-- FS25_FarmFinance - multiplayer events.
--
-- The server owns the state. It sends the whole state (as serialized text,
-- in chunks) to a client when it joins and after every change. Clients ask
-- for changes with FFActionEvent; the server checks permission, runs the
-- action and answers with FFActionResultEvent. Notifications go out with
-- FFNotifyEvent to the players of one farm.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local S = FF.Serializer

local function writeText(streamId, text)
    local chunks = S.chunk(text, 1000)
    streamWriteInt32(streamId, #chunks)
    for _, chunk in ipairs(chunks) do
        streamWriteString(streamId, chunk)
    end
end

local function readText(streamId)
    local count = streamReadInt32(streamId)
    local parts = {}
    for index = 1, count do
        parts[index] = streamReadString(streamId)
    end
    return table.concat(parts)
end

-- State: server -> client ------------------------------------------------------

FFStateEvent = {}
local FFStateEvent_mt = Class(FFStateEvent, Event)
InitEventClass(FFStateEvent, "FFStateEvent")

function FFStateEvent.emptyNew()
    return Event.new(FFStateEvent_mt)
end

function FFStateEvent.new()
    local self = FFStateEvent.emptyNew()
    self.payload = FF.buildStatePayload ~= nil and FF.buildStatePayload() or {}
    return self
end

function FFStateEvent:writeStream(streamId, connection)
    local ok, text = pcall(S.encode, self.payload)
    if not ok then
        U.warn("could not encode state: %s", tostring(text))
        text = S.encode({})
    end
    writeText(streamId, text)
end

function FFStateEvent:readStream(streamId, connection)
    local text = readText(streamId)
    local ok, payload = pcall(S.decode, text)
    if not ok then
        U.warn("could not decode state: %s", tostring(payload))
        return
    end
    self.payload = payload
    self:run(connection)
end

function FFStateEvent:run(connection)
    if connection:getIsServer() and FF.applyStatePayload ~= nil then
        FF.applyStatePayload(self.payload or {})
    end
end

-- Action: client -> server -----------------------------------------------------

FFActionEvent = {}
local FFActionEvent_mt = Class(FFActionEvent, Event)
InitEventClass(FFActionEvent, "FFActionEvent")

function FFActionEvent.emptyNew()
    return Event.new(FFActionEvent_mt)
end

function FFActionEvent.new(farmId, action, params)
    local self = FFActionEvent.emptyNew()
    self.farmId = farmId
    self.action = action
    self.params = params or {}
    return self
end

function FFActionEvent:writeStream(streamId, connection)
    streamWriteInt32(streamId, self.farmId or 0)
    streamWriteString(streamId, self.action or "")
    writeText(streamId, S.encode(self.params or {}))
end

function FFActionEvent:readStream(streamId, connection)
    self.farmId = streamReadInt32(streamId)
    self.action = streamReadString(streamId)
    local ok, params = pcall(S.decode, readText(streamId))
    self.params = ok and params or {}
    self:run(connection)
end

function FFActionEvent:run(connection)
    if connection:getIsServer() then
        return
    end
    local ok, reason = false, "ff_reason_denied"
    if FF.hasPermission(connection, self.farmId, self.action) then
        ok, reason = FF.executeAction(self.farmId, self.action, self.params)
    end
    connection:sendEvent(FFActionResultEvent.new(self.action, ok, reason))
end

-- Result: server -> requesting client ----------------------------------------

FFActionResultEvent = {}
local FFActionResultEvent_mt = Class(FFActionResultEvent, Event)
InitEventClass(FFActionResultEvent, "FFActionResultEvent")

function FFActionResultEvent.emptyNew()
    return Event.new(FFActionResultEvent_mt)
end

function FFActionResultEvent.new(action, ok, reason)
    local self = FFActionResultEvent.emptyNew()
    self.action = action or ""
    self.ok = ok == true
    self.reason = reason or ""
    return self
end

function FFActionResultEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.action)
    streamWriteBool(streamId, self.ok)
    streamWriteString(streamId, self.reason)
end

function FFActionResultEvent:readStream(streamId, connection)
    self.action = streamReadString(streamId)
    self.ok = streamReadBool(streamId)
    self.reason = streamReadString(streamId)
    self:run(connection)
end

function FFActionResultEvent:run(connection)
    if connection:getIsServer() and FF.onActionResult ~= nil then
        FF.onActionResult(self.action, self.ok, self.reason ~= "" and self.reason or nil)
    end
end

-- Notification: server -> clients of one farm --------------------------------

FFNotifyEvent = {}
local FFNotifyEvent_mt = Class(FFNotifyEvent, Event)
InitEventClass(FFNotifyEvent, "FFNotifyEvent")

function FFNotifyEvent.emptyNew()
    return Event.new(FFNotifyEvent_mt)
end

function FFNotifyEvent.new(farmId, text, isWarning)
    local self = FFNotifyEvent.emptyNew()
    self.farmId = farmId or 0
    self.text = text or ""
    self.isWarning = isWarning == true
    return self
end

function FFNotifyEvent:writeStream(streamId, connection)
    streamWriteInt32(streamId, self.farmId)
    streamWriteString(streamId, self.text)
    streamWriteBool(streamId, self.isWarning)
end

function FFNotifyEvent:readStream(streamId, connection)
    self.farmId = streamReadInt32(streamId)
    self.text = streamReadString(streamId)
    self.isWarning = streamReadBool(streamId)
    self:run(connection)
end

function FFNotifyEvent:run(connection)
    if connection:getIsServer() and FF.showNotification ~= nil then
        if g_currentMission ~= nil and g_currentMission:getFarmId() == self.farmId then
            FF.showNotification(self.text, self.isWarning)
        end
    end
end
