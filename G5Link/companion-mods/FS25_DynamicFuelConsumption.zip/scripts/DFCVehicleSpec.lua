-- =============================================================
-- Dynamic Fuel Consumption — DFCVehicleSpec.lua
-- Hooks Motorized.updateConsumers and corrects vanilla's fuel
-- drain to match DFCEngineModel's physics-based target.
--
-- CORRECTED: earlier versions hooked "Motorized.updateFuelUsage",
-- which does not exist anywhere in FS25's Motorized specialization
-- (confirmed against the full function list in the FS25 Community
-- LUADOC — 219 specializations, Motorized has no such method). The
-- real per-tick consumer/fuel update is Motorized:updateConsumers.
-- That's also why the hook never crashed on a nil call: there was
-- nothing to call, because nothing was ever hooked.
--
-- STRATEGY: let vanilla run first (so multi-fuel-type handling,
-- stats/achievements tracking, and other mods' hooks on the same
-- function all still fire normally), then read back what vanilla
-- reports it just consumed (spec.lastFuelUsage, confirmed to be a
-- plain L/h rate — see FS25_EnhancedVehicle's HUD, which displays
-- it directly as "%.1f l/h"), diff that against our own target,
-- and drain/refund only the delta. Same "drain the difference"
-- pattern as most fuel-multiplier mods, but here the target is an
-- absolute physics number instead of vanilla-rate * fudge-factor.
--
-- Verified accessors (confirmed against the decompiled Motorized
-- specialization source and two ModHub mods that read the same
-- motor state for their own HUDs — not guessed):
--   motor:getMotorAvailableTorque()   -- kN*m
--   motor:getMotorExternalTorque()    -- kN*m, PTO/implement draw
--   motor:getMotorRotSpeed()          -- rad/s
--   motor.peakMotorPower              -- kW, built from torque curve
--   vehicle:getMotorLoadPercentage()  -- returns spec.smoothedLoadPercentage
--   vehicle:getConsumerFillUnitIndex(fillType) -- spec.consumersByFillType[fillType].fillUnitIndex
--   spec.lastFuelUsage                -- vanilla's own L/h rate
--
-- ONLY APPLIES to combustion fuel types (diesel/methane) on the
-- server. Electric, hybrid, and anything else is left untouched —
-- the BSFC model doesn't apply to them and vanilla's own accounting
-- is fine as-is.
-- =============================================================

-- Resolve which fuel kind (if any) this vehicle's primary fill unit
-- is, so we know which BSFC curve/density to use — and so we can
-- cleanly skip vehicles the model doesn't apply to.
--
-- CORRECTED: there is no spec.fuelFillUnitIndex field (that was an
-- unverified carry-over assumption and it silently made this whole
-- hook a no-op — no crash, just nil every tick). The real accessor,
-- confirmed against FS25_AdvancedDamageSystem's own fuel resolution
-- (ADS_Specialization.lua, resolveFuelLevel/resolveFuelUsageRatio):
--   vehicle:getConsumerFillUnitIndex(FillType.DIESEL)
-- with a fallback of scanning spec_motorized.consumers for an entry
-- whose .fillType matches, reading its .fillUnitIndex.
local function getFuelKindAndFillUnit(vehicle, spec)
    local candidates = { "DIESEL", "METHANE" }

    for _, kindName in ipairs(candidates) do
        local fillType = FillType[kindName]
        if fillType ~= nil then
            local fillUnitIdx = nil

            if vehicle.getConsumerFillUnitIndex ~= nil then
                fillUnitIdx = vehicle:getConsumerFillUnitIndex(fillType)
                if type(fillUnitIdx) == "table" then
                    fillUnitIdx = tonumber(fillUnitIdx.fillUnitIndex or fillUnitIdx.index or fillUnitIdx[1])
                end
            end

            if fillUnitIdx == nil and spec.consumers ~= nil then
                for _, consumer in pairs(spec.consumers) do
                    if consumer ~= nil and consumer.fillType == fillType and consumer.fillUnitIndex ~= nil then
                        fillUnitIdx = consumer.fillUnitIndex
                        break
                    end
                end
            end

            if fillUnitIdx ~= nil then
                return kindName, fillUnitIdx
            end
        end
    end

    return nil, nil   -- electric/unsupported, or genuinely couldn't resolve
end

-- Apply a signed liter delta to a fill unit. Positive delta = drain
-- more than vanilla already did; negative = refund the difference.
--
-- CORRECTED: there is no "setFillUnitFillLevel" taking an absolute
-- level — that call (guessed, never verified) is almost certainly
-- what corrupted vehicle state and caused the freeze/crash. The
-- real, confirmed API (FillUnit specialization source) is delta-
-- based: FillUnit:addFillUnitFillLevel(farmId, fillUnitIndex,
-- fillLevelDelta, fillTypeIndex, toolType, fillPositionData). It
-- already handles capacity clamping, network sync, mass updates,
-- and effects internally — no need to read-modify-write ourselves.
local function applyDelta(vehicle, fillUnitIdx, deltaLiters)
    if fillUnitIdx == nil then return end
    if deltaLiters == nil or deltaLiters ~= deltaLiters then return end   -- nil or NaN guard
    if math.abs(deltaLiters) < 0.0000001 then return end

    local fillType = vehicle:getFillUnitFillType(fillUnitIdx)
    if fillType == nil or fillType == FillType.UNKNOWN then return end

    -- We want to drain `deltaLiters` more (positive) or refund it
    -- (negative), so the delta we hand to the fill-level API is the
    -- negation of that.
    vehicle:addFillUnitFillLevel(
        vehicle:getOwnerFarmId(),
        fillUnitIdx,
        -deltaLiters,
        fillType,
        ToolType.UNDEFINED,
        nil
    )
end

-- DIAGNOSTIC MODE: set to false to skip the actual fuel-level write
-- entirely while still computing and logging everything. Confirmed
-- stable under real Courseplay field work with this at false — now
-- flipping it back on to test the actual fuel-level effect.
local APPLY_WRITES = true

local originalUpdateConsumers = Motorized.updateConsumers
print(string.format("[DFC] Installing hook. Motorized.updateConsumers before us = %s", tostring(originalUpdateConsumers)))

-- Set to true for one session to confirm the hook is actually
-- resolving real values, then flip back off. Prints once per
-- vehicle (not every tick) so it won't flood the log.
local DEBUG_PRINT_ONCE = true
local debugPrinted = {}

local errorLogged = {}

Motorized.updateConsumers = function(self, dt)
    -- Vanilla runs first and unchanged — this is a correction pass,
    -- not a replacement of the whole system. Wrapped in pcall: if
    -- vanilla (or some OTHER mod's hook on the same function) throws
    -- for this vehicle, we log it once instead of letting it repeat
    -- every tick, which is what an unguarded error turns into a
    -- freeze — the game spending all its time re-failing the same
    -- call dozens of times a second.
    local vanillaOk, vanillaErr = pcall(originalUpdateConsumers, self, dt)
    if not vanillaOk then
        if not errorLogged[self] then
            errorLogged[self] = true
            print(string.format(
                "[DFC] Vanilla Motorized.updateConsumers threw for this vehicle (not our code, we haven't run yet): %s",
                tostring(vanillaErr)
            ))
        end
        return
    end

    local ok, err = pcall(function()

    if not self.isServer then return end

    local spec = self.spec_motorized
    if spec == nil then return end
    if not self:getIsMotorStarted() then return end
    if self.getMotor == nil then return end

    local motor = self:getMotor()
    if motor == nil then return end

    local fuelKind, fillUnitIdx = getFuelKindAndFillUnit(self, spec)

    if DEBUG_PRINT_ONCE and not debugPrinted[self] then
        debugPrinted[self] = true
        print(string.format(
            "[DFC DEBUG] vehicle=%s fuelKind=%s fillUnitIdx=%s hasMotor=%s hasAvailTorque=%s hasExtTorque=%s hasRotSpeed=%s hasLoadPct=%s peakMotorPower=%s",
            tostring(self.getName ~= nil and self:getName() or self),
            tostring(fuelKind), tostring(fillUnitIdx),
            tostring(motor ~= nil),
            tostring(motor ~= nil and motor.getMotorAvailableTorque ~= nil),
            tostring(motor ~= nil and motor.getMotorExternalTorque ~= nil),
            tostring(motor ~= nil and motor.getMotorRotSpeed ~= nil),
            tostring(self.getMotorLoadPercentage ~= nil),
            tostring(motor ~= nil and motor.peakMotorPower)
        ))
    end

    if fuelKind == nil then return end   -- electric/unsupported -> leave vanilla alone

    -- Real net drivetrain power this tick (kW). rotSpeed is rad/s,
    -- torque is kN*m, so the product is kW directly. External torque
    -- (PTO/implement draw) is subtracted so PTO load isn't double
    -- counted as drivetrain power — it already shows up via
    -- getMotorLoadPercentage()'s effect on the BSFC lookup instead.
    local availableTorque = 0.0
    local externalTorque  = 0.0
    local rotSpeed         = 0.0

    if motor.getMotorAvailableTorque ~= nil then
        availableTorque = motor:getMotorAvailableTorque() or 0.0
    end
    if motor.getMotorExternalTorque ~= nil then
        externalTorque = motor:getMotorExternalTorque() or 0.0
    end
    if motor.getMotorRotSpeed ~= nil then
        rotSpeed = motor:getMotorRotSpeed() or 0.0
    end

    local powerOutKW = rotSpeed * (availableTorque - externalTorque)

    local loadFrac = 0.0
    if self.getMotorLoadPercentage ~= nil then
        loadFrac = self:getMotorLoadPercentage() or 0.0
    end

    local peakPowerKW = motor.peakMotorPower or 0.0

    local targetLPerH = DFCEngineModel.computeTargetLPerH(
        powerOutKW,
        loadFrac,
        peakPowerKW,
        fuelKind,
        DynamicFuelConsumption.getIdleLevelKey()
    )
    targetLPerH = targetLPerH * DynamicFuelConsumption.getRealismMultiplier()

    local targetLitersThisTick = (targetLPerH / 3600000.0) * dt

    -- What vanilla itself reports it just did, same field EnhancedVehicle
    -- reads for its HUD — confirmed plain L/h, no re-scaling needed.
    local vanillaLPerH          = spec.lastFuelUsage or 0.0
    local vanillaLitersThisTick = (vanillaLPerH / 3600000.0) * dt

    local delta = targetLitersThisTick - vanillaLitersThisTick

    if APPLY_WRITES then
        applyDelta(self, fillUnitIdx, delta)
    end

    if DEBUG_PRINT_ONCE and debugPrinted[self] == true then
        debugPrinted[self] = "logged"
        print(string.format(
            "[DFC DEBUG] powerOutKW=%.1f loadFrac=%.2f peakPowerKW=%.1f -> targetLPerH=%.2f vanillaLPerH=%.2f deltaThisTick=%.5f",
            powerOutKW, loadFrac, peakPowerKW, targetLPerH, vanillaLPerH, delta
        ))
    end

    end)   -- end of pcall'd body

    if not ok and not errorLogged[self] then
        errorLogged[self] = true
        print(string.format("[DFC] Our own fuel logic threw for this vehicle: %s", tostring(err)))
    end
end

-- Store our own function object so we can later detect whether some
-- other mod (loaded after us) has clobbered Motorized.updateConsumers
-- with a direct, non-chaining reassignment instead of wrapping it.
DynamicFuelConsumption.installedConsumersHook = Motorized.updateConsumers

-- One-shot check, fired ~5s after the mission finishes loading (by
-- which point every mod has had a chance to install its own hooks).
-- If Motorized.updateConsumers no longer matches what we installed,
-- something after us replaced it outright.
local clobberCheckTimer = 5000
FSBaseMission.update = Utils.appendedFunction(FSBaseMission.update, function(self, dt)
    if clobberCheckTimer > 0 then
        clobberCheckTimer = clobberCheckTimer - dt
        if clobberCheckTimer <= 0 then
            clobberCheckTimer = -1
            if Motorized.updateConsumers == DynamicFuelConsumption.installedConsumersHook then
                print("[DFC] Hook check OK: Motorized.updateConsumers still points to our function.")
            else
                print("[DFC] Hook check FAILED: Motorized.updateConsumers has been replaced by something else since we installed it. Our fuel logic is NOT running.")
            end
        end
    end
end)
