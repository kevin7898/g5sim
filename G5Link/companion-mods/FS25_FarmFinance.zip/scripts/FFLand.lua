-- FS25_FarmFinance - land contracts (pure rules).
--
-- Two directions, same rules:
--   "in"  : the farm rents a neighbour's land (an NPC farmland). The game
--           marks the land as the farm's so machines can work it.
--   "out" : the farm rents its own land to a neighbour. The game marks the
--           land as unowned while the lease runs; it still counts as the
--           farm's asset.
--
-- Leases are yearly cash leases that renew automatically. The crop year runs
-- from period 1 to period 12. Signing mid-year pays a prorated share for the
-- rest of the current crop year; after that, rent follows the region's
-- payment dates. A notice given by the region's deadline period ends the
-- lease at the end of the current crop year; later notice ends it a year
-- after that.
--
-- Game calls go through FF.env.land:
--   getOwner(id), setOwner(id, farmId), getPrice(id), getName(id),
--   isBuyable(id), hasMission(id), hasPlaceables(id, farmId), NO_OWNER
-- plus env.getPeriod(), env.getMoney(), env.addMoney(), env.notify().

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region

FF.Land = {}
local L = FF.Land

L.applying = false

local function env()
    return FF.env or {}
end

local function land()
    return env().land or {}
end

local function noOwner()
    return land().NO_OWNER or 0
end

local function addMoney(amount, farmId, typeKey)
    if amount ~= 0 and env().addMoney ~= nil then
        env().addMoney(amount, farmId, typeKey)
    end
end

local function notify(farmId, text, isWarning)
    if env().notify ~= nil then
        env().notify(farmId, text, isWarning)
    end
end

local function random()
    if env().random ~= nil then
        return env().random()
    end
    return math.random()
end

local function markDirty()
    if env().markDirty ~= nil then
        env().markDirty()
    end
end

local function currentPeriod()
    if env().getPeriod ~= nil then
        return env().getPeriod()
    end
    return FF.state.period or 1
end

local function setOwner(farmlandId, farmId)
    if land().setOwner == nil then
        return
    end
    L.applying = true
    local ok, err = pcall(land().setOwner, farmlandId, farmId)
    L.applying = false
    -- Remember every farmland we touched so clients can be brought in line.
    FF.state.touchedFarmlands = FF.state.touchedFarmlands or {}
    FF.state.touchedFarmlands[tostring(farmlandId)] = true
    if not ok then
        U.warn("could not change owner of farmland %s: %s", tostring(farmlandId), tostring(err))
    end
end

local function farmlandName(farmlandId)
    if land().getName ~= nil then
        return land().getName(farmlandId)
    end
    return tostring(farmlandId)
end

-- Lookups --------------------------------------------------------------------

function L.forEachContract(callback)
    for _, farm in pairs(FF.state.farms) do
        for _, contract in pairs(farm.land) do
            callback(contract, farm)
        end
    end
end

function L.getContractByFarmland(farmlandId)
    local found, foundFarm
    L.forEachContract(function(contract, farm)
        if contract.farmlandId == farmlandId then
            found = contract
            foundFarm = farm
        end
    end)
    return found, foundFarm
end

function L.isRentedIn(farmlandId)
    local contract = L.getContractByFarmland(farmlandId)
    return contract ~= nil and contract.kind == "in"
end

function L.isRentedOut(farmlandId)
    local contract = L.getContractByFarmland(farmlandId)
    return contract ~= nil and contract.kind == "out"
end

function L.marketRent(farmlandId)
    local price = land().getPrice ~= nil and land().getPrice(farmlandId) or 0
    return math.floor(price * R.get("land.rentToValue", 0.03) + 0.5)
end

function L.monthsLeftInCropYear(period)
    return 13 - U.clamp(period or 1, 1, 12)
end

function L.getDeadlinePeriod()
    return R.get("land.lease.noticeDeadlinePeriod", 7)
end

-- Rent obligations for credit: yearly rent paid (in) and received (out).
function L.getYearlyRent(farmId)
    local paid, received = 0, 0
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return 0, 0
    end
    for _, contract in pairs(farm.land) do
        if contract.kind == "in" then
            paid = paid + contract.annualRent
        else
            received = received + contract.annualRent
        end
    end
    return paid, received
end

-- Offers ---------------------------------------------------------------------

-- leaseType "cash" (default) or "share"; termId picks a crop-share term
-- from the region (default term when nil).
function L.offerRentIn(farmId, farmlandId, leaseType, termId)
    local offer = {farmlandId = farmlandId, kind = "in", leaseType = leaseType or "cash"}
    local l = land()
    if l.getOwner == nil then
        offer.reason = "ff_reason_landUnavailable"
        return offer
    end
    if L.getContractByFarmland(farmlandId) ~= nil or (l.isForeignLease ~= nil and l.isForeignLease(farmlandId)) then
        offer.reason = "ff_reason_landHasContract"
        return offer
    end
    if l.getOwner(farmlandId) ~= noOwner() then
        offer.reason = "ff_reason_landNotForRent"
        return offer
    end
    if l.isBuyable ~= nil and not l.isBuyable(farmlandId) then
        offer.reason = "ff_reason_landNotForRent"
        return offer
    end
    if l.hasMission ~= nil and l.hasMission(farmlandId) then
        offer.reason = "ff_reason_landMission"
        return offer
    end
    offer.annualRent = L.marketRent(farmlandId)
    if offer.annualRent <= 0 then
        offer.reason = "ff_reason_landUnavailable"
        return offer
    end
    local period = currentPeriod()
    offer.monthsLeft = L.monthsLeftInCropYear(period)
    if offer.leaseType == "share" then
        local term = nil
        for _, candidate in ipairs(R.getCropShareTerms()) do
            if term == nil or candidate.id == termId then
                term = candidate
            end
            if candidate.id == termId then
                break
            end
        end
        if term == nil then
            offer.reason = "ff_reason_noCropShare"
            return offer
        end
        offer.termId = term.id
        offer.landownerShare = term.landownerShare
        offer.inputShare = term.inputShare
        offer.cashEquivalent = offer.annualRent
        offer.annualRent = 0
        offer.upfront = 0
    else
        offer.upfront = math.floor(offer.annualRent * offer.monthsLeft / 12 + 0.5)
    end
    offer.ok = true
    return offer
end

function L.offerRentOut(farmId, farmlandId)
    local offer = {farmlandId = farmlandId, kind = "out"}
    local l = land()
    if l.getOwner == nil then
        offer.reason = "ff_reason_landUnavailable"
        return offer
    end
    if L.getContractByFarmland(farmlandId) ~= nil or (l.isForeignLease ~= nil and l.isForeignLease(farmlandId)) then
        offer.reason = "ff_reason_landHasContract"
        return offer
    end
    if l.getOwner(farmlandId) ~= farmId then
        offer.reason = "ff_reason_landNotOwned"
        return offer
    end
    if l.hasPlaceables ~= nil and l.hasPlaceables(farmlandId, farmId) then
        offer.reason = "ff_reason_landHasBuildings"
        return offer
    end
    if l.hasMission ~= nil and l.hasMission(farmlandId) then
        offer.reason = "ff_reason_landMission"
        return offer
    end
    offer.annualRent = math.floor(L.marketRent(farmlandId) * R.get("land.rentOutFactor", 0.95) + 0.5)
    if offer.annualRent <= 0 then
        offer.reason = "ff_reason_landUnavailable"
        return offer
    end
    local period = currentPeriod()
    offer.monthsLeft = L.monthsLeftInCropYear(period)
    offer.upfront = math.floor(offer.annualRent * offer.monthsLeft / 12 + 0.5)
    offer.ok = true
    return offer
end

-- Signing --------------------------------------------------------------------

local function newContract(farmId, offer)
    local s = FF.state
    return {
        id = FF.Bank.nextId("R"),
        kind = offer.kind,
        farmId = farmId,
        farmlandId = offer.farmlandId,
        name = farmlandName(offer.farmlandId),
        annualRent = offer.annualRent,
        signedMonth = s.monthIndex,
        signedCropYear = s.cropYear,
        billingFromCropYear = s.cropYear + 1,
        lastRenegotiatedCropYear = s.cropYear,
        status = "active",
        source = offer.source or "ff",
        leaseType = offer.leaseType or "cash",
        shareTermId = offer.termId,
        landownerShare = offer.landownerShare,
        inputShare = offer.inputShare
    }
end

function L.isShare(contract)
    return contract ~= nil and contract.leaseType == "share"
end

function L.signRentIn(farmId, farmlandId, leaseType, termId)
    local offer = L.offerRentIn(farmId, farmlandId, leaseType, termId)
    if not offer.ok then
        return nil, offer.reason, offer
    end
    if env().getMoney ~= nil and env().getMoney(farmId) < offer.upfront then
        return nil, "ff_reason_noCash", offer
    end
    local farm = FF.Bank.getFarm(farmId)
    local contract = newContract(farmId, offer)
    farm.land[contract.id] = contract
    setOwner(farmlandId, farmId)
    if offer.upfront > 0 then
        addMoney(-offer.upfront, farmId, "landRent")
        farm.ledger.rentPaid = farm.ledger.rentPaid + offer.upfront
    end
    if L.isShare(contract) then
        notify(farmId, U.text("ff_msg_shareSigned", contract.name, math.floor(contract.landownerShare * 100 + 0.5)), false)
    else
        notify(farmId, U.text("ff_msg_rentInSigned", contract.name, U.money(contract.annualRent)), false)
    end
    markDirty()
    return contract, nil, offer
end

function L.signRentOut(farmId, farmlandId)
    local offer = L.offerRentOut(farmId, farmlandId)
    if not offer.ok then
        return nil, offer.reason, offer
    end
    local farm = FF.Bank.getFarm(farmId)
    local contract = newContract(farmId, offer)
    farm.land[contract.id] = contract
    setOwner(farmlandId, noOwner())
    addMoney(offer.upfront, farmId, "landRentIncome")
    farm.ledger.rentIncome = farm.ledger.rentIncome + offer.upfront
    notify(farmId, U.text("ff_msg_rentOutSigned", contract.name, U.money(contract.annualRent)), false)
    markDirty()
    return contract, nil, offer
end

-- Used by the importer: the land is already the farm's in the game.
function L.adoptRentIn(farmId, farmlandId, annualRent, source)
    local farm = FF.Bank.getFarm(farmId)
    local contract = newContract(farmId, {
        kind = "in",
        farmlandId = farmlandId,
        annualRent = annualRent,
        source = source
    })
    contract.billingFromCropYear = FF.state.cropYear
    farm.land[contract.id] = contract
    markDirty()
    return contract
end

-- Used by the importer: the land is already unowned (rented out) in the game.
function L.adoptRentOut(farmId, farmlandId, annualRent, source)
    local farm = FF.Bank.getFarm(farmId)
    local contract = newContract(farmId, {
        kind = "out",
        farmlandId = farmlandId,
        annualRent = annualRent,
        source = source
    })
    contract.billingFromCropYear = FF.state.cropYear
    farm.land[contract.id] = contract
    markDirty()
    return contract
end

-- Notice ---------------------------------------------------------------------

function L.getEndYearForNoticeNow()
    local period = currentPeriod()
    if period <= L.getDeadlinePeriod() then
        return FF.state.cropYear
    end
    return FF.state.cropYear + 1
end

local function findContract(farmId, contractId)
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return nil
    end
    return farm.land[contractId], farm
end

function L.giveNotice(farmId, contractId)
    local contract = findContract(farmId, contractId)
    if contract == nil then
        return false, "ff_reason_noContract"
    end
    if contract.endCropYear ~= nil then
        return false, "ff_reason_alreadyEnding"
    end
    contract.endCropYear = L.getEndYearForNoticeNow()
    contract.noticeBy = "farm"
    markDirty()
    return true
end

function L.cancelNotice(farmId, contractId)
    local contract = findContract(farmId, contractId)
    if contract == nil then
        return false, "ff_reason_noContract"
    end
    if contract.noticeBy ~= "farm" then
        return false, "ff_reason_cannotCancel"
    end
    local period = currentPeriod()
    local canCancel = contract.endCropYear > FF.state.cropYear
        or (contract.endCropYear == FF.state.cropYear and period <= L.getDeadlinePeriod())
    if not canCancel then
        return false, "ff_reason_cannotCancel"
    end
    contract.endCropYear = nil
    contract.noticeBy = nil
    markDirty()
    return true
end

-- Ends a contract now and gives the land back.
function L.endContract(farm, contract, reasonKey)
    farm.land[contract.id] = nil
    if contract.kind == "in" then
        if land().getOwner ~= nil and land().getOwner(contract.farmlandId) == contract.farmId then
            setOwner(contract.farmlandId, noOwner())
        end
    else
        if land().getOwner ~= nil and land().getOwner(contract.farmlandId) == noOwner() then
            setOwner(contract.farmlandId, contract.farmId)
        end
    end
    notify(contract.farmId, U.text(reasonKey or "ff_msg_leaseEnded", contract.name), false)
    markDirty()
end

-- Monthly hooks (called by FF.Bank.processMonth) -----------------------------

function L.beginMonth(period)
    if period ~= 1 then
        return
    end
    local s = FF.state
    local toEnd = {}
    L.forEachContract(function(contract, farm)
        if contract.endCropYear ~= nil and contract.endCropYear < s.cropYear then
            toEnd[#toEnd + 1] = {contract = contract, farm = farm}
        end
    end)
    for _, item in ipairs(toEnd) do
        L.endContract(item.farm, item.contract, "ff_msg_leaseEnded")
    end

    local every = R.get("land.lease.renegotiateEveryYears", 3)
    L.forEachContract(function(contract, farm)
        if not L.isShare(contract) and every > 0 and s.cropYear - (contract.lastRenegotiatedCropYear or s.cropYear) >= every then
            local newRent = L.marketRent(contract.farmlandId)
            if contract.kind == "out" then
                newRent = math.floor(newRent * R.get("land.rentOutFactor", 0.95) + 0.5)
            end
            contract.lastRenegotiatedCropYear = s.cropYear
            if newRent > 0 and newRent ~= contract.annualRent then
                local old = contract.annualRent
                contract.annualRent = newRent
                notify(contract.farmId, U.text("ff_msg_rentRenegotiated", contract.name, U.money(old), U.money(newRent)), false)
            end
        end
    end)
end

-- Bills one farm's land contracts for this period. Returns the rent the farm
-- had to pay (income from renting out is not an obligation).
function L.billFarm(farm, period)
    local paid = 0
    local share = 0
    for _, payment in ipairs(R.get("land.rentPayments", {})) do
        if payment.period == period then
            share = share + (payment.share or 0)
        end
    end
    if share <= 0 then
        return 0
    end
    for _, id in ipairs(U.sortedKeys(farm.land)) do
        local contract = farm.land[id]
        if contract ~= nil and not L.isShare(contract) and FF.state.cropYear >= (contract.billingFromCropYear or 0) then
            local amount = math.floor(contract.annualRent * share + 0.5)
            if contract.kind == "in" then
                addMoney(-amount, farm.farmId, "landRent")
                farm.ledger.rentPaid = farm.ledger.rentPaid + amount
                paid = paid + amount
            else
                addMoney(amount, farm.farmId, "landRentIncome")
                farm.ledger.rentIncome = farm.ledger.rentIncome + amount
            end
        end
    end
    return paid
end

function L.endMonth(period)
    local deadline = L.getDeadlinePeriod()
    if period == deadline - 1 then
        for _, farm in pairs(FF.state.farms) do
            if U.count(farm.land) > 0 then
                notify(farm.farmId, U.text("ff_msg_noticeDeadlineSoon"), false)
            end
        end
    end
    if period ~= deadline then
        return
    end
    local s = FF.state
    L.forEachContract(function(contract)
        if contract.endCropYear == nil then
            local chance
            if contract.kind == "in" then
                chance = R.get("land.lease.landlordNonRenewChance", 0.03)
            else
                chance = R.get("land.lease.tenantNonRenewChance", 0.05)
            end
            if random() < chance then
                contract.endCropYear = s.cropYear
                contract.noticeBy = contract.kind == "in" and "landlord" or "tenant"
                local key = contract.kind == "in" and "ff_msg_landlordNotice" or "ff_msg_tenantNotice"
                notify(contract.farmId, U.text(key, contract.name), true)
            end
        end
    end)
end

-- The game changed a farmland's owner. If that breaks one of our contracts
-- (sold, bought by someone else), drop the contract.
function L.onOwnerChanged(farmlandId, newOwner)
    if L.applying then
        return
    end
    local contract, farm = L.getContractByFarmland(farmlandId)
    if contract == nil then
        return
    end
    local expected = contract.kind == "in" and contract.farmId or noOwner()
    if newOwner ~= expected then
        farm.land[contract.id] = nil
        notify(contract.farmId, U.text("ff_msg_leaseBroken", contract.name), true)
        markDirty()
    end
end

-- After loading a save, drop contracts whose land no longer matches.
function L.validate()
    if land().getOwner == nil then
        return
    end
    local broken = {}
    L.forEachContract(function(contract, farm)
        local owner = land().getOwner(contract.farmlandId)
        local expected = contract.kind == "in" and contract.farmId or noOwner()
        if owner ~= expected then
            broken[#broken + 1] = {farm = farm, contract = contract}
        end
    end)
    for _, item in ipairs(broken) do
        item.farm.land[item.contract.id] = nil
        U.warn("dropped land contract %s on farmland %s: owner no longer matches", item.contract.id, tostring(item.contract.farmlandId))
    end
end

-- Current owner (on the server) of every farmland we ever changed, so
-- multiplayer clients can apply the same owners.
function L.getOwnershipMap()
    local map = {}
    if land().getOwner == nil then
        return map
    end
    for key in pairs(FF.state.touchedFarmlands or {}) do
        local farmlandId = tonumber(key)
        if farmlandId ~= nil then
            map[key] = land().getOwner(farmlandId)
        end
    end
    return map
end

return L
