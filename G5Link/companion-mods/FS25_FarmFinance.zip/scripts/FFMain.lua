-- FS25_FarmFinance - bootstrap: hooks, lifecycle, actions, notifications.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region
local B = FF.Bank
local L = FF.Land
local D = FF.FarmData
local P = FF.Persistence
local I = FF.Importer

FF.MOD_NAME = g_currentModName or FF.MOD_NAME
FF.MOD_DIR = g_currentModDirectory or FF.MOD_DIR

FF.blocked = {bank = false, rentIn = false, rentOut = false}
FF.conflicts = {bank = {}, rentIn = {}, rentOut = {}}
FF.pendingPeriods = 0
FF.dirty = false
FF.dirtyTimer = 0
FF.loaded = false

-- Money types (statistic name, text key) ---------------------------------------

FF.MONEY = {
    loanProceeds = {stat = "ffLoanProceeds", l10n = "ff_stat_loanProceeds"},
    loanInterest = {stat = "ffLoanInterest", l10n = "ff_stat_loanInterest"},
    loanPrincipal = {stat = "ffLoanPrincipal", l10n = "ff_stat_loanPrincipal"},
    landRent = {stat = "ffLandRent", l10n = "ff_stat_landRent"},
    landRentIncome = {stat = "ffRentIncome", l10n = "ff_stat_rentIncome"},
    cropShareLandowner = {stat = "ffCropShareLandowner", l10n = "ff_stat_cropShareLandowner"},
    cropShareInputs = {stat = "ffCropShareInputs", l10n = "ff_stat_cropShareInputs"},
    cropShareStorage = {stat = "ffCropShareStorage", l10n = "ff_stat_cropShareStorage"},
    inputAccountDraw = {stat = "ffInputAccountDraw", l10n = "ff_stat_inputAccountDraw"},
    inputAccountPayment = {stat = "ffInputAccountPayment", l10n = "ff_stat_inputAccountPayment"},
    inputAccountInterest = {stat = "ffInputAccountInterest", l10n = "ff_stat_inputAccountInterest"},
    inputDiscount = {stat = "ffInputDiscount", l10n = "ff_stat_inputDiscount"},
    lineDraw = {stat = "ffLineDraw", l10n = "ff_stat_lineDraw"},
    lineRepay = {stat = "ffLineRepay", l10n = "ff_stat_lineRepay"},
    leaseFunding = {stat = "ffLeaseFunding", l10n = "ff_stat_leaseFunding"},
    leasePayment = {stat = "ffLeasePayment", l10n = "ff_stat_leasePayment"},
    leaseDeposit = {stat = "ffLeaseDeposit", l10n = "ff_stat_leaseDeposit"},
    leaseReturn = {stat = "ffLeaseReturn", l10n = "ff_stat_leaseReturn"},
    leaseBuyout = {stat = "ffLeaseBuyout", l10n = "ff_stat_leaseBuyout"},
    dealerRebate = {stat = "ffDealerRebate", l10n = "ff_stat_dealerRebate"}
}

function FF.registerMoneyTypes()
    -- Remembered on MoneyType itself so a second savegame in the same game
    -- session reuses the types instead of registering them again.
    MoneyType.__ffTypes = MoneyType.__ffTypes or {}
    for _, info in pairs(FF.MONEY) do
        local existing = MoneyType.__ffTypes[info.stat]
        if existing == nil then
            local ok, created = pcall(MoneyType.register, info.stat, info.l10n, FF.MOD_NAME)
            if ok and created ~= nil then
                existing = created
                MoneyType.__ffTypes[info.stat] = created
            else
                U.warn("could not register money type %s: %s", info.stat, tostring(created))
            end
        end
        info.moneyType = existing or MoneyType.OTHER
        if FinanceStats ~= nil and FinanceStats.statNames ~= nil and FinanceStats.statNameToIndex[info.stat] == nil then
            table.insert(FinanceStats.statNames, info.stat)
            FinanceStats.statNameToIndex[info.stat] = #FinanceStats.statNames
            if FinanceStats.statNamesI18n ~= nil then
                FinanceStats.statNamesI18n[info.stat] = g_i18n:getText(info.l10n)
            end
        end
    end
end

-- Mod texts are mod-scoped; copy ours into the game's table so base-game
-- screens (finance page, GUI $l10n_ lookups) can see them.
function FF.mergeTexts()
    local ok, err = pcall(function()
        local meta = getmetatable(_G)
        local globalEnv = meta ~= nil and meta.__index or nil
        local globalI18n = type(globalEnv) == "table" and globalEnv.g_i18n or nil
        if globalI18n == nil or globalI18n == g_i18n or g_i18n.texts == nil then
            return
        end
        for key, text in pairs(g_i18n.texts) do
            if U.startsWith(key, "ff_") then
                globalI18n.texts[key] = text
            end
        end
    end)
    if not ok then
        U.warn("could not share texts: %s", tostring(err))
    end
end

-- Hooks ----------------------------------------------------------------------
-- A base-game function is wrapped only once per game session, however often
-- these scripts are sourced. The wrapper looks up the newest implementation
-- in a registry kept on the hooked class, and passes straight through while
-- no savegame with Farm Finance is running.

FF.hookList = FF.hookList or {}

function FF.hook(target, methodName, kind, fn)
    if target == nil or target[methodName] == nil then
        U.warn("cannot hook %s: missing", tostring(methodName))
        return
    end
    target.__ffHooks = target.__ffHooks or {}
    local registry = target.__ffHooks[methodName]
    if registry == nil then
        registry = {impl = fn, active = true}
        target.__ffHooks[methodName] = registry
        if kind == "overwritten" then
            target[methodName] = Utils.overwrittenFunction(target[methodName], function(self, superFunc, ...)
                if registry.active then
                    return registry.impl(self, superFunc, ...)
                end
                return superFunc(self, ...)
            end)
        elseif kind == "prepended" then
            target[methodName] = Utils.prependedFunction(target[methodName], function(...)
                if registry.active then
                    registry.impl(...)
                end
            end)
        else
            target[methodName] = Utils.appendedFunction(target[methodName], function(...)
                if registry.active then
                    registry.impl(...)
                end
            end)
        end
        table.insert(FF.hookList, registry)
    else
        registry.impl = fn
        registry.active = true
        local known = false
        for _, item in ipairs(FF.hookList) do
            if item == registry then
                known = true
            end
        end
        if not known then
            table.insert(FF.hookList, registry)
        end
    end
end

function FF.setHooksActive(active)
    for _, registry in ipairs(FF.hookList) do
        registry.active = active
    end
end

-- Conflicts ----------------------------------------------------------------------

function FF.detectConflicts()
    FF.conflicts = {}
    FF.blocked = {}
    for _, feature in ipairs(FF.CONFLICT_FEATURES) do
        FF.conflicts[feature] = {}
        for _, prefix in ipairs(FF.CONFLICTS[feature] or {}) do
            for _, modName in ipairs(U.sortedKeys(g_modIsLoaded or {})) do
                if g_modIsLoaded[modName] == true and U.startsWith(modName, prefix) then
                    table.insert(FF.conflicts[feature], modName)
                end
            end
        end
        FF.blocked[feature] = #FF.conflicts[feature] > 0
        if FF.blocked[feature] then
            U.warn("%s is off because these mods are active: %s", feature, table.concat(FF.conflicts[feature], ", "))
        end
    end
end

function FF.anyBlocked()
    for _, feature in ipairs(FF.CONFLICT_FEATURES) do
        if FF.blocked[feature] then
            return true
        end
    end
    return false
end

function FF.getConflictText(...)
    local names, seen = {}, {}
    for _, feature in ipairs({...}) do
        for _, name in ipairs(FF.conflicts[feature] or {}) do
            if not seen[name] then
                seen[name] = true
                names[#names + 1] = name
            end
        end
    end
    return table.concat(names, ", ")
end

-- Another mod's manager lives in that mod's script environment.
local function getOtherModGlobal(modName, globalName)
    local ok, value = pcall(function()
        local direct = getfenv(0)[globalName]
        if direct ~= nil then
            return direct
        end
        local env = getfenv(0)[modName]
        return type(env) == "table" and env[globalName] or nil
    end)
    if ok then
        return value
    end
    return nil
end

FF.getOtherModGlobal = getOtherModGlobal

function FF.isLeasedByOtherMod(farmlandId)
    local rentYourField = getOtherModGlobal("FS25_RentYourField", "g_rentYourFieldManager")
    if rentYourField ~= nil and rentYourField.getRentAgreement ~= nil and rentYourField:getRentAgreement(farmlandId) ~= nil then
        return true
    end
    local fieldLeasing = getOtherModGlobal("FS25_FieldLeasing", "g_fieldLeasingManager")
    if fieldLeasing ~= nil and fieldLeasing.getLeaseAgreement ~= nil and fieldLeasing:getLeaseAgreement(farmlandId) ~= nil then
        return true
    end
    return false
end

-- Permissions ---------------------------------------------------------------------

function FF.canManageFarm()
    if g_currentMission == nil then
        return false
    end
    if g_currentMission:getIsServer() or g_currentMission.isMasterUser == true then
        return true
    end
    local ok, allowed = pcall(g_currentMission.getHasPlayerPermission, g_currentMission, Farm.PERMISSION.MANAGE_RIGHTS)
    return ok and allowed == true
end

function FF.canChangeRegion()
    if g_currentMission == nil then
        return false
    end
    return g_currentMission:getIsServer() or g_currentMission.isMasterUser == true
end

function FF.hasPermission(connection, farmId, action)
    if connection == nil then
        return true
    end
    if action == "setRegion" then
        local ok, isMaster = pcall(function()
            return g_currentMission:getIsMasterUserConnection(connection)
        end)
        return ok and isMaster == true
    end
    local player = g_currentMission.connectionsToPlayer ~= nil and g_currentMission.connectionsToPlayer[connection] or nil
    if player == nil or player.farmId ~= farmId then
        return false
    end
    local ok, allowed = pcall(g_currentMission.getHasPlayerPermission, g_currentMission, Farm.PERMISSION.MANAGE_RIGHTS, connection, farmId)
    return ok and allowed == true
end

-- Environment for the rules code (server and client) ----------------------------

function FF.showNotification(text, isWarning)
    if g_currentMission == nil or text == nil or text == "" then
        return
    end
    local kind = isWarning and FSBaseMission.INGAME_NOTIFICATION_CRITICAL or FSBaseMission.INGAME_NOTIFICATION_OK
    local ok = pcall(g_currentMission.addIngameNotification, g_currentMission, kind, text)
    if not ok then
        U.log("%s", text)
    end
end

function FF.setupEnv()
    FF.env = {
        getMoney = function(farmId)
            return D.getCash(farmId)
        end,
        addMoney = function(amount, farmId, typeKey)
            if not FF.isServer() then
                return
            end
            local info = FF.MONEY[typeKey]
            local moneyType = info ~= nil and info.moneyType or MoneyType.OTHER
            g_currentMission:addMoney(amount, farmId, moneyType, true, true)
        end,
        -- Same, without the money popup (for frequent small bookings).
        addMoneyQuiet = function(amount, farmId, typeKey)
            if not FF.isServer() then
                return
            end
            local info = FF.MONEY[typeKey]
            local moneyType = info ~= nil and info.moneyType or MoneyType.OTHER
            g_currentMission:addMoney(amount, farmId, moneyType, true, false)
        end,
        -- With a base-game MoneyType (API purchases).
        addMoneyType = function(amount, farmId, moneyType)
            if not FF.isServer() then
                return
            end
            g_currentMission:addMoney(amount, farmId, moneyType or MoneyType.OTHER, true, true)
        end,
        inputMoneyType = function(fillTypeName)
            if fillTypeName == "SEEDS" or fillTypeName == "TREESAPLINGS" or fillTypeName == "POPLARSAPLINGS" then
                return MoneyType.PURCHASE_SEEDS or MoneyType.OTHER
            end
            return MoneyType.PURCHASE_FERTILIZER or MoneyType.OTHER
        end,
        notify = function(farmId, text, isWarning)
            if g_currentMission:getFarmId() == farmId then
                FF.showNotification(text, isWarning)
            end
            if g_server ~= nil and FFNotifyEvent ~= nil then
                g_server:broadcastEvent(FFNotifyEvent.new(farmId, text, isWarning), false)
            end
        end,
        random = function()
            return math.random()
        end,
        getFarmIds = function()
            local ids = {}
            for _, farm in pairs(g_farmManager:getFarms() or {}) do
                if farm.farmId ~= nil and farm.farmId > 0 and farm.farmId ~= FarmManager.SPECTATOR_FARM_ID then
                    ids[#ids + 1] = farm.farmId
                end
            end
            table.sort(ids)
            return ids
        end,
        getPeriod = function()
            local environment = g_currentMission.environment
            return environment ~= nil and environment.currentPeriod or 1
        end,
        snapshot = function(farmId)
            return D.snapshot(farmId)
        end,
        -- Base price of a crop, used only before the farm has sold any of it.
        getFallbackPrice = function(fillTypeName)
            local fillType = g_fillTypeManager ~= nil and g_fillTypeManager:getFillTypeByName(fillTypeName) or nil
            return fillType ~= nil and fillType.pricePerLiter or 0
        end,
        markDirty = function()
            FF.dirty = true
        end,
        now = function()
            return g_currentMission ~= nil and g_currentMission.time or 0
        end,
        equipment = FF.makeEquipmentEnv(),
        land = {
            NO_OWNER = FarmlandManager.NO_OWNER_FARM_ID,
            getOwner = function(farmlandId)
                return g_farmlandManager:getFarmlandOwner(farmlandId)
            end,
            setOwner = function(farmlandId, farmId)
                g_farmlandManager:setLandOwnership(farmlandId, farmId)
                g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, farmId)
            end,
            getPrice = function(farmlandId)
                local farmland = g_farmlandManager:getFarmlandById(farmlandId)
                return farmland ~= nil and farmland.price or 0
            end,
            getName = function(farmlandId)
                local farmland = g_farmlandManager:getFarmlandById(farmlandId)
                if farmland ~= nil and farmland.name ~= nil and farmland.name ~= "" then
                    return tostring(farmland.name)
                end
                return U.text("ff_label_farmland", tostring(farmlandId))
            end,
            -- Land held by another lease mod that is still active
            isForeignLease = function(farmlandId)
                return FF.isLeasedByOtherMod(farmlandId)
            end,
            hasMission = function(farmlandId)
                local farmland = g_farmlandManager:getFarmlandById(farmlandId)
                if farmland == nil or g_missionManager == nil or g_missionManager.getIsMissionRunningOnFarmland == nil then
                    return false
                end
                return g_missionManager:getIsMissionRunningOnFarmland(farmland) == true
            end,
            hasPlaceables = function(farmlandId, farmId)
                local system = g_currentMission.placeableSystem
                if system == nil or system.placeables == nil then
                    return false
                end
                for _, placeable in ipairs(system.placeables) do
                    if placeable.getOwnerFarmId ~= nil and placeable:getOwnerFarmId() == farmId and placeable.rootNode ~= nil then
                        local x, _, z = getWorldTranslation(placeable.rootNode)
                        if g_farmlandManager:getFarmlandIdAtWorldPosition(x, z) == farmlandId then
                            return true
                        end
                    end
                end
                return false
            end
        }
    }
end

-- Actions (run on the server) ----------------------------------------------------

FF.ACTIONS = {
    takeLoan = function(farmId, params)
        if FF.blocked.bank then
            return false, "ff_reason_blocked"
        end
        local loan, reason = B.applyForLoan(farmId, params.productId, tonumber(params.termYears) or 1, tonumber(params.amount) or 0)
        return loan ~= nil, reason
    end,
    payExtra = function(farmId, params)
        return B.payExtra(farmId, params.loanId, tonumber(params.amount) or 0)
    end,
    payOff = function(farmId, params)
        return B.payOff(farmId, params.loanId)
    end,
    rentIn = function(farmId, params)
        if FF.blocked.rentIn then
            return false, "ff_reason_blocked"
        end
        local contract, reason = L.signRentIn(farmId, tonumber(params.farmlandId), params.leaseType, params.termId)
        return contract ~= nil, reason
    end,
    settleShare = function(farmId, params)
        local ok, reason = FF.CropShare.settleNow(farmId, params.fillType)
        return ok, reason
    end,
    openLine = function(farmId)
        if FF.blocked.bank then
            return false, "ff_reason_blocked"
        end
        return FF.Line.open(farmId)
    end,
    lineDraw = function(farmId, params)
        if FF.blocked.bank then
            return false, "ff_reason_blocked"
        end
        return FF.Line.draw(farmId, tonumber(params.amount) or 0)
    end,
    lineRepay = function(farmId, params)
        return FF.Line.repay(farmId, tonumber(params.amount))
    end,
    closeLine = function(farmId)
        return FF.Line.close(farmId)
    end,
    payInputs = function(farmId, params)
        return FF.Inputs.payNow(farmId, tonumber(params.amount))
    end,
    setAutoCharge = function(farmId, params)
        return FF.Inputs.setAutoCharge(farmId, params.enabled == true)
    end,
    preApprove = function(farmId, params)
        if FF.blocked.bank then
            return false, "ff_reason_blocked"
        end
        -- Brand and used status come from the store, not from the client.
        local storeItem = g_storeManager ~= nil and g_storeManager:getItemByXMLFilename(params.storeXml or "") or nil
        if storeItem == nil or not FF.isShopItemFinanceable(storeItem) then
            return false, "ff_reason_notFinanceable"
        end
        params.brand = FF.getBrandName(storeItem)
        params.price = tonumber(params.price) or 0
        params.storeName = params.storeName or storeItem.name
        return FF.Equipment.preApprove(farmId, params)
    end,
    leaseReturn = function(farmId, params)
        return FF.Equipment.returnLease(farmId, params.leaseId)
    end,
    leaseBuyout = function(farmId, params)
        return FF.Equipment.buyoutLease(farmId, params.leaseId)
    end,
    leaseExtend = function(farmId, params)
        return FF.Equipment.extendLease(farmId, params.leaseId)
    end,
    rentOut = function(farmId, params)
        if FF.blocked.rentOut then
            return false, "ff_reason_blocked"
        end
        local contract, reason = L.signRentOut(farmId, tonumber(params.farmlandId))
        return contract ~= nil, reason
    end,
    notice = function(farmId, params)
        return L.giveNotice(farmId, params.contractId)
    end,
    cancelNotice = function(farmId, params)
        return L.cancelNotice(farmId, params.contractId)
    end,
    setRegion = function(farmId, params)
        if params.regionId == nil or R.regions[params.regionId] == nil then
            return false, "ff_reason_noRegion"
        end
        R.activate(params.regionId)
        FF.state.regionId = params.regionId
        FF.applyRentalPricing()
        FF.dirty = true
        FF.env.notify(farmId, U.text("ff_msg_regionChanged", R.getName(params.regionId)), false)
        return true
    end
}

function FF.executeAction(farmId, action, params)
    if FF.state == nil or not FF.isServer() then
        return false, "ff_reason_denied"
    end
    local handler = FF.ACTIONS[action]
    if handler == nil then
        return false, "ff_reason_unknownAction"
    end
    local ok, result, reason = pcall(handler, farmId, params or {})
    if not ok then
        U.warn("action %s failed: %s", tostring(action), tostring(result))
        return false, "ff_reason_declined"
    end
    if result then
        FF.dirty = true
    end
    return result == true, reason
end

function FF.requestAction(action, params)
    local farmId = g_currentMission:getFarmId()
    if FF.isServer() then
        local ok, reason = FF.executeAction(farmId, action, params)
        FF.onActionResult(action, ok, reason)
    else
        g_client:getServerConnection():sendEvent(FFActionEvent.new(farmId, action, params))
    end
end

function FF.onActionResult(action, ok, reason)
    if action == "preApprove" then
        if ok and FF.pendingShopScreen ~= nil then
            if FF.isServer() then
                -- single player / host: the money is already in the account
                FF.completeShopPurchase()
            else
                -- client: give the farm's new balance a moment to arrive
                FF.pendingShopScreen.buyAt = (g_currentMission.time or 0) + 1000
            end
        elseif not ok then
            FF.pendingShopScreen = nil
        end
    end
    if not ok and reason ~= nil then
        InfoDialog.show(U.text(reason))
    end
    FF.refreshUi()
end

-- Presses the shop's own Buy for the approved machine, exactly as the
-- player would. If that isn't possible, says to press Buy.
function FF.completeShopPurchase()
    local pending = FF.pendingShopScreen
    FF.pendingShopScreen = nil
    local screen = pending ~= nil and pending.screen or nil
    local button = screen ~= nil and screen.buyButton or nil
    local done = false
    if button ~= nil and button.onClickCallback ~= nil then
        local ok, err = pcall(button.onClickCallback, button.target or screen, button)
        done = ok
        if not ok then
            U.warn("could not complete the purchase: %s", tostring(err))
        end
    elseif screen ~= nil and screen.onClickBuy ~= nil then
        local ok, err = pcall(screen.onClickBuy, screen)
        done = ok
        if not ok then
            U.warn("could not complete the purchase: %s", tostring(err))
        end
    end
    if not done then
        InfoDialog.show(U.text("ff_msg_pressBuy", math.floor(FF.Equipment.PENDING_MS / 60000)))
    end
end

function FF.refreshUi()
    if FF.openFrame ~= nil and FF.openFrame.updateContent ~= nil then
        local ok, err = pcall(FF.openFrame.updateContent, FF.openFrame)
        if not ok then
            U.warn("menu refresh failed: %s", tostring(err))
        end
    end
end

-- State sync ---------------------------------------------------------------------------

function FF.buildStatePayload()
    return {
        state = FF.state,
        region = {id = R.getActiveId(), values = R.active ~= nil and R.active.values or {}},
        ownership = L.getOwnershipMap(),
        blocked = FF.blocked,
        conflicts = FF.conflicts
    }
end

function FF.applyStatePayload(payload)
    if FF.isServer() or payload == nil or payload.state == nil then
        return
    end
    FF.state = payload.state
    B.init(FF.state)
    if payload.region ~= nil then
        R.setActiveResolved(payload.region.id, payload.region.values)
    end
    FF.blocked = payload.blocked or FF.blocked
    FF.conflicts = payload.conflicts or FF.conflicts
    for key, owner in pairs(payload.ownership or {}) do
        local farmlandId = tonumber(key)
        if farmlandId ~= nil and g_farmlandManager:getFarmlandOwner(farmlandId) ~= owner then
            g_farmlandManager:setLandOwnership(farmlandId, owner)
        end
    end
    FF.refreshUi()
end

function FF.broadcastState()
    if g_server ~= nil and FFStateEvent ~= nil then
        g_server:broadcastEvent(FFStateEvent.new(), false)
    end
end

-- Lifecycle ------------------------------------------------------------------------------

local function getMapNames()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    if missionInfo == nil then
        return nil, nil
    end
    return missionInfo.mapTitle, missionInfo.mapId
end

-- Server: load the save, import old mods, take over the vanilla loan.
function FF.onItemsLoaded()
    FF.ensureInit()
    if not FF.isServer() then
        return
    end
    local ok, err = pcall(function()
        local loadedState = P.load()
        B.init(loadedState)
        local mapTitle, mapId = getMapNames()
        local regionId, why = R.select(FF.state.regionId, mapTitle, mapId)
        R.activate(regionId)
        FF.state.regionId = regionId
        U.log("region %s (%s); market rate %.2f%%", regionId, why, (FF.state.baseRate or 0) * 100)

        if FF.state.period == nil then
            FF.state.period = FF.env.getPeriod()
        end

        L.validate()
        FF.Equipment.cleanupAfterLoad()
        if U.count(FF.state.promos or {}) == 0 then
            FF.Equipment.refreshPromos()
        end
        FF.applyRentalPricing()

        -- Each import source checks on its own that its mod is gone.
        if I.run(P.getSavegameDirectory()) then
            FF.state.importReportSeen = false
            FF.pendingImportNotice = true
        end
        if not FF.blocked.bank then
            for _, gameFarm in pairs(g_farmManager:getFarms() or {}) do
                if gameFarm.farmId ~= nil and gameFarm.farmId > 0 and (gameFarm.loan or 0) > 0 then
                    local remainder = I.getVanillaRemainder(gameFarm.farmId, gameFarm.loan)
                    if remainder > 0 then
                        B.convertVanillaLoan(gameFarm.farmId, remainder)
                    end
                    gameFarm.loan = 0
                end
            end
        end
        FF.refreshCropShareFlags()
        FF.loaded = true
        FF.dirty = true
    end)
    if not ok then
        U.warn("load failed: %s", tostring(err))
        if FF.state == nil then
            B.init(nil)
        end
        FF.loaded = true
    end
end

function FF.onSave()
    if FF.isServer() and FF.loaded then
        local ok, err = pcall(P.save)
        if not ok then
            U.warn("save failed: %s", tostring(err))
        end
    end
end

function FF.onSendInitialClientState(mission, connection)
    if connection ~= nil and FF.state ~= nil then
        connection:sendEvent(FFStateEvent.new())
    end
end

-- Crop share: harvest, sales and inputs ------------------------------------------------

local function pack(...)
    return {n = select("#", ...), ...}
end

local function getFarmlandAt(vehicle)
    if vehicle == nil or vehicle.rootNode == nil or g_farmlandManager == nil then
        return nil
    end
    local x, _, z = getWorldTranslation(vehicle.rootNode)
    return g_farmlandManager:getFarmlandIdAtWorldPosition(x, z)
end

local function fillTypeName(fillTypeIndex)
    if fillTypeIndex == nil or g_fillTypeManager == nil then
        return nil
    end
    return g_fillTypeManager:getFillTypeNameByIndex(fillTypeIndex)
end

local function combineLevel(combine, spec)
    local total = 0
    if spec ~= nil and spec.fillUnitIndex ~= nil then
        total = total + (combine:getFillUnitFillLevel(spec.fillUnitIndex) or 0)
    end
    if spec ~= nil and spec.bufferFillUnitIndex ~= nil then
        total = total + (combine:getFillUnitFillLevel(spec.bufferFillUnitIndex) or 0)
    end
    return total
end

-- Measures what one combine pass added to the tank and credits the
-- landowner's share when the combine is on a crop-share field.
function FF.onCombineCutterArea(combine, superFunc, area, liters, inputFruitType, outputFillType, ...)
    if not FF.cropShareActive or not FF.isServer() or FF.state == nil then
        return superFunc(combine, area, liters, inputFruitType, outputFillType, ...)
    end
    local spec = combine.spec_combine
    local ok, before = pcall(combineLevel, combine, spec)
    local results = pack(superFunc(combine, area, liters, inputFruitType, outputFillType, ...))
    if ok then
        local okAfter, after = pcall(combineLevel, combine, spec)
        local delta = okAfter and (after - before) or 0
        if delta > 0 then
            local done, err = pcall(function()
                FF.CropShare.onHarvest(combine:getOwnerFarmId(), getFarmlandAt(combine), fillTypeName(outputFillType), delta)
            end)
            if not done then
                U.warn("crop share harvest: %s", tostring(err))
            end
        end
    end
    return unpack(results, 1, results.n)
end

-- A sale pays the landowner's share first (Harvest Quality uses the same hook).
function FF.onSellFillType(station, superFunc, farmId, fillDelta, fillTypeIndex, toolType, ...)
    local price = nil
    if FF.cropShareTracking and FF.isServer() and FF.state ~= nil and fillDelta ~= nil and fillDelta > 0
            and station.getEffectiveFillTypePrice ~= nil then
        local ok, value = pcall(station.getEffectiveFillTypePrice, station, fillTypeIndex, toolType)
        if ok and type(value) == "number" then
            price = value
        end
    end
    local results = pack(superFunc(station, farmId, fillDelta, fillTypeIndex, toolType, ...))
    if price ~= nil and farmId ~= nil and farmId > 0 then
        local name = fillTypeName(fillTypeIndex)
        local ok, liters, value = pcall(FF.CropShare.onSale, farmId, name, fillDelta, price)
        if ok and value ~= nil and value > 0 then
            FF.env.addMoney(-value, farmId, "cropShareLandowner")
            FarmFinanceAPI.fire("landownerPaid", farmId, name, liters, value)
        elseif not ok then
            U.warn("crop share sale: %s", tostring(liters))
        end
    end
    return unpack(results, 1, results.n)
end

function FF.onSowingEnd(machine, dt, hasProcessed)
    if not FF.cropShareActive or not FF.isServer() then
        return
    end
    local ok, err = pcall(function()
        local spec = machine.spec_sowingMachine
        local params = spec ~= nil and spec.workAreaParameters or nil
        if params == nil or (params.lastChangedArea or 0) <= 0 or params.seedsFruitType == nil then
            return
        end
        local fruitDesc = g_fruitTypeManager:getFruitTypeByIndex(params.seedsFruitType)
        if fruitDesc == nil or fruitDesc.seedUsagePerSqm == nil then
            return
        end
        local hectares = MathUtil.areaToHa(params.lastChangedArea, g_currentMission:getFruitPixelsToSqm())
        local usage = fruitDesc.seedUsagePerSqm * hectares * 10000 * (spec.seedUsageScale or 1)
        local seedFillType = spec.seedFillType or FillType.SEEDS
        local costPerLiter = g_currentMission.economyManager:getCostPerLiter(seedFillType, false) or 0
        FF.CropShare.onInputUse(machine:getOwnerFarmId(), getFarmlandAt(machine), usage * costPerLiter)
    end)
    if not ok then
        U.warn("crop share seed cost: %s", tostring(err))
    end
end

function FF.onSprayerEnd(sprayer, dt, hasProcessed)
    if not FF.cropShareActive or not FF.isServer() then
        return
    end
    local ok, err = pcall(function()
        local spec = sprayer.spec_sprayer
        local params = spec ~= nil and spec.workAreaParameters or nil
        if params == nil or not params.isActive or (params.usage or 0) <= 0 or params.sprayFillType == nil then
            return
        end
        local costPerLiter = g_currentMission.economyManager:getCostPerLiter(params.sprayFillType, false) or 0
        FF.CropShare.onInputUse(sprayer:getOwnerFarmId(), getFarmlandAt(sprayer), params.usage * costPerLiter)
    end)
    if not ok then
        U.warn("crop share spray cost: %s", tostring(err))
    end
end

-- Input purchases ------------------------------------------------------------------------
-- AI helpers buy seed and fertilizer as they work (PURCHASE_SEEDS /
-- PURCHASE_FERTILIZER, every frame): those are summed and booked every two
-- seconds. Shop pallets of inputs: BuyVehicleData:buy tells us an input
-- pallet is being bought, the money hook sees the charge; whichever comes
-- second books it, so a purchase that fails is never credited.

FF.pendingAiInputs = FF.pendingAiInputs or {}
FF.AI_INPUT_STATS = {purchaseSeeds = true, purchaseFertilizer = true}
FF.SHOP_MATCH_MS = 2000

local function collectFillTypeNames(value, out, depth)
    if value == nil or depth > 4 then
        return
    end
    local valueType = type(value)
    if valueType == "string" then
        out[string.upper(value)] = true
    elseif valueType == "number" then
        local name = fillTypeName(value)
        if name ~= nil then
            out[name] = true
        end
    elseif valueType == "table" then
        if type(value.name) == "string" then
            out[string.upper(value.name)] = true
        end
        for _, item in pairs(value) do
            if type(item) ~= "function" then
                collectFillTypeNames(item, out, depth + 1)
            end
        end
    end
end

-- Is this shop purchase a pallet / big bag / IBC of a farm input?
function FF.isInputPurchase(buyData)
    local storeItem = buyData.storeItem
    if storeItem == nil or buyData.leaseVehicle or buyData.isFreeOfCharge then
        return false
    end
    local okLimited, _, isPallet = pcall(buyData.getIsLimitedObjectPurchase, buyData)
    if not okLimited or not isPallet then
        return false
    end
    if StoreItemUtil ~= nil and StoreItemUtil.loadSpecsFromXML ~= nil then
        pcall(StoreItemUtil.loadSpecsFromXML, storeItem)
    end
    local names = {}
    collectFillTypeNames(storeItem.specs ~= nil and storeItem.specs.fillTypes or nil, names, 0)
    for name in pairs(names) do
        if FF.Inputs.isInputFillType(name) then
            return true, name
        end
    end
    return false
end

function FF.getBrandName(storeItem)
    if storeItem == nil or g_brandManager == nil or storeItem.brandIndex == nil then
        return nil
    end
    local ok, brand = pcall(g_brandManager.getBrandByIndex, g_brandManager, storeItem.brandIndex)
    if ok and brand ~= nil then
        return brand.title or brand.name
    end
    return nil
end

-- Pairs the shop's purchase (BuyVehicleData:buy) with its money charge.
-- Input pallets go to the input account; machines go to the equipment rules
-- (financing bound, or a promo brand's cash rebate).
local function matchShopPurchase()
    local pending, charge = FF.pendingShopInput, FF.recentShopCharge
    if pending == nil or charge == nil or pending.farmId ~= charge.farmId then
        return
    end
    if math.abs((pending.time or 0) - (charge.time or 0)) > FF.SHOP_MATCH_MS then
        return
    end
    if pending.isInput then
        if charge.cost < pending.price - 1 or charge.cost > pending.price * 100 + 1 then
            return
        end
    elseif math.abs(charge.cost - pending.price) > math.max(1, pending.price * 0.01) then
        return
    end
    FF.pendingShopInput = nil
    FF.recentShopCharge = nil
    if pending.isInput then
        FF.Inputs.onInputPurchase(charge.farmId, charge.cost, {description = pending.name})
    else
        FF.Equipment.onShopPurchase(charge.farmId, charge.cost, pending)
    end
end

function FF.onShopBuy(buyData)
    if not FF.isServer() or FF.state == nil or FF.blocked.bank or not FF.loaded then
        return
    end
    if buyData.leaseVehicle or buyData.isFreeOfCharge or buyData.storeItem == nil then
        return
    end
    local ok, isInput = pcall(FF.isInputPurchase, buyData)
    FF.pendingShopInput = {
        farmId = buyData.ownerFarmId,
        price = buyData.price or 0,
        name = buyData.storeItem.name,
        storeXml = buyData.storeItem.xmlFilename,
        brand = FF.getBrandName(buyData.storeItem),
        isSale = buyData.saleItem ~= nil,
        isInput = ok and isInput == true,
        time = g_currentMission.time
    }
    matchShopPurchase()
end

-- Every money change on the server (Farm.changeBalance).
function FF.onMoneyChanged(gameFarm, amount, moneyType)
    D.onChangeBalance(gameFarm, amount, moneyType)
    if FF.state == nil or not FF.loaded or not FF.isServer() or gameFarm == nil then
        return
    end
    if FF.Inputs.suppressPurchaseHook or FF.blocked.bank or amount == nil or amount >= 0 then
        return
    end
    local statistic = type(moneyType) == "table" and moneyType.statistic or nil
    local farmId = gameFarm.farmId
    if statistic == nil or farmId == nil or farmId <= 0 then
        return
    end
    if FF.AI_INPUT_STATS[statistic] then
        FF.pendingAiInputs[farmId] = (FF.pendingAiInputs[farmId] or 0) - amount
    elseif statistic == "newVehiclesCost" then
        FF.recentShopCharge = {farmId = farmId, cost = -amount, time = g_currentMission.time}
        matchShopPurchase()
        -- No buy record (yet)? A financed deal can still be matched on price.
        if FF.recentShopCharge ~= nil and #FF.Equipment.pending > 0 then
            local result = FF.Equipment.onShopPurchase(farmId, -amount, {})
            if result == "financed" or result == "leased" then
                FF.recentShopCharge = nil
            end
        end
    end
end

-- Equipment: shop button, sell protection, rental pricing -----------------------------

local function getUniqueId(vehicle)
    if vehicle == nil then
        return nil
    end
    if vehicle.uniqueId ~= nil then
        return tostring(vehicle.uniqueId)
    end
    if vehicle.getUniqueId ~= nil then
        local ok, uid = pcall(vehicle.getUniqueId, vehicle)
        if ok and uid ~= nil then
            return tostring(uid)
        end
    end
    return nil
end

local function forEachVehicle(callback)
    local system = g_currentMission ~= nil and g_currentMission.vehicleSystem or nil
    if system == nil or system.vehicles == nil then
        return
    end
    for _, vehicle in pairs(system.vehicles) do
        if callback(vehicle) then
            return
        end
    end
end

function FF.makeEquipmentEnv()
    return {
        getUniqueId = getUniqueId,
        findVehicle = function(uid)
            local found
            forEachVehicle(function(vehicle)
                if not vehicle.markedForDeletion and getUniqueId(vehicle) == uid then
                    found = vehicle
                    return true
                end
            end)
            return found
        end,
        listUids = function(farmId)
            local uids = {}
            forEachVehicle(function(vehicle)
                local uid = getUniqueId(vehicle)
                if uid ~= nil and vehicle.getOwnerFarmId ~= nil and vehicle:getOwnerFarmId() == farmId then
                    uids[uid] = true
                end
            end)
            return uids
        end,
        findNewVehicle = function(farmId, storeXml, excludeUids)
            local found, foundUid
            forEachVehicle(function(vehicle)
                local uid = getUniqueId(vehicle)
                if uid ~= nil and not excludeUids[uid] and not vehicle.markedForDeletion
                        and vehicle.getOwnerFarmId ~= nil and vehicle:getOwnerFarmId() == farmId
                        and vehicle.propertyState == VehiclePropertyState.OWNED
                        and vehicle.configFileName ~= nil and storeXml ~= nil
                        and string.lower(vehicle.configFileName) == string.lower(storeXml) then
                    found, foundUid = vehicle, uid
                    return true
                end
            end)
            return found, foundUid
        end,
        getHours = function(vehicle)
            local time = vehicle.getOperatingTime ~= nil and vehicle:getOperatingTime() or vehicle.operatingTime or 0
            return (time or 0) / 3600000
        end,
        -- Repairs needed to bring the machine back to standard: ADS's
        -- dealer estimate when ADS is installed, else the game's repair and
        -- repaint price.
        getWearCost = function(vehicle)
            local maintenance = FF.getOtherModGlobal("FS25_AdvancedDamageSystem", "ADS_Maintenance")
            if maintenance ~= nil and maintenance.getVehicleRepairEstimate ~= nil and vehicle.spec_AdvancedDamageSystem ~= nil then
                local ok, estimate = pcall(maintenance.getVehicleRepairEstimate, vehicle)
                if ok and type(estimate) == "table" and estimate.basePrice ~= nil then
                    return math.max(estimate.basePrice - (estimate.warrantyCoverage or 0), 0)
                end
            end
            local cost = 0
            if vehicle.getRepairPrice ~= nil then
                local ok, price = pcall(vehicle.getRepairPrice, vehicle)
                cost = cost + (ok and price or 0)
            end
            if vehicle.getRepaintPrice ~= nil then
                local ok, price = pcall(vehicle.getRepaintPrice, vehicle)
                cost = cost + (ok and price or 0)
            end
            return cost
        end,
        deleteVehicle = function(vehicle)
            vehicle:delete()
        end,
        -- The game's own resale value for this machine after `months` and `hours`.
        projectResidual = function(storeXml, price, months, hours)
            local storeItem = g_storeManager ~= nil and g_storeManager:getItemByXMLFilename(storeXml) or nil
            if storeItem == nil or Vehicle == nil or Vehicle.calculateSellPrice == nil then
                return nil
            end
            local ok, value = pcall(Vehicle.calculateSellPrice, storeItem, months, hours * 3600000, price, 0, 0)
            if ok and U.isFiniteNumber(value) then
                return value
            end
            return nil
        end,
        listPromoBrands = function()
            local brands, seen = {}, {}
            if g_storeManager == nil or g_storeManager.getItems == nil then
                return brands
            end
            local minPrice = R.get("equipment.promo.minPrice", 30000)
            local ok, items = pcall(g_storeManager.getItems, g_storeManager)
            for _, item in ipairs(ok and items or {}) do
                if item.species == StoreSpecies.VEHICLE and (item.price or 0) >= minPrice and item.showInStore ~= false then
                    local brand = FF.getBrandName(item)
                    if brand ~= nil and brand ~= "" and not seen[brand] then
                        seen[brand] = true
                        brands[#brands + 1] = brand
                    end
                end
            end
            table.sort(brands)
            return brands
        end
    }
end

function FF.isShopItemFinanceable(storeItem)
    if storeItem == nil or storeItem.species ~= StoreSpecies.VEHICLE then
        return false
    end
    return (storeItem.price or 0) >= R.get("loans.minAmount", 5000)
end

function FF.setupShopButton(screen, storeItem)
    local source = screen.buyButton
    if source == nil or source.clone == nil then
        return
    end
    local button = screen.ffFinanceButton
    -- With another finance mod active, stay out of the shop entirely (its
    -- button may use the same key).
    if FF.blocked.bank then
        if button ~= nil then
            button:setVisible(false)
            button:setDisabled(true)
        end
        return
    end
    if button == nil then
        button = source:clone(source.parent)
        button.name = "ffFinanceButton"
        button.inputActionName = "MENU_EXTRA_1"
        screen.ffFinanceButton = button
    end
    button:setVisible(true)
    button:setText(U.text("ff_button_shopFinance"))
    local eligible = FF.isShopItemFinanceable(storeItem) and FF.canManageFarm() and FF.state ~= nil
    button:setDisabled(not eligible)
    button.onClickCallback = function()
        FF.UI.openShopFinance(screen, storeItem)
    end
end

function FF.onShopSetStoreItem(screen, superFunc, storeItem, ...)
    local results = pack(superFunc(screen, storeItem, ...))
    local ok, err = pcall(FF.setupShopButton, screen, storeItem)
    if not ok then
        U.warn("shop button: %s", tostring(err))
    end
    return unpack(results, 1, results.n)
end

-- Client: the shop's Sell button on a leased machine.
function FF.onShopControllerSell(controller, superFunc, storeItem, concreteItem, ...)
    local uid = type(concreteItem) == "table" and getUniqueId(concreteItem) or nil
    if uid ~= nil and FF.Equipment.isLeased(uid) then
        InfoDialog.show(U.text("ff_msg_leasedNoSell"))
        return
    end
    return superFunc(controller, storeItem, concreteItem, ...)
end

-- Server: any sale of a machine. Leased machines can't be sold; selling a
-- machine that secures a loan pays the loan off from the proceeds.
function FF.onSellVehicleEventRun(event, superFunc, connection, ...)
    if connection == nil or connection:getIsServer() or FF.state == nil then
        return superFunc(event, connection, ...)
    end
    local vehicle = event.vehicle
    local uid = getUniqueId(vehicle)
    if uid ~= nil and FF.Equipment.isLeased(uid) then
        FF.env.notify(vehicle:getOwnerFarmId(), U.text("ff_msg_leasedNoSell"), true)
        return
    end
    local farmId = vehicle ~= nil and vehicle.getOwnerFarmId ~= nil and vehicle:getOwnerFarmId() or nil
    local results = pack(superFunc(event, connection, ...))
    if vehicle ~= nil and uid ~= nil and farmId ~= nil and (vehicle.markedForDeletion or vehicle.isDeleted) then
        local ok, err = pcall(FF.Equipment.onVehicleSold, farmId, uid)
        if not ok then
            U.warn("collateral payoff: %s", tostring(err))
        end
    end
    return unpack(results, 1, results.n)
end

-- Rental = the game's own lease button, priced by the region's scales.
function FF.applyRentalPricing()
    if EconomyManager == nil then
        return
    end
    if FF.Importer.isModActive("FS25_FairLeasingPlus") then
        return
    end
    EconomyManager.__ffOriginal = EconomyManager.__ffOriginal or {
        deposit = EconomyManager.DEFAULT_LEASING_DEPOSIT_FACTOR,
        day = EconomyManager.PER_DAY_LEASING_FACTOR,
        hour = EconomyManager.DEFAULT_RUNNING_LEASING_FACTOR
    }
    local original = EconomyManager.__ffOriginal
    local values = {
        DEFAULT_LEASING_DEPOSIT_FACTOR = original.deposit ~= nil and original.deposit * R.get("equipment.rental.depositScale", 1) or nil,
        PER_DAY_LEASING_FACTOR = original.day ~= nil and original.day * R.get("equipment.rental.perDayScale", 1) or nil,
        DEFAULT_RUNNING_LEASING_FACTOR = original.hour ~= nil and original.hour * R.get("equipment.rental.perHourScale", 1) or nil
    }
    local economy = g_currentMission ~= nil and g_currentMission.economyManager or nil
    for name, value in pairs(values) do
        EconomyManager[name] = value
        if economy ~= nil and rawget(economy, name) ~= nil then
            economy[name] = value
        end
    end
end

function FF.flushAiInputs()
    for farmId, total in pairs(FF.pendingAiInputs) do
        if total > 0 then
            local ok, err = pcall(FF.Inputs.onInputPurchase, farmId, total, {quiet = true, description = U.text("ff_desc_aiInputs")})
            if not ok then
                U.warn("input account: %s", tostring(err))
            end
        end
    end
    FF.pendingAiInputs = {}
end

function FF.refreshCropShareFlags()
    FF.cropShareActive = FF.CropShare.hasShareContracts()
    local held = false
    if FF.state ~= nil then
        for _, farm in pairs(FF.state.farms) do
            if farm.cropShare ~= nil and #(farm.cropShare.lots or {}) > 0 then
                held = true
            end
        end
    end
    FF.cropShareTracking = FF.cropShareActive or held
end

-- Message center callbacks receive the subscription target first.
function FF.onPeriodChanged(_)
    if FF.isServer() then
        FF.pendingPeriods = FF.pendingPeriods + 1
    end
end

function FF.onFarmlandOwnerChanged(_, farmlandId, farmId, loadFromSavegame)
    if FF.isServer() and FF.loaded and not loadFromSavegame then
        L.onOwnerChanged(farmlandId, farmId)
    end
end

-- In-game menu page ----------------------------------------------------------------------

function FF.attachMenuPage(frame)
    local menu = g_inGameMenu
    if menu == nil or menu.pagingElement == nil then
        return false
    end
    local pageName = "ffMenuFrame"
    menu.controlIDs[pageName] = nil

    local targetPosition = #menu.pagingElement.elements + 1
    for index, child in ipairs(menu.pagingElement.elements) do
        if child == menu.pageStatistics or child == menu.pageFinances then
            targetPosition = index + 1
        end
    end

    menu[pageName] = frame
    menu.pagingElement:addElement(frame)
    menu:exposeControlsAsFields(pageName)

    for index, child in ipairs(menu.pagingElement.elements) do
        if child == frame then
            table.remove(menu.pagingElement.elements, index)
            table.insert(menu.pagingElement.elements, math.min(targetPosition, #menu.pagingElement.elements + 1), child)
            break
        end
    end
    for index, page in ipairs(menu.pagingElement.pages) do
        if page.element == frame then
            table.remove(menu.pagingElement.pages, index)
            table.insert(menu.pagingElement.pages, math.min(targetPosition, #menu.pagingElement.pages + 1), page)
            break
        end
    end
    menu.pagingElement:updateAbsolutePosition()
    menu.pagingElement:updatePageMapping()

    menu:registerPage(frame, nil, function()
        return true
    end)
    menu:addPageTab(frame, FF.MOD_DIR .. "gui/menuIcon.dds", GuiUtils.getUVs({0, 0, 1024, 1024}))

    for index, child in ipairs(menu.pageFrames) do
        if child == frame then
            table.remove(menu.pageFrames, index)
            table.insert(menu.pageFrames, math.min(targetPosition, #menu.pageFrames + 1), child)
            break
        end
    end
    menu:rebuildTabList()
    return true
end

function FF.loadGui()
    g_gui:loadProfiles(FF.MOD_DIR .. "gui/guiProfiles.xml")
    FFOptionsDialog.register(FF.MOD_DIR)
    local frame = FFMenuFrame.new()
    g_gui:loadGui(FF.MOD_DIR .. "gui/FFMenuFrame.xml", "ffMenuFrame", frame, true)
    FF.pendingMenuFrame = frame
end

-- Mod event listener -----------------------------------------------------------------

FFMain = {}

-- Session setup. Safe to call more than once: loadMap and the savegame
-- load hook both call it, whichever runs first does the work.
function FF.ensureInit()
    if FF.initDone then
        return
    end
    FF.initDone = true
    FF.MOD_NAME = FF.MOD_NAME or g_currentModName
    FF.loaded = false
    FF.pendingPeriods = 0
    FF.mergeTexts()
    FF.detectConflicts()
    FF.setupEnv()
    FF.registerMoneyTypes()
    R.loadAll(FF.MOD_DIR)
    R.activate(R.select(nil, getMapNames()))
    FF.setHooksActive(true)
    -- Public API for other mods (see API.md)
    if g_currentMission ~= nil then
        g_currentMission.farmFinanceAPI = FarmFinanceAPI
    end
    pcall(function()
        getfenv(0).FarmFinanceAPI = FarmFinanceAPI
    end)
    g_messageCenter:subscribe(MessageType.PERIOD_CHANGED, FF.onPeriodChanged, FF)
    g_messageCenter:subscribe(MessageType.FARMLAND_OWNER_CHANGED, FF.onFarmlandOwnerChanged, FF)
    if g_server == nil and FF.state == nil then
        -- Clients start empty and wait for the server's state.
        B.init(nil)
    end
end

function FFMain:loadMap()
    FF.ensureInit()
    local ok, err = pcall(FF.loadGui)
    if not ok then
        U.warn("GUI failed to load: %s", tostring(err))
    end
    U.log("version %s loaded", FF.VERSION)
end

function FFMain:deleteMap()
    if g_messageCenter ~= nil then
        g_messageCenter:unsubscribeAll(FF)
    end
    FF.setHooksActive(false)
    FF.initDone = false
    FF.state = nil
    FF.openFrame = nil
    FF.pendingMenuFrame = nil
    FF.loaded = false
end

function FFMain:update(dt)
    -- Attach the menu page once the map page is fully set up.
    if FF.pendingMenuFrame ~= nil then
        local mapFrame = g_inGameMenu ~= nil and g_inGameMenu.pageMapOverview or nil
        if g_currentMission ~= nil and g_currentMission.mapOverlayGenerator ~= nil and mapFrame ~= nil
                and type(mapFrame.displayCropTypes) == "table" then
            local frame = FF.pendingMenuFrame
            FF.pendingMenuFrame = nil
            local ok, err = pcall(FF.attachMenuPage, frame)
            if not ok then
                U.warn("could not add the menu page: %s", tostring(err))
            end
        end
    end

    -- Multiplayer client: finish an approved shop purchase once the balance is in.
    if FF.pendingShopScreen ~= nil and FF.pendingShopScreen.buyAt ~= nil
            and g_currentMission ~= nil and g_currentMission.time >= FF.pendingShopScreen.buyAt then
        FF.completeShopPurchase()
    end

    if not FF.isServer() or not FF.loaded or FF.state == nil then
        return
    end

    -- Crop share: refresh the cheap flags the harvest hooks check every
    -- frame, and send harvest progress to clients every few seconds.
    FF.cropShareTimer = (FF.cropShareTimer or 0) + dt
    if FF.cropShareTimer >= 1000 then
        FF.cropShareSyncTimer = (FF.cropShareSyncTimer or 0) + FF.cropShareTimer
        FF.cropShareTimer = 0
        FF.refreshCropShareFlags()
        -- Book AI helpers' seed and fertilizer buys, drop stale shop matches,
        -- tie financed purchases to their machines, reverse unused approvals.
        FF.flushAiInputs()
        local okEquipment, errEquipment = pcall(function()
            FF.Equipment.bindVehicles()
            FF.Equipment.expirePending()
        end)
        if not okEquipment then
            U.warn("equipment deals: %s", tostring(errEquipment))
        end
        local now = g_currentMission.time
        if FF.pendingShopInput ~= nil and now - (FF.pendingShopInput.time or 0) > FF.SHOP_MATCH_MS then
            FF.pendingShopInput = nil
        end
        if FF.recentShopCharge ~= nil and now - (FF.recentShopCharge.time or 0) > FF.SHOP_MATCH_MS then
            FF.recentShopCharge = nil
        end
        if FF.CropShare.dirty and FF.cropShareSyncTimer >= 5000 then
            FF.CropShare.dirty = false
            FF.cropShareSyncTimer = 0
            FF.dirty = true
        end
    end

    -- One game month per frame (PERIOD_CHANGED fires before the period
    -- advances, so this also reads the new period).
    if FF.pendingPeriods > 0 then
        FF.pendingPeriods = FF.pendingPeriods - 1
        local period = FF.env.getPeriod()
        local ok, err = pcall(B.processMonth, period)
        if not ok then
            U.warn("monthly processing failed: %s", tostring(err))
        end
        FarmFinanceAPI.fire("monthProcessed", period)
    end

    if FF.pendingImportNotice then
        FF.pendingImportNotice = false
        local farmId = g_currentMission:getFarmId()
        if farmId ~= nil and farmId > 0 then
            FF.showNotification(U.text("ff_msg_imported"), false)
        end
    end

    if FF.dirty then
        FF.dirtyTimer = FF.dirtyTimer + dt
        if FF.dirtyTimer >= 500 then
            FF.dirty = false
            FF.dirtyTimer = 0
            FF.broadcastState()
            FF.refreshUi()
        end
    end
end

addModEventListener(FFMain)

-- Hooks are installed when this file is sourced, before the mission and the
-- in-game menu load (FF.hook makes repeat installs harmless).
FF.hook(Mission00, "loadItemsFinished", "appended", function()
    FF.onItemsLoaded()
end)
FF.hook(FSBaseMission, "saveSavegame", "appended", function()
    FF.onSave()
end)
FF.hook(FSBaseMission, "sendInitialClientState", "appended", function(mission, connection)
    FF.onSendInitialClientState(mission, connection)
end)
FF.hook(Farm, "changeBalance", "appended", function(farm, amount, moneyType)
    FF.onMoneyChanged(farm, amount, moneyType)
end)
if BuyVehicleData ~= nil then
    FF.hook(BuyVehicleData, "buy", "appended", function(self, ...)
        FF.onShopBuy(self)
    end)
end
if ShopConfigScreen ~= nil then
    FF.hook(ShopConfigScreen, "setStoreItem", "overwritten", function(self, superFunc, ...)
        return FF.onShopSetStoreItem(self, superFunc, ...)
    end)
end
if ShopController ~= nil then
    FF.hook(ShopController, "sell", "overwritten", function(self, superFunc, ...)
        return FF.onShopControllerSell(self, superFunc, ...)
    end)
end
if SellVehicleEvent ~= nil then
    FF.hook(SellVehicleEvent, "run", "overwritten", function(self, superFunc, ...)
        return FF.onSellVehicleEventRun(self, superFunc, ...)
    end)
end
-- Farm Finance is the bank: the vanilla loan buttons go away, unless a
-- conflicting loan mod is active (then everything is left alone).
FF.hook(InGameMenuStatisticsFrame, "hasPlayerLoanPermission", "overwritten", function(self, superFunc, ...)
    if FF.blocked.bank then
        return superFunc(self, ...)
    end
    return false
end)
-- Crop share. Class functions are wrapped before vehicle types are built,
-- so every combine, seeder and sprayer picks the wrappers up (Moisture
-- System and Harvest Quality hook the same places).
if Combine ~= nil then
    FF.hook(Combine, "addCutterArea", "overwritten", function(self, superFunc, ...)
        return FF.onCombineCutterArea(self, superFunc, ...)
    end)
end
if SellingStation ~= nil then
    FF.hook(SellingStation, "sellFillType", "overwritten", function(self, superFunc, ...)
        return FF.onSellFillType(self, superFunc, ...)
    end)
end
if SowingMachine ~= nil then
    FF.hook(SowingMachine, "onEndWorkAreaProcessing", "appended", function(self, dt, hasProcessed)
        FF.onSowingEnd(self, dt, hasProcessed)
    end)
end
if Sprayer ~= nil then
    FF.hook(Sprayer, "onEndWorkAreaProcessing", "appended", function(self, dt, hasProcessed)
        FF.onSprayerEnd(self, dt, hasProcessed)
    end)
end

FF.hook(InGameMenuMapFrame, "onLoadMapFinished", "overwritten", function(self, superFunc, ...)
    return FF.MapFrame.onLoadMapFinished(self, superFunc, ...)
end)
FF.hook(InGameMenuMapFrame, "setMapInputContext", "overwritten", function(self, superFunc, ...)
    return FF.MapFrame.setMapInputContext(self, superFunc, ...)
end)
