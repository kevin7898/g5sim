# RealisticSeeder module boundary

RealisticSeeder is now the seed-only module in the FieldPath agronomy stack.

Owns:
- Mechanical seed placement, manual drill/planter setup, and equipped-machine settings telemetry (2.1.0.0)
- Crop-specific seed fill types
- Seed lots
- Brands and varieties/hybrids
- Seed treatment state and roleplay fallback
- ProBox product-selector mapping where supported
- FieldPath seed inventory manifests

Does not own:
- Weather/soil establishment failures owned by Soil & Fertilizer
- Herbicides, fungicides, insecticides, desiccants, SoyGreen, or tank mixes
- N/P/K/S/lime/manure fertility modelling
- Grain storage, drying, routing, contracts, or bin telemetry

Related modules:
- FS25_RealisticCropProtection
- FS25_RealisticNutrients
- FS25_GrainControl
- FS25_FieldPathExporter / FieldPath Command

Placement API v2 is exposed as `g_currentMission.realisticSeederAPI`. See
`PLACEMENT_API_V2.txt` for the current contract and `PLACEMENT_API_V1.txt` for
the compatible snapshot/record schema and historical consumer examples.
FieldPath retains ownership of coverage. Existing seed-lot catalogs remain
metadata and do not yet drive germination or vigor effects.

## FieldPath 2 integration (v2.0.3.2)

Telemetry now targets FieldPath 2 first: registers as module
"RealisticSeeder", emits seed.seederState events into FP2's checkpointed
event log, and publishes all Phase 3 seed catalogs to
modSettings/FS25_FieldPath2/modules/RealisticSeeder/. Without FieldPath 2 the
original FieldPath 1 behaviour (FS25_FieldPathCommand state file + catalog
dumps) is preserved unchanged. Planting passes remain owned by FP2; join
seed.seederState to passes by vehicle + time.
