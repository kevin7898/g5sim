-- Example only: not automatically loaded. FieldPath owns its checkpointed sink.
-- Call attach after mission startup; call detach on mission teardown.
FieldPathPlacementConsumer = {}
function FieldPathPlacementConsumer.attach(vehicle, cursor, accept)
    local api=g_currentMission and g_currentMission.realisticSeederAPI
    if not api or (api.version~=1 and api.version~=2) then return nil,"providerUnavailable" end
    local capabilities=api.getCapabilities(vehicle)
    if not capabilities or not capabilities.settingsLogging then return nil,"loggingNotEquipped" end
    local replay=api.getRecords(vehicle,cursor or 0)
    if replay.resetRequired then return nil,"restoreMatchingCheckpoint" end
    if replay.truncated then return nil,"historyGap" end
    for _,row in ipairs(replay.records) do accept(row.event,row) end
    local token=api.subscribe(function(event,row,source)
        if source==vehicle then accept(event,row) end
    end)
    return {api=api,token=token,snapshot=api.getSnapshot(vehicle)}
end
function FieldPathPlacementConsumer.detach(handle)
    if handle then handle.api.unsubscribe(handle.token) end
end
