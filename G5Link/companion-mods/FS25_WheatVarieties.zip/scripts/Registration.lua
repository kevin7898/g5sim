local WV = WheatVarieties
local Tree = WV.XmlTree
local Registration = {}
WV.Registration = Registration

local function node(name, children)
    return { name = name, attributes = {}, children = children or {} }
end

local function cacheDistanceTextures(tree, cache, copied)
    local path = tree.attributes.distanceMap
    if path and path ~= "" then
        -- Native distance textures are always relative to the foliage XML,
        -- even when the supplied value is an absolute path. Cache the small
        -- installed DDS textures; do not distribute game artwork in the mod.
        local dds = path:gsub("%.png$", ".dds")
        if fileExists(dds) then path = dds end
        assert(fileExists(path), "Missing wheat distance texture: " .. path)
        local relative = "distance/" .. assert(path:match("[^/\\]+$"))
        if not copied[path] then
            copyFile(path, cache .. relative, true)
            assert(fileExists(cache .. relative), "Cannot cache wheat distance texture")
            copied[path] = true
        end
        tree.attributes.distanceMap = relative
    end
    for _, child in ipairs(tree.children) do cacheDistanceTextures(child, cache, copied) end
end

function Registration.prepare()
    if WV.state.prepared then return end
    WV.definitions = WV.Definitions.parse(Tree.load(WV.directory .. "config/varieties.xml", "wheatVarieties"))
    local settings = getUserProfileAppPath() .. "modSettings/"
    createFolder(settings)
    WV.cacheDirectory = settings .. "FS25_WheatVarieties/"
    createFolder(WV.cacheDirectory)
    local cache = WV.cacheDirectory .. "generated/"
    createFolder(cache)
    createFolder(cache .. "distance/")

    local wheat = Tree.load("data/foliage/wheat/wheat.xml", "foliageType")
    local fillMap = Tree.load("data/maps/maps_fillTypes.xml", "map")
    local wheatFill
    for _, fill in ipairs(assert(Tree.child(fillMap, "fillTypes"), "Missing base fillTypes").children) do
        if fill.name == "fillType" and (fill.attributes.name or ""):upper() == "WHEAT" then
            wheatFill = fill
        end
    end
    assert(wheatFill, "Base wheat fill definition not found")
    local fillNodes, fruitNodes = {}, {}
    -- Build all documents before registering anything, so invalid configuration
    -- cannot register just half of the pair.
    local foliage, copiedTextures = {}, {}
    for _, def in ipairs(WV.definitions) do
        foliage[def.name] = WV.Definitions.makeFoliage(wheat, def)
        cacheDistanceTextures(foliage[def.name], cache, copiedTextures)
        fillNodes[#fillNodes + 1] = WV.Definitions.makeFillType(wheatFill, def)
        def.foliageFilename = cache .. def.layerName .. ".xml"
        local entry = node("fruitType")
        entry.attributes.filename = def.foliageFilename
        fruitNodes[#fruitNodes + 1] = entry
    end
    for _, def in ipairs(WV.definitions) do Tree.save(def.foliageFilename, foliage[def.name]) end
    WV.state.fillTypesFilename = cache .. "fillTypes.xml"
    WV.state.fruitTypesFilename = cache .. "fruitTypes.xml"
    Tree.save(WV.state.fillTypesFilename, node("map", {node("fillTypes", fillNodes)}))
    Tree.save(WV.state.fruitTypesFilename, node("map", {node("fruitTypes", fruitNodes)}))
    WV.state.prepared = true
    WV.state.phase = "prepared"
    WV.log("Generated native XML from this game's wheat assets: %s", cache)
end

function Registration.loadFills(manager)
    if WV.state.fillsLoaded then return end
    Registration.prepare()
    local wheat = assert(manager:getFillTypeByName("WHEAT"), "WHEAT fill type unavailable")
    assert(#manager.fillTypes + #WV.definitions <= 2 ^ FillTypeManager.SEND_NUM_BITS - 1, "Fill type capacity exceeded")
    for _, def in ipairs(WV.definitions) do
        assert(manager:getFillTypeByName(def.name) == nil, "Fill type name collision: " .. def.name)
    end
    local xml = XMLFile.load("wvFillTypes", WV.state.fillTypesFilename, FillTypeManager.xmlSchema)
    assert(xml, "Generated fillTypes XML failed to load")
    local ok, result = pcall(manager.loadFillTypes, manager, xml, "", false, WV.modName)
    xml:delete()
    assert(ok, result)
    assert(result ~= false, "Fill type loading rejected")
    for _, def in ipairs(WV.definitions) do
        local fill = assert(manager:getFillTypeByName(def.name), "Fill type not registered: " .. def.name)
        -- Only transport/storage categories. Do not silently change animal diets
        -- or factory ingredient recipes by joining every wheat category.
        for _, category in ipairs({"BULK", "COMBINE", "AUGERWAGON", "FARMSILO", "TRAINWAGON"}) do
            local categoryIndex = manager.nameToCategoryIndex[category]
            if categoryIndex and manager:getIsFillTypeInCategory(wheat.index, category) then
                assert(manager:addFillTypeToCategory(fill.index, categoryIndex), "Cannot extend " .. category)
            end
        end
        if fill.finalize then fill:finalize() end
        WV.state.fills[def.name] = fill
        WV.log("Registered grain %s index=%d component=%s", def.name, fill.index, def.componentId)
    end
    WV.state.fillsLoaded = true
    WV.state.phase = "grainsRegistered"
end

function Registration.loadFruits(manager, missionInfo)
    assert(WV.state.fillsLoaded, "Grains must register before fruit types; loading order changed")
    if WV.state.fruitsLoaded then return end
    local wheat = assert(manager:getFruitTypeByName("WHEAT"), "WHEAT fruit type unavailable")
    assert(#manager:getFruitTypes() + #WV.definitions <= 2 ^ FruitTypeManager.SEND_NUM_BITS - 1, "Fruit type capacity exceeded")
    for _, def in ipairs(WV.definitions) do
        assert(manager:getFruitTypeByName(def.name) == nil, "Fruit type name collision: " .. def.name)
    end
    local straw = wheat.windrowFillType
    local originalStrawFruit = straw and manager.fillTypeIndexToFruitTypeIndex[straw.index]
    local xml = loadXMLFile("wvFruitTypes", WV.state.fruitTypesFilename)
    assert(xml and xml ~= 0, "Generated fruitTypes XML failed to load")
    local ok, result = pcall(manager.loadFruitTypes, manager, xml, missionInfo, "", false)
    delete(xml)
    -- Preserve whichever crop the map originally used for shared straw lookup.
    if straw then manager.fillTypeIndexToFruitTypeIndex[straw.index] = originalStrawFruit end
    assert(ok, result)
    for _, def in ipairs(WV.definitions) do
        local fruit = assert(manager:getFruitTypeByName(def.name), "Fruit type not registered: " .. def.name)
        WV.state.fruits[def.name] = fruit
        assert(fruit.fillType and fruit.fillType.index == WV.state.fills[def.name].index, "Crop/grain identity mismatch")
        fruit.useForFieldMissions = false
        -- Provisional crop registration is not proof that a terrain layer exists.
        -- Keep fruit flags disabled until CURRENT_MISSION_START validates both
        -- layers; provisional seeder lists retain stable save/network ordering.
        fruit.allowsSeeding = false
        for _, category in ipairs({"SOWINGMACHINE", "COMBINEHEADER"}) do
            local categoryIndex = manager.categories[category]
            if categoryIndex and WV.contains(manager.categoryIndexToFruitTypeIndex[categoryIndex], wheat.index) then
                if not WV.contains(manager.categoryIndexToFruitTypeIndex[categoryIndex], fruit.index) then
                    assert(manager:addFruitTypeToCategory(fruit.index, categoryIndex), "Cannot extend " .. category)
                end
            end
        end
        WV.log("Registered crop %s index=%d layer=%s file=%s", def.name, fruit.index, def.layerName, def.foliageFilename)
    end
    WV.state.fruitsLoaded = true
    WV.state.phase = "awaitingTerrain"
end

function Registration.validateTerrain()
    local valid = WV.state.fruitsLoaded == true and #WV.state.errors == 0
    local planes = {}
    local wheat = g_fruitTypeManager and g_fruitTypeManager:getFruitTypeByName("WHEAT")
    if wheat and wheat.terrainDataPlaneId then
        planes[#planes + 1] = { plane = wheat.terrainDataPlaneId, index = WV.state.terrainIndices and WV.state.terrainIndices.WHEAT }
    end
    for _, def in ipairs(WV.definitions) do
        local fruit = WV.state.fruits[def.name]
        local plane = fruit and fruit.terrainDataPlaneId
        local densityIndex = WV.state.terrainIndices and WV.state.terrainIndices[def.name]
        -- The documented setter is observed, rather than assuming an internal
        -- property name for the type index. Unique plane handles also suffice.
        local good = type(plane) == "number" and plane > 0 and type(fruit.numStateChannels) == "number" and fruit.numStateChannels > 0
            and g_fruitTypeManager:getFruitTypeByName(def.name) == fruit
        for _, previous in ipairs(planes) do
            if previous.plane == plane and (densityIndex == nil or previous.index == nil or densityIndex == previous.index) then good = false end
        end
        if good then planes[#planes + 1] = { plane = plane, index = densityIndex } else valid = false end
        WV.log("Terrain %s plane=%s typeIndex=%s valid=%s", def.name, tostring(plane), tostring(densityIndex), tostring(good))
    end
    WV.state.ready = valid
    for _, fruit in pairs(WV.state.fruits) do
        fruit.allowsSeeding, fruit.shownOnMap = valid, valid
    end
    if valid then
        WV.state.phase = "ready"
        WV.log("READY: both varieties have distinct terrain identities. Verify growth, harvest and save/reload in-game.")
    else
        WV.fail("TERRAIN_NOT_READY: varieties disabled. Registration alone did not establish two usable terrain layers. See generated XML and preceding engine foliage errors.")
    end
    return valid
end
