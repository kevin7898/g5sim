-- Optional read-only integrations. Missing data is explicitly neutral, never dry.
RSSoilConditions = {}
local S=RSSoilConditions
local M=RSPlacementModel
local function call(object,name,...)
    if not object or type(object[name])~="function" then return nil end
    local ok,value=pcall(object[name],object,...)
    if ok then return value end
end
local function valid(value,hi)
    return M.finite(value) and value>=0 and value<=hi
end
function S.sample(x,z)
    local out={moistureSource="unavailable",compactionSource="unavailable"}
    if not M.finite(x) or not M.finite(z) then return out end
    local mission=g_currentMission
    if not mission then return out end
    -- SCS uses farmland IDs, not displayed field numbers.
    -- Prefer the native farmland map lookup over a polygon search each work tick.
    local farmland=call(g_farmlandManager,"getFarmlandAtWorldPosition",x,z)
    if not farmland then
        local field=call(g_fieldManager,"getFieldAtWorldPosition",x,z)
        farmland=field and field.farmland
    end
    local fieldId=farmland and farmland.id
    if valid(fieldId,2147483647) and fieldId>0 then
        out.farmlandId=fieldId
        local moisture=call(mission.cropStressManager,"getMoisture",fieldId,x,z)
        if valid(moisture,1) then out.moisture=moisture;out.moistureSource="SeasonalCropStress" end
    end
    -- The installed SF public delegate accepts semantic value-map keys, including compaction.
    local compaction=call(mission.soilFertilityManager,"getSoilValueAtWorld","compaction",x,z)
    if valid(compaction,100) then
        out.compaction=compaction/100;out.compactionSource="SoilFertilizer"
    end
    return out
end
