-- Generic simulation kits, inspired by real staged hardware. Prices are gameplay values.
local T=RSTechnology
T.modules[4].extra={{id='rowDrive',title='Individual row drive + cab rate',planter=12000,caps={'cabRateControl','rowDrive'},rows=true}}
local additions={
 {name='rsPrecisionMeter',title='Precision meter / feed',capability='precisionMeter',planter=4500,drill=2500},
 {name='rsDownforce',title='Opener downforce',capability='cabDownforceControl',options={
  {id='cab',title='Cab-adjustable pressure',planter=3500,drill=4000,caps={'cabDownforceControl'}},
  {id='sensed',title='Cab control + load sensing',planter=6000,drill=6500,caps={'cabDownforceControl','downforceSensor'}},
  {id='automatic',title='Automatic downforce system',planter=14000,drill=12000,caps={'cabDownforceControl','downforceSensor','automaticDownforce'}}}},
 {name='rsClosing',title='Closing / packing system',capability='improvedClosing',options={
  {id='manual',title='Improved manual closing / packing',planter=3000,drill=2500,caps={'improvedClosing'}},
  {id='sensed',title='Improved system + load sensing',planter=5000,drill=4500,caps={'improvedClosing','closingSensor'}},
  {id='automatic',title='Automatic closing / packing system',planter=10000,drill=9000,caps={'improvedClosing','closingSensor','cabClosingControl','automaticClosing'}}}},
 {name='rsDepthControl',title='Depth adjustment',capability='cabDepthControl',planter=9000,drill=7000,
  description='Powered depth actuator. Add soil sensing to enable modeled soil-adaptive control.'},
 {name='rsSoilSensor',title='Seed-zone soil sensing',capability='soilSensor',planter=4500,drill=3500,
  description='Reports available modeled soil conditions. Sensing alone cannot change adjustments.'},
 {name='rsSeedDelivery',title='Controlled seed delivery',capability='controlledDeliveryHardware',planter=8500,kind='planter',
  description='Requires precision meter AND powered metering to operate. Corn, soybeans, cotton and sugarbeets.'},
 {name='rsRowCleanerControl',title='Row cleaner display interface',capability='rowCleanerDisplayControl',planter=1800,kind='planter',cleaners=true,
  description='Fit recognized air-adjust row cleaners first. Adds display control; existing machine control is retained.'}}
for _,m in ipairs(additions) do T.modules[#T.modules+1]=m end
T.capabilities={}
for _,m in ipairs(T.modules) do
 T.capabilities[m.capability]=true
 for _,o in ipairs(m.options or m.extra or {}) do for _,cap in ipairs(o.caps) do T.capabilities[cap]=true end end
end
function T.options(m,kind,factory)
 local out={}
 if m.kind and m.kind~=kind or m.cleaners and not (factory.recognizedCleanerOptions or factory.rowCleanerCabAdjustment) then return out end
 local function add(o)
  if not o[kind] or o.rows and (kind~='planter' or (factory.rowCount or 0)<1) then return end
  local complete=true;for _,cap in ipairs(o.caps) do if not factory[cap] then complete=false end end
  if not complete then out[#out+1]=o end
 end
 for _,o in ipairs(m.options or {{id='retrofit',title='Aftermarket retrofit',planter=m.planter,drill=m.drill,caps={m.capability}}}) do add(o) end
 for _,o in ipairs(m.extra or {}) do add(o) end
 return out
end
