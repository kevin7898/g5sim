-- ProBoxAutoStoreItems.lua
-- Built-in optional ProBox integration for FieldPath RealisticSeeder.
-- This file does not ship or copy any ProBox assets. It only loads our small
-- generated ProBox wrapper XML entries when the matching original ProBox mod is installed.

RealisticSeederProBoxAutoStoreItems = RealisticSeederProBoxAutoStoreItems or {}

-- g_currentModDirectory is only reliable while this source file is being loaded.
-- Store-item registration happens later in loadMap(), so capture it here.
RealisticSeederProBoxAutoStoreItems.modDirectory = g_currentModDirectory or ""
RealisticSeederProBoxAutoStoreItems.modName = g_currentModName or "FS25_RealisticSeeder"

RealisticSeederProBoxAutoStoreItems.realisticModName = "FS25_LAC_SeedProBoxPackRealisticPricing"
RealisticSeederProBoxAutoStoreItems.standardModName  = "FS25_LAC_SeedProBoxPackStandardPricing"
RealisticSeederProBoxAutoStoreItems.crossplayModName = "FS25_SeedProBox_Crossplay"
RealisticSeederProBoxAutoStoreItems.seedFiles = {
    "probox_maize.xml",
    "probox_soybean.xml",
    "probox_wheat.xml",
    "probox_barley.xml",
    "probox_oat.xml",
    "probox_canola.xml",
    "probox_sorghum.xml",
    "probox_sunflower.xml",
    "probox_cotton.xml",
    "probox_potato.xml",
    "probox_sugarbeet.xml",
    "probox_beetroot.xml",
    "probox_carrot.xml",
    "probox_onion.xml",
    "probox_parsnip.xml",
    "probox_grass.xml",
    "probox_alfalfa.xml",
    "probox_clover.xml",
    "probox_oilseedradish.xml"
}

local function fpRsHasMod(modName)
    if g_modIsLoaded ~= nil and g_modIsLoaded[modName] ~= nil then
        return g_modIsLoaded[modName] == true
    end
    if g_modManager ~= nil and g_modManager.getModByName ~= nil then
        return g_modManager:getModByName(modName) ~= nil
    end
    return false
end

local function fpRsWriteFile(path, text)
    local file = io.open(path, "w")
    if file ~= nil then
        file:write(text)
        file:close()
        return true
    end
    return false
end

local function fpRsEscapeJson(value)
    value = tostring(value or "")
    value = value:gsub('\\', '\\\\')
    value = value:gsub('"', '\\"')
    return value
end

function RealisticSeederProBoxAutoStoreItems:getSettingsChoice(realisticInstalled, standardInstalled)
    -- FS25 only allows io.open write mode from Lua, so do not try to read a
    -- FieldPath settings JSON here. FieldPath can still read the status file
    -- and the selected mode can be handled on the FieldPath side.
    -- Auto mode: prefer realistic if present, otherwise standard.
    if realisticInstalled then
        return "realistic"
    elseif standardInstalled then
        return "standard"
    end
    return "none"
end

function RealisticSeederProBoxAutoStoreItems:tryLoadStoreItem(xmlFilename)
    -- GIANTS store manager APIs have shifted between game versions. Keep this defensive:
    -- try common function shapes, never crash the game if one is unavailable.
    if g_storeManager == nil then
        return false, "g_storeManager_missing"
    end

    local modDir = self.modDirectory or g_currentModDirectory or ""
    local modName = self.modName or g_currentModName or "FS25_RealisticSeeder"
    local fullPath = xmlFilename
    if Utils ~= nil and Utils.getFilename ~= nil then
        fullPath = Utils.getFilename(xmlFilename, modDir)
    elseif modDir ~= nil and modDir ~= "" then
        fullPath = modDir .. xmlFilename
    end

    -- Important: pass the mod-relative XML path to store-manager APIs where possible.
    -- Passing a resolved full path plus modDir can make FS25 prepend the mod directory twice.
    local storeXml = xmlFilename
    local fpUnpack = unpack or (table ~= nil and table.unpack)
    if fpUnpack == nil then
        return false, "unpack_missing"
    end

    local attempts = {
        { name = "loadItem_xml_modDir_modName_true", fn = g_storeManager.loadItem, args = {g_storeManager, storeXml, modDir, modName, true} },
        { name = "loadItem_fullPath_modDir_modName_true", fn = g_storeManager.loadItem, args = {g_storeManager, fullPath, modDir, modName, true} },
        { name = "loadStoreItem_xml_modDir_modName_true", fn = g_storeManager.loadStoreItem, args = {g_storeManager, storeXml, modDir, modName, true} },
    }

    local lastError = "no_supported_store_loader"
    for _, attempt in ipairs(attempts) do
        if attempt.fn ~= nil then
            local ok, result = pcall(attempt.fn, fpUnpack(attempt.args))
            if ok and result ~= false and result ~= nil then
                return true, attempt.name
            end
            if not ok then
                lastError = attempt.name .. ":" .. tostring(result)
            else
                lastError = attempt.name .. ":returned_" .. tostring(result)
            end
        end
    end

    if StoreItemUtil ~= nil and StoreItemUtil.loadStoreItem ~= nil then
        local ok, result = pcall(StoreItemUtil.loadStoreItem, storeXml, modDir, modName, true)
        if ok and result ~= false and result ~= nil then
            return true, "StoreItemUtil.loadStoreItem"
        end
        if not ok then
            lastError = "StoreItemUtil.loadStoreItem:" .. tostring(result)
        else
            lastError = "StoreItemUtil.loadStoreItem:returned_" .. tostring(result)
        end
    end

    return false, lastError
end

function RealisticSeederProBoxAutoStoreItems:loadSelectedPack(pack)
    local prefix = "xml/proboxCompat/" .. pack .. "/"
    local loaded = 0
    local failed = 0
    local lastReason = ""

    for _, fileName in ipairs(self.seedFiles) do
        local ok, reason = self:tryLoadStoreItem(prefix .. fileName)
        if ok then
            loaded = loaded + 1
        else
            failed = failed + 1
            lastReason = tostring(reason)
        end
    end

    print(string.format("[RealisticSeeder] ProBox auto compat: pack=%s loaded=%d failed=%d lastReason=%s", tostring(pack), loaded, failed, tostring(lastReason)))
    return loaded, failed, lastReason
end

function RealisticSeederProBoxAutoStoreItems:loadMap()
    local realisticInstalled = fpRsHasMod(self.realisticModName)
    local standardInstalled = fpRsHasMod(self.standardModName)
    local crossplayInstalled = fpRsHasMod(self.crossplayModName)
    local selectedPack = self:getSettingsChoice(realisticInstalled, standardInstalled)

    local loaded, failed, lastReason = 0, 0, "native_product_selector_hook_mode"
    if crossplayInstalled and selectedPack == "none" then
        lastReason = "FS25_SeedProBox_Crossplay detected, but native selector hook currently supports the LAC realistic/standard ProBox vehicle type only"
    end

    -- v0.1.0.28: Do not add separate ProBox wrapper store entries by default.
    -- Instead, ProBoxProductSelectionHook maps the original ProBox Products selector
    -- to RealisticSeeder crop-specific seed fill types after purchase/load. This
    -- keeps the original ProBox store item, brand selector, labels, textures, and
    -- model intact without redistributing ProBox assets.
    print("[RealisticSeeder] ProBox wrapper store entries disabled: using original ProBox product selector hook")
    print(string.format("[RealisticSeeder] ProBox detected: realistic=%s standard=%s crossplay=%s selected=%s loaded=%d failed=%d", tostring(realisticInstalled), tostring(standardInstalled), tostring(crossplayInstalled), tostring(selectedPack), loaded, failed))

    if getUserProfileAppPath ~= nil and createFolder ~= nil then
        local dir = getUserProfileAppPath() .. "modSettings/FS25_FieldPathCommand"
        createFolder(dir)
        fpRsWriteFile(dir .. "/realisticSeederProBoxCompat.json", string.format(
            '{"realisticOriginal":%s,"standardOriginal":%s,"crossplayOriginal":%s,"selectedPack":"%s","loadedStoreItems":%d,"failedStoreItems":%d,"lastReason":"%s","singleZipIntegration":true,"redistributesProBoxAssets":false}',
            tostring(realisticInstalled), tostring(standardInstalled), tostring(crossplayInstalled), fpRsEscapeJson(selectedPack), loaded, failed, fpRsEscapeJson(lastReason)))

        -- Write a safe default settings file. FS25 Lua does not allow read-mode
        -- io.open, so this file is intentionally write-only from the mod side.
        -- FieldPath can own user edits and write the selected mode later.
        fpRsWriteFile(dir .. "/realisticSeederProBoxSettings.json", '{"schema":1,"pricingPack":"auto","notes":"pricingPack can be auto, realistic, or standard. FieldPath may change this when both ProBox packs are installed."}')
    end
end

addModEventListener(RealisticSeederProBoxAutoStoreItems)
