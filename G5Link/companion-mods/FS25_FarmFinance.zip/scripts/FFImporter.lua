-- FS25_FarmFinance - one-time import from UsedPlus and Enhanced Loan System.
--
-- Runs on the server the first time a save loads with Farm Finance and
-- without the old mod. It only reads the old files; it never changes them.
--   UsedPlus usedPlus.xml:
--     finance deals (dealType 1)  -> loans with the same balance, rate, months
--     vehicle leases (dealType 2) -> ownership loans (remaining payments plus
--                                    residual, at the lease rate)
--     land leases (dealType 3)    -> yearly cash leases at the region rate
--     payment tracker             -> starting payment history
--   ELS els_loans.xml: unpaid loans -> loans with the same balance and rate.
-- A UsedPlus cash loan is written into the vanilla loan, which ELS then
-- copies into an ELS loan. Such duplicates are imported once.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local LM = FF.LoanMath

FF.Importer = {}
local I = FF.Importer

I.cashLoanByFarm = {}

local function report(key, ...)
    table.insert(FF.state.importReport, U.text(key, ...))
end

local function getNumber(xmlFile, key)
    return U.toNumber(xmlFile:getString(key), nil)
end

function I.isModActive(prefix)
    if g_modIsLoaded == nil then
        return false
    end
    for modName, loaded in pairs(g_modIsLoaded) do
        if loaded == true and U.startsWith(modName, prefix) then
            return true
        end
    end
    return false
end

local function farmExists(farmId)
    return g_farmManager ~= nil and g_farmManager:getFarmById(farmId) ~= nil
end

local function farmlandName(farmlandId)
    if FF.env ~= nil and FF.env.land ~= nil and FF.env.land.getName ~= nil then
        return FF.env.land.getName(farmlandId)
    end
    return tostring(farmlandId)
end

local function importFinanceDeal(farmId, xmlFile, key)
    local balance = getNumber(xmlFile, key .. "#currentBalance") or 0
    if balance <= 0.5 then
        return
    end
    local itemType = xmlFile:getString(key .. "#itemType") or "vehicle"
    local rate = (getNumber(xmlFile, key .. "#interestRate") or 0) / 100
    local termMonths = xmlFile:getInt(key .. "#termMonths") or 12
    local monthsPaid = xmlFile:getInt(key .. "#monthsPaid") or 0
    local months = math.max(termMonths - monthsPaid, 1)
    local payment = getNumber(xmlFile, key .. "#monthlyPayment")
    local name = xmlFile:getString(key .. "#itemName") or itemType

    local productId = "equipment"
    if itemType == "land" then
        productId = "realEstate"
        name = U.text("ff_label_farmland", name)
    elseif itemType == "loan" or itemType == "cash" then
        productId = "imported"
        I.cashLoanByFarm[farmId] = (I.cashLoanByFarm[farmId] or 0) + balance
        FF.state.importCashLoans = FF.state.importCashLoans or {}
        table.insert(FF.state.importCashLoans, getNumber(xmlFile, key .. "#amountFinanced") or balance)
    elseif itemType == "placeable" then
        productId = "realEstate"
    end
    if payment == nil or payment <= 0 then
        payment = LM.payment(balance, rate, months)
    end

    FF.Bank.createLoan(farmId, {
        productId = productId,
        balance = balance,
        amount = getNumber(xmlFile, key .. "#amountFinanced") or balance,
        months = months,
        monthsTotal = termMonths,
        rate = rate,
        payment = payment,
        source = "usedPlus",
        label = name,
        noDisbursement = true
    })
    report("ff_import_usedPlusLoan", name, U.money(balance), U.percent(rate), months)
end

local function importVehicleLease(farmId, xmlFile, key)
    local termMonths = xmlFile:getInt(key .. "#termMonths") or 12
    local monthsPaid = xmlFile:getInt(key .. "#monthsPaid") or 0
    local months = math.max(termMonths - monthsPaid, 1)
    local rate = (getNumber(xmlFile, key .. "#interestRate") or 0) / 100
    local monthly = getNumber(xmlFile, key .. "#monthlyPayment") or 0
    local residual = getNumber(xmlFile, key .. "#residualValue") or 0
    local name = xmlFile:getString(key .. "#vehicleName") or "?"

    local balance = LM.principalForPayment(monthly, rate, months) + LM.presentValue(residual, rate, months)
    if balance <= 0.5 then
        return
    end
    FF.Bank.createLoan(farmId, {
        productId = "equipment",
        balance = balance,
        amount = balance,
        months = months,
        rate = rate,
        source = "usedPlus",
        label = U.text("ff_label_leaseConverted", name),
        noDisbursement = true
    })
    report("ff_import_usedPlusLease", name, U.money(balance), months)
end

local function importLandLease(farmId, xmlFile, key)
    local farmlandId = xmlFile:getInt(key .. "#farmlandId")
    if farmlandId == nil then
        return
    end
    local oldMonthly = getNumber(xmlFile, key .. "#monthlyPayment") or 0
    local name = farmlandName(farmlandId)
    local owner = g_farmlandManager ~= nil and g_farmlandManager:getFarmlandOwner(farmlandId) or nil
    if owner ~= farmId then
        report("ff_import_landSkipped", name)
        return
    end
    if FF.Land.getContractByFarmland(farmlandId) ~= nil then
        return
    end
    local rent = FF.Land.marketRent(farmlandId)
    FF.Land.adoptRentIn(farmId, farmlandId, rent, "usedPlus")
    report("ff_import_usedPlusLand", name, U.money(oldMonthly * 12), U.money(rent))
end

function I.importUsedPlus(filename)
    local xmlFile = XMLFile.load("ffImportUsedPlus", filename)
    if xmlFile == nil then
        U.warn("could not read %s", filename)
        return false
    end
    local count = 0
    xmlFile:iterate("usedPlus.farms.farm", function(_, farmKey)
        local farmId = xmlFile:getInt(farmKey .. "#farmId")
        if farmId ~= nil and farmExists(farmId) then
            xmlFile:iterate(farmKey .. ".deal", function(_, key)
                local status = xmlFile:getString(key .. "#status") or "active"
                if status == "active" then
                    local dealType = xmlFile:getString(key .. "#dealType")
                    if dealType == "1" or dealType == "finance" then
                        importFinanceDeal(farmId, xmlFile, key)
                        count = count + 1
                    elseif dealType == "2" or dealType == "lease" then
                        importVehicleLease(farmId, xmlFile, key)
                        count = count + 1
                    elseif dealType == "3" or dealType == "land_lease" then
                        importLandLease(farmId, xmlFile, key)
                        count = count + 1
                    end
                end
            end)
        end
    end)

    xmlFile:iterate("usedPlus.paymentTracker.farm", function(_, farmKey)
        local farmId = xmlFile:getInt(farmKey .. "#farmId")
        if farmId ~= nil and farmExists(farmId) then
            local farm = FF.Bank.getFarm(farmId)
            local history = farm.history
            local statsKey = farmKey .. ".stats"
            history.onTime = (history.onTime or 0) + (xmlFile:getInt(statsKey .. "#onTimePayments") or 0)
            history.late = (history.late or 0) + (xmlFile:getInt(statsKey .. "#latePayments") or 0)
            history.missed = (history.missed or 0) + (xmlFile:getInt(statsKey .. "#missedPayments") or 0)
            history.streak = math.max(history.streak or 0, xmlFile:getInt(statsKey .. "#currentStreak") or 0)
            history.monthsOnRecord = math.max(history.monthsOnRecord or 0, xmlFile:getInt(statsKey .. "#totalPayments") or 0)
            report("ff_import_history", farmId, xmlFile:getInt(statsKey .. "#onTimePayments") or 0)
        end
    end)

    xmlFile:delete()
    U.log("imported %d UsedPlus deal(s)", count)
    return true
end

local function isDuplicateOfCashLoan(amount)
    for index, cashAmount in ipairs(FF.state.importCashLoans or {}) do
        if math.abs(cashAmount - amount) < 1 then
            table.remove(FF.state.importCashLoans, index)
            return true
        end
    end
    return false
end

function I.importEls(filename)
    local xmlFile = XMLFile.load("ffImportEls", filename)
    if xmlFile == nil then
        U.warn("could not read %s", filename)
        return false
    end
    local count = 0
    xmlFile:iterate("loans.farmId", function(_, farmKey)
        local farmId = xmlFile:getInt(farmKey .. "#farmId")
        if farmId ~= nil and farmExists(farmId) then
            xmlFile:iterate(farmKey .. ".loan", function(_, key)
                local paidOff = xmlFile:getBool(key .. "#paidOff")
                local balance = getNumber(xmlFile, key .. "#restAmount") or 0
                if not paidOff and balance > 0.5 then
                    local amount = getNumber(xmlFile, key .. "#amount") or balance
                    if isDuplicateOfCashLoan(amount) then
                        report("ff_import_elsDuplicate", U.money(amount))
                    else
                        local rate = (getNumber(xmlFile, key .. "#interest") or 0) / 100
                        local months = math.max(xmlFile:getInt(key .. "#restDuration") or 1, 1)
                        FF.Bank.createLoan(farmId, {
                            productId = "imported",
                            balance = balance,
                            amount = amount,
                            months = months,
                            rate = rate,
                            source = "els",
                            label = U.text("ff_label_elsLoan"),
                            noDisbursement = true
                        })
                        report("ff_import_elsLoan", U.money(balance), U.percent(rate), months)
                        count = count + 1
                    end
                end
            end)
        end
    end)
    xmlFile:delete()
    U.log("imported %d ELS loan(s)", count)
    return true
end

-- FieldLeasing (Chissel): fieldLeasingAgreements.xml. The leased land is the
-- farm's in the game; it becomes a yearly cash lease at the region rate.
function I.importFieldLeasing(filename)
    local xmlFile = XMLFile.load("ffImportFieldLeasing", filename)
    if xmlFile == nil then
        return 0
    end
    local multiplier = U.toNumber(xmlFile:getString("fieldLeasingAgreements#priceMultiplier"), 1) or 1
    local count = 0
    xmlFile:iterate("fieldLeasingAgreements.fieldLeaseAgreement", function(_, key)
        local farmlandId = xmlFile:getInt(key .. "#farmlandId")
        local farmId = xmlFile:getInt(key .. "#farmId")
        if farmlandId ~= nil and farmId ~= nil and farmExists(farmId) and FF.Land.getContractByFarmland(farmlandId) == nil then
            local name = farmlandName(farmlandId)
            local owner = g_farmlandManager ~= nil and g_farmlandManager:getFarmlandOwner(farmlandId) or nil
            if owner ~= farmId then
                report("ff_import_landSkipped", name)
            else
                local oldYearly = (getNumber(xmlFile, key .. "#price") or 0) * multiplier / 100
                local rent = FF.Land.marketRent(farmlandId)
                FF.Land.adoptRentIn(farmId, farmlandId, rent, "fieldLeasing")
                report("ff_import_fieldLeasing", name, U.money(oldYearly), U.money(rent))
                count = count + 1
            end
        end
    end)
    xmlFile:delete()
    U.log("imported %d FieldLeasing lease(s)", count)
    return count
end

-- Rent Your Field (NYKK3): rentYourFieldAgreements.xml. The land is unowned
-- in the game while rented out; it becomes a Farm Finance rent-out lease.
function I.importRentYourField(filename)
    local xmlFile = XMLFile.load("ffImportRentYourField", filename)
    if xmlFile == nil then
        return 0
    end
    local count = 0
    xmlFile:iterate("rentYourFieldAgreements.rentAgreement", function(_, key)
        local farmlandId = xmlFile:getInt(key .. "#farmlandId")
        local farmId = xmlFile:getInt(key .. "#farmId")
        if farmlandId ~= nil and farmId ~= nil and farmExists(farmId) and FF.Land.getContractByFarmland(farmlandId) == nil then
            local name = farmlandName(farmlandId)
            local owner = g_farmlandManager ~= nil and g_farmlandManager:getFarmlandOwner(farmlandId) or nil
            if owner ~= (FarmlandManager ~= nil and FarmlandManager.NO_OWNER_FARM_ID or 0) then
                report("ff_import_landSkipped", name)
            else
                local rent = math.floor(FF.Land.marketRent(farmlandId) * FF.Region.get("land.rentOutFactor", 0.95) + 0.5)
                FF.Land.adoptRentOut(farmId, farmlandId, rent, "rentYourField")
                report("ff_import_rentYourField", name, U.money(rent))
                count = count + 1
            end
        end
    end)
    xmlFile:delete()
    U.log("imported %d Rent Your Field lease(s)", count)
    return count
end

-- Each source: the mod that wrote it, its file, the importer and a header.
I.SOURCES = {
    {id = "usedPlus", mod = "FS25_UsedPlus", file = "usedPlus.xml", header = "ff_import_header_usedPlus"},
    {id = "els", mod = "FS25_EnhancedLoanSystem", file = "els_loans.xml", header = "ff_import_header_els"},
    {id = "fieldLeasing", mod = "FS25_FieldLeasing", file = "fieldLeasingAgreements.xml", header = "ff_import_header_fieldLeasing"},
    {id = "rentYourField", mod = "FS25_RentYourField", file = "rentYourFieldAgreements.xml", header = "ff_import_header_rentYourField"}
}

local function runSource(source, filename)
    if source.id == "usedPlus" then
        I.importUsedPlus(filename)
    elseif source.id == "els" then
        I.importEls(filename)
    elseif source.id == "fieldLeasing" then
        I.importFieldLeasing(filename)
    elseif source.id == "rentYourField" then
        I.importRentYourField(filename)
    end
end

-- Returns true when something was imported. A source is only read when its
-- mod is not active in this save, and only once per save.
function I.run(directory)
    if directory == nil or FF.state == nil then
        return false
    end
    local s = FF.state
    local changed = false
    for _, source in ipairs(I.SOURCES) do
        if not s.imported[source.id] and not I.isModActive(source.mod) then
            local filename = directory .. "/" .. source.file
            if fileExists(filename) then
                local headerIndex = #s.importReport + 1
                table.insert(s.importReport, U.text(source.header))
                local before = #s.importReport
                runSource(source, filename)
                if #s.importReport == before then
                    -- nothing imported from this source: drop the empty header
                    table.remove(s.importReport, headerIndex)
                else
                    changed = true
                end
                s.imported[source.id] = true
            end
        end
    end
    return changed
end

-- The vanilla loan, minus what UsedPlus had mirrored into it.
function I.getVanillaRemainder(farmId, vanillaLoan)
    local mirrored = I.cashLoanByFarm[farmId] or 0
    return math.max((vanillaLoan or 0) - mirrored, 0)
end

return I
