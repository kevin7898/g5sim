local Guard = {}
local modName = "FS25_Courseplay"
local supportedVersion = "8.1.0.3"
local prefix = "[Courseplay Route Guard] "

local classNames = {
    "AIDriveStrategyFieldWorkCourse",
    "AIDriveStrategyCombineCourse",
    "AIDriveStrategyPlowCourse",
    "AIDriveStrategyVineFieldWorkCourse"
}

local callbacks = {
    {name = "onPathfindingFailedToNextWaypoint", route = "next waypoint"},
    {name = "onPathfindingDoneToNextWaypoint", route = "next waypoint", completion = true},
    {name = "onPathfindingFailedToConnectingPathEnd", route = "connecting path"},
    {name = "onPathfindingDoneToConnectingPathEnd", route = "connecting path", completion = true}
}

local function stopWorker(strategy, route)
    if strategy.routeGuardStopped then
        return
    end
    strategy.routeGuardStopped = true

    local vehicle = strategy.vehicle
    local x, _, z = getWorldTranslation(vehicle.rootNode)
    local course = strategy.fieldWorkCourse
    local waypoint = course and course:getCurrentWaypointIx()
    print(string.format("%sStopping %s at x=%.1f z=%.1f, fieldwork waypoint %s. No collision-checked route for %s.",
        prefix, vehicle:getName(), x, z, tostring(waypoint), route))
    vehicle:stopCurrentAIJob(AIMessageErrorNotReachable.new())
end

local function wrap(installation, callback, original)
    return function(strategy, controller, ...)
        if not installation.active then
            return original(strategy, controller, ...)
        end
        if strategy.routeGuardStopped then
            return
        end
        if callback.completion then
            local success, course = ...
            if success and course then
                return original(strategy, controller, ...)
            end
        end
        stopWorker(strategy, callback.route)
    end
end

function Guard:loadMap()
    local mission = g_currentMission
    if self.installation or not mission or not mission:getIsServer()
            or (mission.missionDynamicInfo and mission.missionDynamicInfo.isMultiplayer) then
        return
    end

    local mod = g_modManager:getModByName(modName)
    if not mod or mod.version ~= supportedVersion then
        print(prefix .. "Inactive. Requires Courseplay " .. supportedVersion .. ".")
        return
    end

    local cp = _G[modName]
    local patches = {}
    local installation = {active = true, patches = patches}
    for _, className in ipairs(classNames) do
        local class = cp and cp[className]
        for _, callback in ipairs(callbacks) do
            local original = class and class[callback.name]
            if type(original) ~= "function" then
                print(prefix .. "Inactive. Missing " .. className .. "." .. callback.name .. ".")
                return
            end
            patches[#patches + 1] = {
                class = class,
                name = callback.name,
                original = original,
                wrapped = wrap(installation, callback, original)
            }
        end
    end

    for _, patch in ipairs(patches) do
        patch.class[patch.name] = patch.wrapped
    end
    self.installation = installation
    print(prefix .. "Active for Courseplay " .. supportedVersion .. ".")
end

function Guard:deleteMap()
    local installation = self.installation
    if not installation then
        return
    end
    installation.active = false
    for _, patch in ipairs(installation.patches) do
        if patch.class[patch.name] == patch.wrapped then
            patch.class[patch.name] = patch.original
        end
    end
    self.installation = nil
end

addModEventListener(Guard)
