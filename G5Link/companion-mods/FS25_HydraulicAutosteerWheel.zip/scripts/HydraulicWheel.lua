--[[
    FS25_HydraulicAutosteerWheel
    Emulates real-world hydraulic (orbitrol valve) autosteer on a physical wheel.

    Real tractor behaviour being copied:
      * While autosteer drives, the steering wheel does not turn. It stays wherever
        the operator left it.
      * The moment the operator takes over, the wheel's position simply *is* the
        current front-wheel angle. There is no fixed centre on a hydraulic system.
      * Turning the wheel a little disengages autosteer (wheel-motion sensor).

    How it is done here:
      * The physical wheel's raw angle (rawDeg) is mapped to the game's steering
        axis with a movable centre:   axis = (rawDeg - centerDeg) / (rangeDeg / 2)
      * While autosteer is engaged, centerDeg is recomputed every frame so that
        "wheel where it was at engagement" == "tractor's current wheel angle".
        On takeover there is therefore no jump: the tractor keeps the angle the
        autosteer last had, and your input steers relative to it.
      * The end stops are walls at centerDeg +/- rangeDeg/2. Those are drawn by
        the Fanatec companion app (precise, firmware-level), or experimentally
        by the game's own force-feedback output (wallMode = "game").

    Settings: <userProfile>/modSettings/FS25_HydraulicAutosteerWheel.xml
]]

HydraulicWheel = {}
HydraulicWheel.MOD_NAME = g_currentModName
HydraulicWheel.MOD_DIR = g_currentModDirectory
HydraulicWheel.STATE_VERSION = "HAW3"

HydraulicWheel.DEFAULTS = {
    hardwareLockDeg    = 2520,        -- lock-to-lock the DD base is set to (its max). Fixed symmetric lock; the walls move inside it.
    steeringRangeDeg   = 900,         -- lock-to-lock rotation you want for the tractor
    disengageDeg       = 10,          -- wheel movement that disengages autosteer
    disengageGraceMs   = 300,         -- ignore wheel movement right after engaging
    invertVehicleSteer = false,       -- flip if the tractor turns the wrong way after takeover
    wallMode           = "companion", -- "companion" | "game" | "off"
    gameWallForce      = 1.0,         -- only for wallMode="game" (0..1)
    hydraulicFeel      = true,        -- suppress the game's self-centering FFB (real hydraulic steering does not self-centre the wheel)
    -- Autosteer style:
    --   "hydraulic": factory hydraulic autosteer. Wheel stays still while it steers.
    --   "electric" : aftermarket motor on the steering wheel (EZ-Pilot style). The wheel turns
    --                with every correction; holding/turning it against the motor disengages.
    autosteerStyle     = "hydraulic",
    electricOverrideDeg = 20,         -- electric: how far you can hold the wheel off the motor's position before it disengages
    -- Drift control (hydraulic style; electric style does not drift) (keeps the moving centre from walking off the end of the base)
    slipAtWalls        = true,        -- push past a stop and it slowly gives way, like an orbitrol at full lock
    slipStartDeg       = 2,           -- how far past the stop before it starts to give (companion reaches full stop force at 4)
    slipRatePerDeg     = 15,          -- deg/s of slip per degree pushed beyond slipStartDeg
    slipMaxDegPerSec   = 120,
    reindexWhileEngaged = true,       -- while autosteer drives, unwind the wheel if the centre has drifted too far
    reindexKeepDeg     = 360,         -- centre offset that is left alone (wheel stays perfectly still below this)
    reindexDoneDeg     = 30,          -- once re-indexing, carry on until the centre is this close to true centre
    reindexRateDegPerSec = 40,        -- how fast the motor turns the wheel while re-indexing
    debug              = false,
}

HydraulicWheel.cfg = {}
HydraulicWheel.centerDeg = 0
HydraulicWheel.lastRawDeg = nil
HydraulicWheel.vehicle = nil
HydraulicWheel.engaged = false
HydraulicWheel.engageTime = 0
HydraulicWheel.holdTargetDeg = 0       -- where the wheel is held/considered to rest while engaged
HydraulicWheel.reindexing = false
HydraulicWheel.holdActive = false
HydraulicWheel.holdFeed = 0
HydraulicWheel.centerClamped = false
HydraulicWheel.hookedDevices = {}
HydraulicWheel.hookFailedLogged = false
HydraulicWheel.stateSeq = 0
HydraulicWheel.lastStateWrite = -100000
HydraulicWheel.lastStateLine = ""

local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

local function log(fmt, ...)
    print(string.format("[HydraulicWheel] " .. fmt, ...))
end

function HydraulicWheel:dbg(fmt, ...)
    if self.cfg.debug then
        log(fmt, ...)
    end
end

---------------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------------

function HydraulicWheel:getSettingsDir()
    return getUserProfileAppPath() .. "modSettings/"
end

function HydraulicWheel:getSettingsPath()
    return self:getSettingsDir() .. "FS25_HydraulicAutosteerWheel.xml"
end

function HydraulicWheel:getStatePath()
    return self:getSettingsDir() .. "FS25_HydraulicAutosteerWheel_state.txt"
end

function HydraulicWheel:loadSettings()
    local d = HydraulicWheel.DEFAULTS
    local c = {}
    for k, v in pairs(d) do c[k] = v end

    createFolder(self:getSettingsDir())
    local path = self:getSettingsPath()
    local root = "hydraulicAutosteerWheel"

    local keys = {}
    for k in pairs(d) do table.insert(keys, k) end
    table.sort(keys)

    if fileExists(path) then
        local xml = loadXMLFile("HydraulicWheelSettings", path)
        if xml ~= nil and xml ~= 0 then
            for _, k in ipairs(keys) do
                local key = root .. "." .. k
                local t = type(d[k])
                local v
                if t == "number" then v = getXMLFloat(xml, key)
                elseif t == "boolean" then v = getXMLBool(xml, key)
                else v = getXMLString(xml, key) end
                if v ~= nil then c[k] = v end
            end
            delete(xml)
        end
    end

    self.cfg = c
    self:sanitizeSettings()
    -- (Re)write the file so new options appear with their current values.
    self:saveSettings()

    log("hardwareLock=%d deg, steeringRange=%d deg, centre can move +/-%d deg, wallMode=%s",
        c.hardwareLockDeg, c.steeringRangeDeg, self:getMaxCenterOffset(), c.wallMode)
end

function HydraulicWheel:sanitizeSettings()
    local c = self.cfg
    c.hardwareLockDeg = math.max(c.hardwareLockDeg, 90)
    c.steeringRangeDeg = clamp(c.steeringRangeDeg, 90, c.hardwareLockDeg)
    if c.autosteerStyle ~= "electric" then c.autosteerStyle = "hydraulic" end
    if c.wallMode ~= "game" and c.wallMode ~= "off" then c.wallMode = "companion" end
end

function HydraulicWheel:saveSettings()
    local d = HydraulicWheel.DEFAULTS
    local root = "hydraulicAutosteerWheel"
    local keys = {}
    for k in pairs(d) do table.insert(keys, k) end
    table.sort(keys)
    local xml = createXMLFile("HydraulicWheelSettings", self:getSettingsPath(), root)
    if xml ~= nil and xml ~= 0 then
        for _, k in ipairs(keys) do
            local key = root .. "." .. k
            local t = type(d[k])
            if t == "number" then setXMLFloat(xml, key, self.cfg[k])
            elseif t == "boolean" then setXMLBool(xml, key, self.cfg[k])
            else setXMLString(xml, key, tostring(self.cfg[k])) end
        end
        saveXMLFile(xml)
        delete(xml)
    end
end

-- Called by the in-game settings menu.
function HydraulicWheel:setSetting(key, value)
    if self.cfg[key] == value then return end
    self.cfg[key] = value
    self:sanitizeSettings()
    self:setCenter(self.centerDeg)     -- re-clamp in case the range or lock changed
    self:saveSettings()
    self:dbg("setting %s = %s", key, tostring(value))
end

---------------------------------------------------------------------------
-- Geometry helpers
---------------------------------------------------------------------------

function HydraulicWheel:getHalfRange()
    return self.cfg.steeringRangeDeg * 0.5
end

function HydraulicWheel:getHardwareHalf()
    return self.cfg.hardwareLockDeg * 0.5
end

-- How far the centre can move before a virtual wall would sit outside the base's hardware lock.
function HydraulicWheel:getMaxCenterOffset()
    return math.max(self:getHardwareHalf() - self:getHalfRange(), 0)
end

function HydraulicWheel:setCenter(centerDeg)
    local maxOff = self:getMaxCenterOffset()
    local clamped = clamp(centerDeg, -maxOff, maxOff)
    if clamped ~= centerDeg then
        if not self.centerClamped then
            log("Centre wanted %.0f deg but only +/-%.0f deg fits inside the %d deg hardware lock. Raise hardwareLockDeg for more room.",
                centerDeg, maxOff, self.cfg.hardwareLockDeg)
        end
        self.centerClamped = true
    else
        self.centerClamped = false
    end
    self.centerDeg = clamped
end

-- Tractor's current front-wheel angle in steering-axis units (-1..1),
-- using the same convention AIAutomaticSteering uses to turn rotTime into axisSide.
function HydraulicWheel:getVehicleSteerAxis(vehicle)
    local rt = vehicle.rotatedTime or 0
    local maxRot = vehicle.maxRotTime or 0
    local minRot = vehicle.minRotTime or 0
    local axis = 0
    if rt < 0 then
        if maxRot ~= 0 then axis = -rt / maxRot end
    else
        if minRot ~= 0 then axis = rt / minRot end
    end
    if self.cfg.invertVehicleSteer then
        axis = -axis
    end
    return clamp(axis, -1, 1)
end

function HydraulicWheel:isAutosteerEngaged(vehicle)
    local spec = vehicle.spec_aiAutomaticSteering
    return spec ~= nil and spec.steeringEnabled == true
end

function HydraulicWheel:rawToAxis(rawDeg)
    return clamp((rawDeg - self.centerDeg) / self:getHalfRange(), -1, 1)
end

-- Make the wheel's position at referenceRawDeg correspond to the vehicle's current wheel angle.
function HydraulicWheel:matchCenterToVehicle(vehicle, referenceRawDeg)
    if referenceRawDeg == nil then return end
    self:setCenter(referenceRawDeg - self:getVehicleSteerAxis(vehicle) * self:getHalfRange())
end

---------------------------------------------------------------------------
-- Engage / disengage
---------------------------------------------------------------------------

function HydraulicWheel:onEngage(vehicle)
    self.engaged = true
    self.engageTime = g_time
    self.holdTargetDeg = self.lastRawDeg or 0
    self.engageRawDeg = self.holdTargetDeg
    self.steerAtEngage = self:getVehicleSteerAxis(vehicle)
    self.reindexing = false
    -- Constant value fed to the game while engaged, so the base game's own
    -- "wheel moved > 0.1" check never fires. We do our own check in degrees.
    self.holdFeed = self:rawToAxis(self.holdTargetDeg)
    self:dbg("engaged at raw %.1f deg (centre %.1f)", self.holdTargetDeg, self.centerDeg)
end

function HydraulicWheel:onDisengage(vehicle)
    self.engaged = false
    self.reindexing = false
    self.holdActive = false
    -- centerDeg was kept matched while engaged, so nothing jumps here.
    self:dbg("disengaged, centre now %.1f deg", self.centerDeg)
end

---------------------------------------------------------------------------
-- Steering input hook
---------------------------------------------------------------------------

function HydraulicWheel:processSteerInput(vehicle, inputValue)
    local rawDeg = inputValue * self:getHardwareHalf()
    self.lastRawDeg = rawDeg

    if vehicle ~= self.vehicle then
        self:onVehicleChanged(vehicle)
    end

    if self:isAutosteerEngaged(vehicle) then
        if not self.engaged then
            self:onEngage(vehicle)
        end

        local moved = math.abs(rawDeg - self.holdTargetDeg)
        local electric = self:isElectric()
        local threshold
        if electric then
            threshold = self.cfg.electricOverrideDeg
        else
            -- the motor lags its target a few degrees while re-indexing, so allow extra margin then
            threshold = self.cfg.disengageDeg + (self.reindexing and 10 or 0)
        end
        if g_time - self.engageTime > self.cfg.disengageGraceMs and moved > threshold then
            -- Operator grabbed the wheel: hand control back.
            if electric then
                -- the wheel is mechanically linked: carry on from where it actually is, no jump
                self:matchCenterToVehicle(vehicle, rawDeg)
            else
                self:matchCenterToVehicle(vehicle, self.holdTargetDeg)
            end
            vehicle:setAIAutomaticSteeringEnabled(false)
            self:onDisengage(vehicle)
            -- fall through: the movement already made is applied as a steering change
        else
            return self.holdFeed
        end
    elseif self.engaged then
        self:onDisengage(vehicle)
    end

    return self:rawToAxis(rawDeg)
end

function HydraulicWheel:onVehicleChanged(vehicle)
    self.vehicle = vehicle
    self.engaged = false
    -- Getting into a tractor: wherever the wheel is now is where that tractor's wheels point.
    self:matchCenterToVehicle(vehicle, self.lastRawDeg)
    self:dbg("vehicle changed, centre %.1f deg", self.centerDeg)
end

function HydraulicWheel.installSteerHook()
    if Drivable == nil or Drivable.actionEventSteer == nil then
        log("ERROR: Drivable.actionEventSteer not found, mod inactive")
        return
    end
    local original = Drivable.actionEventSteer
    Drivable.actionEventSteer = function(self, actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory, binding)
        if isAnalog and not isMouse and deviceCategory ~= InputDevice.CATEGORY.KEYBOARD_MOUSE
            and deviceCategory ~= InputDevice.CATEGORY.GAMEPAD then
            local ok, mapped = pcall(HydraulicWheel.processSteerInput, HydraulicWheel, self, inputValue)
            if ok then
                inputValue = mapped
            else
                log("ERROR in steer hook: %s", tostring(mapped))
            end
        end
        return original(self, actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory, binding)
    end
    log("Steering hook installed")
end

---------------------------------------------------------------------------
-- Game force-feedback filter (translates the game's FFB to the moved centre,
-- removes self-centering for hydraulic feel, optionally draws the walls)
---------------------------------------------------------------------------

function HydraulicWheel:hookForceFeedback(vehicle)
    local spec = vehicle.spec_drivable
    local ff = spec ~= nil and spec.forceFeedback or nil
    if ff == nil or not ff.isActive or ff.device == nil then
        return
    end
    local device = ff.device
    if self.hookedDevices[device] then
        return
    end

    local ok, err = pcall(function()
        local original = device.setForceFeedback
        if type(original) ~= "function" then
            error("setForceFeedback is not a Lua function")
        end
        device.setForceFeedback = function(dev, axisIndex, force, targetState)
            local f, t = HydraulicWheel:filterForceFeedback(force, targetState)
            return original(dev, axisIndex, f, t)
        end
    end)

    if ok then
        self.hookedDevices[device] = true
        log("Game force-feedback output hooked")
    elseif not self.hookFailedLogged then
        self.hookFailedLogged = true
        log("Could not hook game force feedback (%s). Use the companion app for end stops and set in-game force feedback to 0.", tostring(err))
    end
end

function HydraulicWheel:filterForceFeedback(force, targetState)
    local hwHalf = self:getHardwareHalf()
    local half = self:getHalfRange()

    if self.cfg.hydraulicFeel or self.engaged then
        -- Hydraulic steering never drives the wheel, autosteer engaged or not.
        force = 0
    end

    -- Game target is in steering-axis units; convert to raw device units around the moved centre.
    local targetDeg = self.centerDeg + (targetState or 0) * half
    local rawTarget = clamp(targetDeg / hwHalf, -1, 1)

    if self.cfg.wallMode == "game" and self.lastRawDeg ~= nil then
        local upper = self.centerDeg + half
        local lower = self.centerDeg - half
        if self.lastRawDeg > upper then
            force = self.cfg.gameWallForce
            rawTarget = upper / hwHalf
        elseif self.lastRawDeg < lower then
            force = self.cfg.gameWallForce
            rawTarget = lower / hwHalf
        end
    end

    return force, rawTarget
end

---------------------------------------------------------------------------
-- State file for the Fanatec companion app
---------------------------------------------------------------------------

function HydraulicWheel:writeState(active, force)
    if self.cfg.wallMode ~= "companion" then
        return
    end
    local hold = active and self.engaged and self.holdActive
    local line = string.format("%s %d %d %.2f %d %d %d %.2f",
        HydraulicWheel.STATE_VERSION,
        math.floor(self.cfg.hardwareLockDeg + 0.5),
        math.floor(self.cfg.steeringRangeDeg + 0.5),
        active and self.centerDeg or 0,
        (active and self.engaged) and 1 or 0,
        active and 1 or 0,
        hold and (self:isElectric() and 2 or 1) or 0,
        hold and self.holdTargetDeg or 0)

    local now = g_time or 0
    local changed = line ~= self.lastStateLine
    if not force then
        if changed and now - self.lastStateWrite < 15 then return end
        if not changed and now - self.lastStateWrite < 500 then return end -- heartbeat
    end

    self.stateSeq = self.stateSeq + 1
    local file = createFile(self:getStatePath(), FileAccess.WRITE)
    if file ~= nil and file ~= 0 then
        fileWrite(file, string.format("%s %d END\n", line, self.stateSeq))
        delete(file)
    end
    self.lastStateLine = line
    self.lastStateWrite = now
end

---------------------------------------------------------------------------
-- Drift control
---------------------------------------------------------------------------

-- Orbitrol-style slip: pushing past a stop makes it give way, so the centre
-- follows the push. The tractor stays at full lock meanwhile (axis is clamped).
function HydraulicWheel:updateSlip(dt)
    if not self.cfg.slipAtWalls or self.lastRawDeg == nil then return end
    local half = self:getHalfRange()
    local over = 0
    if self.lastRawDeg > self.centerDeg + half then
        over = self.lastRawDeg - (self.centerDeg + half)
    elseif self.lastRawDeg < self.centerDeg - half then
        over = self.lastRawDeg - (self.centerDeg - half)
    end
    local excess = math.abs(over) - self.cfg.slipStartDeg
    if excess <= 0 then return end
    local rate = math.min(excess * self.cfg.slipRatePerDeg, self.cfg.slipMaxDegPerSec)
    local step = rate * dt * 0.001
    if over < 0 then step = -step end
    self:setCenter(self.centerDeg + step)
end

function HydraulicWheel:isElectric()
    return self.cfg.autosteerStyle == "electric"
end

-- Aftermarket electric autosteer: the motor turns the steering wheel by however much
-- the tractor's wheels move, so the wheel always matches the tractor and the centre never drifts.
function HydraulicWheel:updateElectric(vehicle)
    local steer = self:getVehicleSteerAxis(vehicle)
    self.holdTargetDeg = self.engageRawDeg + (steer - self.steerAtEngage) * self:getHalfRange()
    self.holdActive = true
end

-- While autosteer drives (hands off), unwind the wheel if the centre has drifted
-- more than reindexKeepDeg. Below that the wheel never moves on its own.
function HydraulicWheel:updateReindex(vehicle, dt)
    self.holdActive = false
    if not self.cfg.reindexWhileEngaged then return end
    if g_time - self.engageTime < self.cfg.disengageGraceMs then return end

    local half = self:getHalfRange()
    local steerDeg = self:getVehicleSteerAxis(vehicle) * half
    local center = self.holdTargetDeg - steerDeg

    if not self.reindexing and math.abs(center) > self.cfg.reindexKeepDeg then
        self.reindexing = true
        self:dbg("re-indexing: centre %.0f deg", center)
    elseif self.reindexing and math.abs(center) <= self.cfg.reindexDoneDeg then
        self.reindexing = false
        -- re-reference to where the wheel actually stopped (it lags the target slightly)
        if self.lastRawDeg ~= nil then self.holdTargetDeg = self.lastRawDeg end
        self:dbg("re-index done")
    end

    if self.reindexing then
        -- Wheel position that would put the centre back at 0.
        local desired = steerDeg
        local maxStep = self.cfg.reindexRateDegPerSec * dt * 0.001
        self.holdTargetDeg = self.holdTargetDeg + clamp(desired - self.holdTargetDeg, -maxStep, maxStep)
    end
    -- Hold the wheel at holdTarget while re-indexing (and a moment after, so it settles).
    self.holdActive = self.reindexing
end

---------------------------------------------------------------------------
-- Mod event listener
---------------------------------------------------------------------------

function HydraulicWheel:loadMap(name)
    self:loadSettings()
    -- The settings section is added on the first update, once every mod (including
    -- FS25_additionalGameSettings, which builds its tab while the savegame loads) is set up.
    self.settingsUiPending = HydraulicWheelSettingsUI ~= nil
    addConsoleCommand("hwStatus", "Hydraulic wheel: print state", "consoleStatus", self)
    addConsoleCommand("hwRecenter", "Hydraulic wheel: make current wheel position match the tractor's wheels", "consoleRecenter", self)
    addConsoleCommand("hwReloadSettings", "Hydraulic wheel: reload settings XML", "consoleReload", self)
end

function HydraulicWheel:deleteMap()
    self:writeState(false, true)
    removeConsoleCommand("hwStatus")
    removeConsoleCommand("hwRecenter")
    removeConsoleCommand("hwReloadSettings")
end

function HydraulicWheel:isVehicleInUse(vehicle)
    if vehicle == nil or vehicle.isDeleted then return false end
    if vehicle.getIsEnteredForInput ~= nil then
        return vehicle:getIsEnteredForInput()
    end
    if vehicle.getIsEntered ~= nil then
        return vehicle:getIsEntered()
    end
    return true
end

function HydraulicWheel:update(dt)
    if self.settingsUiPending then
        self.settingsUiPending = false
        local ok, err = pcall(HydraulicWheelSettingsUI.inject)
        if not ok then
            log("Could not add the in-game settings section (%s). Settings file still works.", tostring(err))
        end
    end

    local vehicle = self.vehicle
    local inUse = self:isVehicleInUse(vehicle)

    if inUse then
        local engagedNow = self:isAutosteerEngaged(vehicle)
        if engagedNow and not self.engaged then
            self:onEngage(vehicle)
        elseif not engagedNow and self.engaged then
            self:onDisengage(vehicle)
        end

        if self.engaged then
            if self:isElectric() then
                self:updateElectric(vehicle)
            else
                self:updateReindex(vehicle, dt)
            end
            -- Keep "wheel where it rests" == "tractor's current wheel angle".
            self:matchCenterToVehicle(vehicle, self.holdTargetDeg)
        else
            self:updateSlip(dt)
        end

        self:hookForceFeedback(vehicle)
    else
        if vehicle ~= nil then
            self.vehicle = nil
            self.engaged = false
        end
    end

    self:writeState(inUse, false)
end

function HydraulicWheel:consoleStatus()
    return string.format("style=%s raw=%.1f centre=%.1f reindexing=%s engaged=%s range=%d hwLock=%d maxOffset=%.0f clamped=%s wallMode=%s",
        self.cfg.autosteerStyle, self.lastRawDeg or 0, self.centerDeg, tostring(self.reindexing), tostring(self.engaged), self.cfg.steeringRangeDeg,
        self.cfg.hardwareLockDeg, self:getMaxCenterOffset(), tostring(self.centerClamped), self.cfg.wallMode)
end

function HydraulicWheel:consoleRecenter()
    if self.vehicle == nil then
        return "Not in a vehicle"
    end
    self:matchCenterToVehicle(self.vehicle, self.lastRawDeg)
    return string.format("Centre set to %.1f deg", self.centerDeg)
end

function HydraulicWheel:consoleReload()
    self:loadSettings()
    return "Settings reloaded"
end

HydraulicWheel.installSteerHook()
addModEventListener(HydraulicWheel)
