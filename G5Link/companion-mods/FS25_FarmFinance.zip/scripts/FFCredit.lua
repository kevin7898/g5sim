-- FS25_FarmFinance - credit scoring and borrowing limits (pure Lua 5.1).
--
-- Two layers, like a farm lender:
--   1. payment history (the farm's track record), and
--   2. the farm's books: debt-to-asset, liquidity, repayment capacity.
-- Both feed a 300-850 score. The score picks a grade band from the region
-- data, the band adds a rate spread, and limits come from collateral and
-- repayment capacity.
--
-- Input is a "snapshot" table built by FFFarmData (in game) or by tests.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region
local LM = FF.LoanMath

FF.Credit = {}
local C = FF.Credit

C.MIN_SCORE = 300
C.MAX_SCORE = 850
C.GRADES = {"A", "B", "C", "D", "E"}

C.WEIGHTS = {
    payment = 0.35,
    solvency = 0.30,
    liquidity = 0.15,
    repayment = 0.15,
    length = 0.05
}

local function linear(x, x0, y0, x1, y1)
    if x1 == x0 then
        return y1
    end
    local t = (x - x0) / (x1 - x0)
    t = U.clamp(t, 0, 1)
    return y0 + (y1 - y0) * t
end

function C.newHistory()
    return {onTime = 0, late = 0, missed = 0, streak = 0, recentLate = {}, defaults = 0, monthsOnRecord = 0}
end

-- Counts late marks within the last 12 months.
function C.countRecentLate(history, monthIndex)
    local count = 0
    for _, lateMonth in ipairs(history.recentLate or {}) do
        if monthIndex - lateMonth < 12 then
            count = count + 1
        end
    end
    return count
end

function C.ratios(snapshot)
    local totalAssets = snapshot.totalAssets or 0
    local totalDebt = snapshot.totalDebt or 0
    local ratios = {
        totalAssets = totalAssets,
        totalDebt = totalDebt,
        netWorth = totalAssets - totalDebt
    }

    if totalAssets > 0 then
        ratios.debtToAsset = totalDebt / totalAssets
    elseif totalDebt > 0 then
        ratios.debtToAsset = 1.5
    else
        ratios.debtToAsset = 0
    end

    local currentLiabilities = snapshot.currentLiabilities or 0
    local currentAssets = snapshot.currentAssets or 0
    if currentLiabilities > 0 then
        ratios.currentRatio = currentAssets / currentLiabilities
    end
    ratios.workingCapital = currentAssets - currentLiabilities

    local minHistory = R.get("credit.minHistoryMonths", 6)
    -- Months on record with no income yet (a first season before harvest)
    -- don't count as history: judge the farm on collateral, like a lender
    -- judging a startup on projections.
    ratios.hasIncomeHistory = (snapshot.historyMonths or 0) >= minHistory and (snapshot.income12 or 0) > 0
    ratios.netOperatingIncome = (snapshot.income12 or 0) - (snapshot.opex12 or 0)
    if ratios.hasIncomeHistory then
        if (snapshot.income12 or 0) > 0 then
            ratios.workingCapitalToRevenue = ratios.workingCapital / snapshot.income12
        end
        if (snapshot.debtService12 or 0) > 0 then
            ratios.termDebtCoverage = ratios.netOperatingIncome / snapshot.debtService12
        end
    end
    return ratios
end

function C.components(ratios, snapshot, history, monthIndex)
    local parts = {}

    -- Payment history
    local total = (history.onTime or 0) + (history.late or 0) + (history.missed or 0)
    if total == 0 then
        parts.payment = 0.45
    else
        local ratio = (history.onTime or 0) / ((history.onTime or 0) + (history.late or 0) + 2 * (history.missed or 0))
        local streakBonus = math.min((history.streak or 0) / 36, 1)
        local recent = C.countRecentLate(history, monthIndex or 0)
        parts.payment = 0.85 * ratio + 0.15 * streakBonus - 0.10 * math.min(recent, 5) - 0.30 * math.min(history.defaults or 0, 3)
        parts.payment = U.clamp(parts.payment, 0, 1)
    end

    -- Solvency: debt-to-asset
    local strongDA, weakDA = R.getRatio("debtToAsset")
    strongDA = strongDA or 0.30
    weakDA = weakDA or 0.70
    if (ratios.totalAssets or 0) <= 0 and (ratios.totalDebt or 0) <= 0 then
        parts.solvency = 0.5
    else
        parts.solvency = linear(ratios.debtToAsset, strongDA - 0.10, 1, weakDA + 0.20, 0)
    end

    -- Liquidity: current ratio
    local strongCR = R.getRatio("currentRatio") or 2.0
    if ratios.currentRatio == nil then
        if (snapshot.cash or 0) < 0 then
            parts.liquidity = 0.3
        else
            parts.liquidity = 1
        end
    else
        parts.liquidity = linear(ratios.currentRatio, 0.5, 0, strongCR, 1)
    end

    -- Repayment capacity: term debt coverage
    local strongTDC, weakTDC = R.getRatio("termDebtCoverage")
    strongTDC = strongTDC or 1.25
    weakTDC = weakTDC or 1.00
    if (snapshot.debtService12 or 0) <= 0 then
        parts.repayment = 0.8
    elseif not ratios.hasIncomeHistory or ratios.termDebtCoverage == nil then
        parts.repayment = 0.6
    else
        parts.repayment = linear(ratios.termDebtCoverage, weakTDC - 0.20, 0, strongTDC + 0.25, 1)
    end

    -- Length of record
    parts.length = math.min((history.monthsOnRecord or 0) / 60, 1)

    return parts
end

function C.score(ratios, snapshot, history, monthIndex)
    local parts = C.components(ratios, snapshot, history, monthIndex)
    local sum = 0
    for name, weight in pairs(C.WEIGHTS) do
        sum = sum + weight * (parts[name] or 0)
    end
    local score = math.floor(C.MIN_SCORE + (C.MAX_SCORE - C.MIN_SCORE) * sum + 0.5)
    return U.clamp(score, C.MIN_SCORE, C.MAX_SCORE), parts
end

function C.grade(score)
    for _, grade in ipairs(C.GRADES) do
        local minScore = R.get("rates.riskSpread." .. grade .. ".minScore")
        if minScore ~= nil and score >= minScore then
            return grade
        end
    end
    return "E"
end

-- Interest rate a farm with this score would get for a product.
function C.rateFor(baseRate, productId, score)
    local spread = R.get("rates.spread." .. productId .. ".value", 0)
    local risk = R.getRiskSpread(C.grade(score))
    return math.max(baseRate + spread + risk, 0.0)
end

-- Collateral pool available for a product, after existing debt of that kind.
function C.collateralLimit(snapshot, productId)
    local debts = snapshot.debts or {}
    if productId == "realEstate" then
        local pool = (snapshot.landValue or 0) * R.get("credit.collateral.land", 0.65)
            + (snapshot.buildingValue or 0) * R.get("credit.collateral.buildings", 0.40)
        return pool - (debts.realEstate or 0)
    elseif productId == "equipment" then
        local pool = (snapshot.machineryValue or 0) * R.get("credit.collateral.machinery", 0.55)
        return pool - (debts.equipment or 0) - (debts.imported or 0)
    elseif productId == "operating" then
        local minHistory = R.get("credit.minHistoryMonths", 6)
        local pool
        if (snapshot.historyMonths or 0) >= minHistory and (snapshot.income12 or 0) > 0 then
            pool = snapshot.income12 * R.get("credit.operating.incomeShare", 0.30)
        else
            pool = (snapshot.totalAssets or 0) * R.get("credit.operating.assetShare", 0.10)
        end
        return pool - (debts.operating or 0)
    end
    return 0
end

-- Largest new loan the farm's income can carry, or nil when there is not
-- enough history yet (a new farm is judged on collateral alone).
function C.capacityLimit(snapshot, ratios, rate, months)
    if not ratios.hasIncomeHistory then
        return nil
    end
    local strongTDC = R.getRatio("termDebtCoverage") or 1.25
    local maxDebtService = math.max(ratios.netOperatingIncome, 0) / strongTDC
    local available = maxDebtService - (snapshot.debtService12 or 0)
    if available <= 0 then
        return 0
    end
    local termMonths = math.max(months, 1)
    if termMonths < 12 then
        termMonths = 12
    end
    return LM.principalForPayment(available / 12, rate, termMonths)
end

-- Full quote for an application. Returns a table with approved, limit,
-- rate, payment and a reason key when declined.
function C.quote(args)
    local snapshot = args.snapshot
    local ratios = args.ratios or C.ratios(snapshot)
    local score = args.score
    local productId = args.productId
    local months = math.max(1, math.floor((args.termYears or 1) * 12 + 0.5))
    local rate = C.rateFor(args.baseRate or 0.065, productId, score)

    local collateral = math.max(C.collateralLimit(snapshot, productId), 0)
    local capacity = C.capacityLimit(snapshot, ratios, rate, months)
    local solvencyRoom = math.max(0.80 * (snapshot.totalAssets or 0) - (snapshot.totalDebt or 0), 0)

    local limit = math.min(collateral, solvencyRoom)
    if capacity ~= nil then
        limit = math.min(limit, capacity)
    end
    limit = math.max(math.floor(limit / 100) * 100, 0)

    local result = {
        productId = productId,
        months = months,
        rate = rate,
        grade = C.grade(score),
        score = score,
        limit = limit,
        collateral = collateral,
        capacity = capacity,
        solvencyRoom = solvencyRoom,
        amount = args.amount,
        approved = false
    }

    local minScore = R.get("credit.minScore", 580)
    local minAmount = R.get("loans.minAmount", 5000)
    if not R.isProductEnabled(productId) then
        result.reason = "ff_reason_productDisabled"
    elseif score < minScore then
        result.reason = "ff_reason_score"
    elseif limit < minAmount then
        result.reason = "ff_reason_noRoom"
    elseif args.amount ~= nil and args.amount < minAmount then
        result.reason = "ff_reason_tooSmall"
    elseif args.amount ~= nil and args.amount > limit then
        result.reason = "ff_reason_overLimit"
    else
        result.approved = true
    end

    if args.amount ~= nil and args.amount > 0 then
        result.payment = LM.payment(args.amount, rate, months)
    end
    return result
end

return C
