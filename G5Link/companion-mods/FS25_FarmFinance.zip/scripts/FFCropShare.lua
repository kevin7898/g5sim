-- FS25_FarmFinance - crop-share leases (pure rules).
--
-- On a crop-share field the landowner owns a share of every pass the
-- combine takes. That grain is pooled per crop: the farm holds it in its
-- trucks and bins with everything else, and a ledger of "lots" (crop, field,
-- crop year, liters) says how much of it belongs to the landowner.
--   * Selling that crop anywhere pays the landowner first, oldest lots
--     first, at the price of that sale.
--   * Grain left in the bins earns a small storage fee from the landowner.
--   * At the region's sell-by period of the next crop year, lots still held
--     are cashed out at the farm's last sale price for that crop.
--   * Seed and spray used on the field are priced per pass; the landowner
--     pays their input share at month end.
-- Game calls go through FF.env: addMoney, notify, getFallbackPrice(fillType).

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region

FF.CropShare = {}
local CS = FF.CropShare

CS.STATS_KEEP_YEARS = 3

local function env()
    return FF.env or {}
end

local function addMoney(amount, farmId, typeKey)
    if amount ~= 0 and env().addMoney ~= nil then
        env().addMoney(amount, farmId, typeKey)
    end
end

local function notify(farmId, text, isWarning)
    if env().notify ~= nil then
        env().notify(farmId, text, isWarning)
    end
end

local function markDirty()
    if env().markDirty ~= nil then
        env().markDirty()
    end
end

function CS.getFarmShare(farm)
    farm.cropShare = farm.cropShare or {}
    local share = farm.cropShare
    share.lots = share.lots or {}
    share.lastPrice = share.lastPrice or {}
    share.stats = share.stats or {}
    share.inputs = share.inputs or {}
    share.pendingInputCredit = share.pendingInputCredit or 0
    return share
end

-- True when any farm has a crop-share lease (keeps the per-frame hooks cheap).
function CS.hasShareContracts()
    if FF.state == nil then
        return false
    end
    for _, farm in pairs(FF.state.farms) do
        for _, contract in pairs(farm.land) do
            if contract.leaseType == "share" then
                return true
            end
        end
    end
    return false
end

function CS.getShareContract(farmId, farmlandId)
    if farmlandId == nil or FF.Land == nil then
        return nil
    end
    local contract = FF.Land.getContractByFarmland(farmlandId)
    if contract ~= nil and contract.kind == "in" and contract.leaseType == "share" and contract.farmId == farmId then
        return contract
    end
    return nil
end

function CS.price(share, fillType)
    local price = share.lastPrice[fillType]
    if price ~= nil and price > 0 then
        return price
    end
    if env().getFallbackPrice ~= nil then
        return env().getFallbackPrice(fillType) or 0
    end
    return 0
end

local function getStat(share, contract, cropYear, fillType)
    for _, row in ipairs(share.stats) do
        if row.contractId == contract.id and row.cropYear == cropYear and row.fillType == fillType then
            return row
        end
    end
    local row = {
        contractId = contract.id,
        farmlandId = contract.farmlandId,
        name = contract.name,
        cropYear = cropYear,
        fillType = fillType,
        harvested = 0,
        landowner = 0,
        delivered = 0,
        deliveredValue = 0,
        settled = 0,
        settledValue = 0
    }
    table.insert(share.stats, row)
    return row
end

local function findStatForLot(share, lot)
    for _, row in ipairs(share.stats) do
        if row.contractId == lot.contractId and row.cropYear == lot.cropYear and row.fillType == lot.fillType then
            return row
        end
    end
    return nil
end

-- Harvest -------------------------------------------------------------------------

-- `liters` the combine just took on `farmlandId`. Returns the landowner's part.
function CS.onHarvest(farmId, farmlandId, fillType, liters)
    if liters == nil or liters <= 0 or fillType == nil then
        return 0
    end
    local contract = CS.getShareContract(farmId, farmlandId)
    if contract == nil then
        return 0
    end
    local farm = FF.Bank.getFarm(farmId)
    local share = CS.getFarmShare(farm)
    local cropYear = FF.state.cropYear
    local landowner = liters * (contract.landownerShare or 0)

    local lot = nil
    for _, existing in ipairs(share.lots) do
        if existing.contractId == contract.id and existing.cropYear == cropYear and existing.fillType == fillType then
            lot = existing
        end
    end
    if lot == nil then
        lot = {contractId = contract.id, farmlandId = contract.farmlandId, name = contract.name, cropYear = cropYear, fillType = fillType, liters = 0}
        table.insert(share.lots, lot)
    end
    lot.liters = lot.liters + landowner

    local row = getStat(share, contract, cropYear, fillType)
    row.harvested = row.harvested + liters
    row.landowner = row.landowner + landowner
    CS.dirty = true
    return landowner
end

-- Sales ----------------------------------------------------------------------------

-- A sale of `liters` of `fillType` at `pricePerLiter`. Takes the landowner's
-- lots first (oldest crop year first) and returns liters and value owed to
-- the landowner from this load. The caller charges the money.
function CS.onSale(farmId, fillType, liters, pricePerLiter)
    if liters == nil or liters <= 0 or fillType == nil then
        return 0, 0
    end
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return 0, 0
    end
    local share = CS.getFarmShare(farm)
    if pricePerLiter ~= nil and pricePerLiter > 0 then
        share.lastPrice[fillType] = pricePerLiter
    end

    local candidates = {}
    for index, lot in ipairs(share.lots) do
        if lot.fillType == fillType and lot.liters > 0 then
            candidates[#candidates + 1] = {lot = lot, index = index}
        end
    end
    if #candidates == 0 then
        return 0, 0
    end
    table.sort(candidates, function(a, b)
        if a.lot.cropYear ~= b.lot.cropYear then
            return a.lot.cropYear < b.lot.cropYear
        end
        return a.index < b.index
    end)

    local remaining = liters
    local takenTotal, valueTotal = 0, 0
    local price = pricePerLiter or CS.price(share, fillType)
    for _, candidate in ipairs(candidates) do
        if remaining <= 0 then
            break
        end
        local lot = candidate.lot
        local taken = math.min(lot.liters, remaining)
        lot.liters = lot.liters - taken
        remaining = remaining - taken
        local value = taken * price
        takenTotal = takenTotal + taken
        valueTotal = valueTotal + value
        local row = findStatForLot(share, lot)
        if row ~= nil then
            row.delivered = row.delivered + taken
            row.deliveredValue = row.deliveredValue + value
        end
    end
    CS.removeEmptyLots(share)
    CS.dirty = true
    return takenTotal, valueTotal
end

function CS.removeEmptyLots(share)
    for index = #share.lots, 1, -1 do
        if share.lots[index].liters <= 0.5 then
            table.remove(share.lots, index)
        end
    end
end

-- Inputs ---------------------------------------------------------------------------

-- Seed or spray worth `cost` was used on `farmlandId`. Returns the credit.
function CS.onInputUse(farmId, farmlandId, cost)
    if cost == nil or cost <= 0 then
        return 0
    end
    local contract = CS.getShareContract(farmId, farmlandId)
    if contract == nil or (contract.inputShare or 0) <= 0 then
        return 0
    end
    local farm = FF.Bank.getFarm(farmId)
    local share = CS.getFarmShare(farm)
    local credit = cost * contract.inputShare
    share.pendingInputCredit = share.pendingInputCredit + credit

    local cropYear = FF.state.cropYear
    local row = nil
    for _, existing in ipairs(share.inputs) do
        if existing.contractId == contract.id and existing.cropYear == cropYear then
            row = existing
        end
    end
    if row == nil then
        row = {contractId = contract.id, cropYear = cropYear, cost = 0, credit = 0}
        table.insert(share.inputs, row)
    end
    row.cost = row.cost + cost
    row.credit = row.credit + credit
    return credit
end

-- Summary --------------------------------------------------------------------------

-- {fillType = {liters, value, oldestCropYear}} of grain held for landowners.
function CS.getHeld(farmId)
    local held = {}
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return held
    end
    local share = CS.getFarmShare(farm)
    for _, lot in ipairs(share.lots) do
        local entry = held[lot.fillType]
        if entry == nil then
            entry = {liters = 0, value = 0, oldestCropYear = lot.cropYear}
            held[lot.fillType] = entry
        end
        entry.liters = entry.liters + lot.liters
        entry.oldestCropYear = math.min(entry.oldestCropYear, lot.cropYear)
    end
    for fillType, entry in pairs(held) do
        entry.value = entry.liters * CS.price(share, fillType)
    end
    return held
end

function CS.getHeldValue(farmId)
    local total = 0
    for _, entry in pairs(CS.getHeld(farmId)) do
        total = total + entry.value
    end
    return total
end

-- Pays the landowner now for everything held of one crop, at the last price.
function CS.settleNow(farmId, fillType)
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return false, "ff_reason_nothingHeld"
    end
    local share = CS.getFarmShare(farm)
    local price = CS.price(share, fillType)
    local total, liters = 0, 0
    for _, lot in ipairs(share.lots) do
        if lot.fillType == fillType and lot.liters > 0 then
            local value = lot.liters * price
            local row = findStatForLot(share, lot)
            if row ~= nil then
                row.settled = row.settled + lot.liters
                row.settledValue = row.settledValue + value
            end
            total = total + value
            liters = liters + lot.liters
            lot.liters = 0
        end
    end
    if liters <= 0 then
        return false, "ff_reason_nothingHeld"
    end
    CS.removeEmptyLots(share)
    addMoney(-total, farmId, "cropShareLandowner")
    markDirty()
    return true, nil, total
end

-- Monthly (called by the bank for each farm). Returns the amount the farm had
-- to pay the landowner this month (an obligation for payment history).
function CS.processMonth(farm, period)
    local share = CS.getFarmShare(farm)
    local paid = 0

    if share.pendingInputCredit > 0 then
        addMoney(share.pendingInputCredit, farm.farmId, "cropShareInputs")
        share.pendingInputCredit = 0
    end

    local held = CS.getHeld(farm.farmId)
    local heldValue = 0
    for _, entry in pairs(held) do
        heldValue = heldValue + entry.value
    end
    if heldValue > 0 then
        local fee = heldValue * R.get("land.cropShare.storageFeePerMonth", 0)
        if fee > 0 then
            addMoney(fee, farm.farmId, "cropShareStorage")
        end
    end

    if period == R.get("land.cropShare.sellByPeriod", 6) then
        local settledValue = 0
        for _, lot in ipairs(share.lots) do
            if lot.cropYear < FF.state.cropYear and lot.liters > 0 then
                local value = lot.liters * CS.price(share, lot.fillType)
                local row = findStatForLot(share, lot)
                if row ~= nil then
                    row.settled = row.settled + lot.liters
                    row.settledValue = row.settledValue + value
                end
                settledValue = settledValue + value
                lot.liters = 0
            end
        end
        if settledValue > 0 then
            CS.removeEmptyLots(share)
            addMoney(-settledValue, farm.farmId, "cropShareLandowner")
            notify(farm.farmId, U.text("ff_msg_shareSettled", U.money(settledValue)), false)
            paid = paid + settledValue
        end
    end

    -- Keep only recent crop years in the field reports.
    local oldest = FF.state.cropYear - CS.STATS_KEEP_YEARS
    for index = #share.stats, 1, -1 do
        if share.stats[index].cropYear < oldest then
            table.remove(share.stats, index)
        end
    end
    for index = #share.inputs, 1, -1 do
        if share.inputs[index].cropYear < oldest then
            table.remove(share.inputs, index)
        end
    end
    return paid
end

return CS
