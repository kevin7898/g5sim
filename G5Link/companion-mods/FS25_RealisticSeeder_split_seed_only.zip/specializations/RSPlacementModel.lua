-- Pure Lua mechanics. Values are gameplay calibration, not agronomic prescriptions.
RSPlacementModel = {}
local M = RSPlacementModel

function M.clamp(v,lo,hi) return math.max(lo,math.min(hi,v)) end
function M.finite(v) return type(v)=="number" and v==v and math.abs(v)<math.huge end
M.defaults = {depthMm=40,ratePercent=100,pressurePercent=50,closingPercent=50,meterPercent=100,ratePerAcre=0,seedsPerPound=0}
M.limits = {depthMm={5,100},ratePercent={50,200},pressurePercent={0,100},closingPercent={0,100},meterPercent={50,150},ratePerAcre={0,3000000},seedsPerPound={0,1000000}}
M.crops = {WHEAT={25,50},WV_WINTERWHEAT={25,50},WV_SPRINGWHEAT={25,50},SOYBEAN={25,50},MAIZE={35,65},BARLEY={25,50},OAT={25,50},CANOLA={10,30},SUNFLOWER={25,60},SUGARBEET={15,35},SORGHUM={25,50}}

function M.settings(input)
    local result={}
    for k,v in pairs(M.defaults) do
        local value=input and input[k]
        result[k]=M.finite(value) and M.clamp(value,M.limits[k][1],M.limits[k][2]) or v
    end
    return result
end

-- Unitless control effort, NOT hydraulic PSI. Neutral defaults preserve old saves.
function M.soilResponse(soil)
    soil=soil or {}
    local moisture=M.finite(soil.moisture) and M.clamp(soil.moisture,0,1) or 0.5
    local compaction=M.finite(soil.compaction) and M.clamp(soil.compaction,0,1) or 0.15
    local dry=M.clamp((0.45-moisture)/0.35,0,1)
    local wet=M.clamp((moisture-0.65)/0.3,0,1)
    return {moisture=soil.moisture,compaction=soil.compaction,
        moistureSource=soil.moistureSource or "unavailable",compactionSource=soil.compactionSource or "unavailable",
        dry=dry,wet=wet,
        pressureTarget=M.clamp(50+35*dry+25*(compaction-0.15)-25*wet,15,90),
        closingTarget=M.clamp(50+25*dry+15*(compaction-0.15)-30*wet,15,85)}
end

function M.evaluate(profile,settings,crop,speedKmh,damage,soil)
    local s=M.settings(settings)
    local excess=math.max(0,(speedKmh or 0)-(profile.workingSpeedKmh or 12))
    damage=M.clamp(damage or 0,0,1)
    local conditions=M.soilResponse(soil)
    local under=math.max(0,conditions.pressureTarget-s.pressurePercent)/100
    local over=math.max(0,s.pressurePercent-conditions.pressureTarget)/100
    local closeUnder=math.max(0,conditions.closingTarget-s.closingPercent)/100
    local closeOver=math.max(0,s.closingPercent-conditions.closingTarget)/100
    local depth=s.depthMm-under*(12+12*conditions.dry)+over*(3+5*conditions.wet)-excess*(profile.kind=="planter" and 1.2 or 0.8)
    local spread=2+excess*1.3+damage*5+under*8+over*conditions.wet*4
    local sidewall=M.clamp(conditions.wet*(over*0.50+closeOver*0.65),0,0.60)
    local contact=M.clamp(1-closeUnder*0.65-closeOver*(0.12+0.35*conditions.wet)-excess*0.012-damage*0.08,0.1,1)
    local delivery=math.max(0,(100-s.meterPercent)/100)
    local skip=M.clamp(delivery+excess*(profile.kind=="planter" and 0.018 or 0.009)+damage*0.025,0,0.7)
    local doubles=profile.kind=="planter" and M.clamp(math.max(0,s.meterPercent-100)/100+excess*0.004,0,0.5) or 0
    local distribution=profile.kind=="drill" and (excess*0.012+math.abs(s.meterPercent-100)/250+damage*0.08) or 0
    local range=M.crops[crop]
    local depthLoss=0
    if range then
        depthLoss=M.clamp((math.max(0,range[1]-depth)+math.max(0,depth-range[2]))/65 + math.max(0,spread-7)/80,0,0.8)
    end
    return {actualDepthMm=math.max(0,depth),depthSpreadMm=spread,contactPercent=contact*100,
        skipsPercent=skip*100,doublesPercent=doubles*100,distributionCvPercent=distribution*100,
        placementLossPercent=(1-(1-depthLoss)*contact*(1-sidewall))*100,
        deliveryScale=(1-skip+doubles)*(profile.kind=="drill" and math.max(1,s.meterPercent/100) or 1),
        depthResponseSupported=range~=nil,speedKmh=speedKmh or 0,soil=conditions,sidewallRiskPercent=sidewall*100}
end

-- Piecewise gameplay response, not field-trial regression or regional prescriptions.
-- Columns are established population / nominal crop population. Soybean branching,
-- cereal tillering and canola branching provide more compensation than maize.
M.populationRatios={0,0.25,0.5,0.75,1,1.15,1.5,2,3,6}
M.populationCurves={
    MAIZE={0,0.40,0.72,0.92,1,1,0.91,0.73,0.43,0},
    SOYBEAN={0,0.65,0.90,0.98,1,1,0.98,0.92,0.78,0},
    WHEAT={0,0.53,0.83,0.96,1,1,0.95,0.84,0.63,0},
    WV_WINTERWHEAT={0,0.57,0.86,0.97,1,1,0.95,0.83,0.61,0},
    WV_SPRINGWHEAT={0,0.48,0.79,0.94,1,1,0.95,0.84,0.63,0},
    BARLEY={0,0.55,0.84,0.96,1,1,0.94,0.81,0.58,0},
    OAT={0,0.50,0.81,0.95,1,1,0.94,0.80,0.56,0},
    CANOLA={0,0.62,0.88,0.97,1,1,0.96,0.85,0.64,0},
    SUNFLOWER={0,0.44,0.76,0.94,1,1,0.90,0.72,0.43,0},
    SUGARBEET={0,0.45,0.78,0.95,1,1,0.96,0.87,0.68,0},
    SORGHUM={0,0.53,0.84,0.96,1,1,0.94,0.82,0.59,0}}
function M.populationYield(crop,ratio,soil)
    ratio=M.finite(ratio) and math.max(0,ratio) or 1
    local curve=M.populationCurves[crop]
    if not curve then return math.min(1,ratio),false end
    -- Dry seedbeds increase the high-population competition penalty only;
    -- drought/nutrients and other mods' seasonal yield effects remain their own.
    if ratio>1 then ratio=1+(ratio-1)*(1+0.5*M.soilResponse(soil).dry) end
    for i=2,#M.populationRatios do
        if ratio<=M.populationRatios[i] then
            local t=(ratio-M.populationRatios[i-1])/(M.populationRatios[i]-M.populationRatios[i-1])
            return curve[i-1]+t*(curve[i]-curve[i-1]),true
        end
    end
    return 0,true
end
function M.populationResponse(crop,calibration,referenceSeeds,sample)
    local seeds=calibration.ratePerAcre
    if calibration.unit=="poundsPerAcre" then seeds=seeds*calibration.seedsPerPound end
    local established=seeds*sample.deliveryScale*(1-sample.placementLossPercent/100)
    local ratio=established/referenceSeeds
    local potential,supported=M.populationYield(crop,ratio,sample.soil)
    -- Uneven spacing is distinct from a uniformly thin stand. Doubles do not
    -- create a free yield bonus; their competition is also in the population curve.
    local sensitivity=crop=="MAIZE" and 0.25 or 0.10
    local uneven=M.clamp((sample.skipsPercent+sample.doublesPercent+sample.distributionCvPercent)/100*sensitivity,0,0.35)
    return {targetSeedsPerAcre=seeds,establishedSeedsPerAcre=established,referenceSeedsPerAcre=referenceSeeds,
        populationRatio=ratio,populationCurveSupported=supported,populationYieldPercent=potential*100,
        yieldPotentialPercent=potential*(1-uneven)*100,unevenStandLossPercent=uneven*100,
        yieldMethod="nativeCoverageEquivalent"}
end

-- Integer hash: no frame-time seed, math.random, or session-specific state.
function M.random(x,z,salt)
    local n=(x*73856093+z*19349663+(salt or 0)*83492791)%2147483647
    n=(n*16807)%2147483647
    return n/2147483647
end

-- Split a rectangular native primitive on a fixed projected metre grid.
-- Edge pieces stay inside the original primitive; no terrain writes occur here.
-- The grid is world anchored, so dividing a straight pass into different dt's
-- gives the same masks. Turns legitimately change the opener's orientation.
function M.partition(sx,sz,wx,wz,hx,hz,cell,visit)
    local ax,az,bx,bz=wx-sx,wz-sz,hx-sx,hz-sz
    local width=math.sqrt(ax*ax+az*az)
    local length=math.sqrt(bx*bx+bz*bz)
    if width<0.00001 or length<0.00001 then return false end
    local ux,uz,vx,vz=ax/width,az/width,bx/length,bz/length
    if math.abs(ux*vx+uz*vz)>0.001 then return false end
    local u0=sx*ux+sz*uz;local v0=sx*vx+sz*vz
    local firstU,lastU=math.floor(u0/cell),math.ceil((u0+width)/cell)-1
    local firstV,lastV=math.floor(v0/cell),math.ceil((v0+length)/cell)-1
    if (lastU-firstU+1)*(lastV-firstV+1)>512 then return false end
    for j=firstV,lastV do
        local va=math.max(v0,j*cell);local vb=math.min(v0+length,(j+1)*cell)
        for i=firstU,lastU do
            local ua=math.max(u0,i*cell);local ub=math.min(u0+width,(i+1)*cell)
            if ub-ua>0.00001 and vb-va>0.00001 then
                visit(ua*ux+va*vx,ua*uz+va*vz,ub*ux+va*vx,ub*uz+va*vz,
                    ua*ux+vb*vx,ua*uz+vb*vz,i,j,(ub-ua)*(vb-va))
            end
        end
    end
    return true
end
