local WV = WheatVarieties
local Tree = WV.XmlTree
WV.Definitions = {}
local Def = WV.Definitions

Def.periods = { "EARLY_SPRING", "MID_SPRING", "LATE_SPRING", "EARLY_SUMMER",
    "MID_SUMMER", "LATE_SUMMER", "EARLY_AUTUMN", "MID_AUTUMN", "LATE_AUTUMN",
    "EARLY_WINTER", "MID_WINTER", "LATE_WINTER" }

function Def.parse(root)
    assert(root.attributes.schemaVersion == "1", "Unsupported variety schema")
    local definitions, names, components = {}, {}, {}
    for _, node in ipairs(root.children) do
        if node.name == "variety" then
            local def = WV.copy(node.attributes)
            assert(def.name and def.name:match("^WV_[A-Z0-9_]+$"), "Invalid variety name")
            assert(def.layerName and def.layerName:upper() == def.name, "Layer name must match fruit name")
            assert(def.componentId and def.componentId:match("^wheat%.[a-z]+$"), "Invalid component ID")
            assert(not names[def.name] and not components[def.componentId], "Duplicate variety identity")
            assert(def.title and def.marketClass and def.growthHabit, "Incomplete variety metadata")
            for _, key in ipairs({"yieldMultiplier", "strawMultiplier", "seedMultiplier", "priceMultiplier"}) do
                def[key] = tonumber(def[key])
                assert(def[key] and def[key] > 0 and def[key] <= 5, "Invalid " .. key)
            end
            def.seasonal = WV.copy(Tree.child(node, "seasonal"))
            assert(def.seasonal and #def.seasonal.children == 12, "Calendar must have 12 periods")
            for index, period in ipairs(def.seasonal.children) do
                assert(period.name == "period" and period.attributes.name == Def.periods[index], "Invalid period order")
                local flag = period.attributes.plantingAllowed
                assert(flag == nil or flag == "true" or flag == "false", "Invalid plantingAllowed")
                local seen = {}
                for _, update in ipairs(period.children) do
                    local a = update.attributes
                    assert(update.name == "update" and a.startState and a.endState, "Invalid growth transition")
                    assert(not seen[a.startState], "Duplicate growth transition")
                    seen[a.startState] = true
                end
            end
            names[def.name], components[def.componentId] = true, true
            definitions[#definitions + 1] = def
        end
    end
    assert(#definitions == 2, "This prototype requires exactly two wheat varieties")
    table.sort(definitions, function(a, b) return a.name < b.name end)
    return definitions
end

local function scale(node, childName, attribute, multiplier)
    local child = assert(Tree.child(node, childName), "Missing wheat " .. childName)
    local value = assert(tonumber(child.attributes[attribute]), "Missing wheat " .. attribute)
    child.attributes[attribute] = string.format("%.8f", value * multiplier)
end

function Def.makeFoliage(base, def)
    local tree = WV.copy(base)
    -- The Lua foliage loader needs an absolute shapeSource. Registration
    -- subsequently caches distance textures for its native relative loader.
    Tree.rebase(tree, getAppBasePath() .. "data/foliage/wheat/")
    local fruit = assert(Tree.child(tree, "fruitType"), "Missing wheat fruitType")
    fruit.attributes.name = def.layerName
    fruit.attributes.useForFieldMissions = "false" -- NPC contracts need separate validation
    fruit.attributes.shownOnMap = "true"
    local colors = Tree.child(fruit, "mapColors")
    if colors then colors.attributes.default = def.mapColor end
    scale(fruit, "harvest", "litersPerSqm", def.yieldMultiplier)
    scale(fruit, "windrow", "litersPerSqm", def.strawMultiplier)
    scale(fruit, "seeding", "litersPerSqm", def.seedMultiplier)
    -- Do not overwrite WHEAT_CUT's reverse mapping with a new variety.
    local windrow = Tree.child(fruit, "windrow")
    windrow.attributes.cutFillType, windrow.attributes.windrowCutFactor = nil, nil
    local states = {}
    for _, layer in ipairs(tree.children) do
        if layer.name == "foliageLayer" then
            for _, state in ipairs(layer.children) do
                if state.name == "foliageState" then states[state.attributes.name] = true end
            end
        end
    end
    assert(states[def.seasonal.attributes.initialState], "Unknown initial growth state")
    for _, period in ipairs(def.seasonal.children) do
        for _, update in ipairs(period.children) do
            assert(states[update.attributes.startState] and states[update.attributes.endState], "Wheat growth states changed")
        end
    end
    local growth = assert(Tree.child(tree, "growth"), "Missing wheat growth")
    Tree.replaceChild(growth, WV.copy(def.seasonal))
    return tree
end

function Def.makeFillType(base, def)
    local tree = WV.copy(base)
    Tree.rebase(tree, "$data/maps/")
    tree.attributes.name, tree.attributes.title = def.name, def.title
    tree.attributes.achievementName = nil
    tree.attributes.showOnPriceTable = "true"
    scale(tree, "economy", "pricePerLiter", def.priceMultiplier)
    return tree
end
