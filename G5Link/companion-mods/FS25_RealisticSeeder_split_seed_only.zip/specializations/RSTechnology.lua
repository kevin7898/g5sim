-- Staged retrofit hardware sold as native store/workshop configurations.
-- Prices approximate US list prices and scale with the machine: per row on
-- planters, per opener or section on drills. The native shop owns payment and
-- persistence. Retired options stay loadable (isSelectable=false) so older saves
-- keep what was bought; they are never offered for sale again.
RSTechnology={modules={},capabilities={},
    rowSpacingM=0.762,          -- 30 in rows when only the working width is known
    drillSpacingM=0.19,         -- 7.5 in openers
    sectionWidthM=3,            -- drill section width for section shutoff
    maxLanes=24,                -- settings hold 24 row/section switches
    unknownRows=8,unknownOpeners=32}
local T=RSTechnology

-- Base-game planters whose names do not state the row count.
T.knownRows={['/horsch/maestro2450sv/']=24,['/horsch/maestro975rx/']=9,['/amazone/precea4500/']=6,
    ['/grimme/matrix1800/']=18,['/kverneland/optimars9m/']=12,['/kuhn/maxima3til/']=8,['/sola/velox300_12/']=12,
    ['/fs25_johndeere_1760/1760_12row.xml']=12}
T.rowSpacingsCm={[45]=true,[50]=true,[70]=true,[75]=true,[76]=true,[80]=true}

local function text(xml,key)
    local value=getXMLString(xml.handle,key)
    if type(value)=='string' and value:sub(1,6)=='$l10n_' and g_i18n and g_i18n.getText then
        local ok,translated=pcall(g_i18n.getText,g_i18n,value:sub(7))
        if ok and type(translated)=='string' then value=translated end
    end
    return type(value)=='string' and value or ''
end
local function whole(v,lo,hi)
    v=tonumber(v)
    if v and v==math.floor(v) and v>=lo and v<=hi then return v end
end
-- "16 Row", "16-row", "16R30", "24.50" (Horsch: rows.spacing cm). nil when absent.
function T.rowsFromText(s)
    s=tostring(s or ''):lower()
    local n=whole(s:match('(%d+)%s*%-?%s*rows?'),1,96)
    if n then return n end
    n=whole(s:match('(%d+)r%d%d'),1,96)
    if n then return n end
    local rows,spacing=s:match('(%d+)%.(%d%d)')
    if rows and T.rowSpacingsCm[tonumber(spacing)] then return whole(rows,1,96) end
end
-- Physical size used for prices and for row/section lanes.
function T.sizes(xml,filename,kind)
    local file=(filename or ''):lower():gsub('\\','/')
    local name=text(xml,'vehicle.storeData.name')
    local width=tonumber(getXMLString(xml.handle,'vehicle.storeData.specs.workingWidth'))
    if width and width<=0 then width=nil end
    local out={widthM=width,rows=0,openers=0,sections=0,lanes=0,rowsPerLane=1,laneKind=kind=='planter' and 'row' or 'section'}
    if kind=='planter' then
        local rows,source=whole(getXMLString(xml.handle,'vehicle.rsPlacement#rowCount'),1,96),'profile'
        if not rows then for pattern,n in pairs(T.knownRows) do if file:find(pattern,1,true) then rows,source=n,'known' end end end
        if not rows then rows,source=T.rowsFromText(name),'name' end
        if not rows then rows,source=T.rowsFromText(file:match('([^/]*)%.xml$')),'file' end
        if not rows and width then rows,source=math.max(1,math.floor(width/T.rowSpacingM+.5)),'width' end
        out.rows=rows or 0;out.rowSource=rows and source or 'unknown'
        if out.rows>0 then
            out.rowsPerLane=math.ceil(out.rows/T.maxLanes)
            out.lanes=math.ceil(out.rows/out.rowsPerLane)
        end
    else
        local _,spacing=name:match('(%d+)%.(%d%d)')
        local spacingM=spacing and tonumber(spacing)>=10 and tonumber(spacing)<=40 and tonumber(spacing)/100 or T.drillSpacingM
        out.openers=width and math.max(1,math.floor(width/spacingM+.5)) or 0
        out.sections=width and math.max(2,math.min(12,math.floor(width/T.sectionWidthM+.5))) or 0
        out.lanes=out.sections
    end
    return out
end
-- Price of one option on this machine, rounded to $50.
function T.price(option,kind,size)
    local p=option[kind];if type(p)=='number' then return p end
    if type(p)~='table' then return nil end
    local rows=size.rows>0 and size.rows or T.unknownRows
    local openers=size.openers>0 and size.openers or T.unknownOpeners
    local total=(p.base or 0)+(p.row or 0)*rows+(p.opener or 0)*openers+(p.section or 0)*size.sections
    return math.floor(total/50+.5)*50
end
function T.register(manager)
    for _,m in ipairs(T.modules) do
        if manager:getConfigurationDescByName(m.name)==nil then manager:addConfigurationType(m.name,m.title,"rsPlacement",VehicleConfigurationItem) end
    end
end
-- Options for one machine kind: offered ones first, then retired (legacy) ones.
function T.optionsFor(m,kind)
    local out={}
    for _,o in ipairs(m.options or {}) do if o[kind]~=nil then out[#out+1]=o end end
    return out
end
function T.options(m,kind,factory,size)
    local out={}
    size=size or {rows=factory.rowCount or 0,openers=0,sections=factory.rowCount or 0,lanes=factory.rowCount or 0}
    if m.cleaners and not (factory.recognizedCleanerOptions or factory.rowCleanerCabAdjustment) then return out end
    for _,o in ipairs(T.optionsFor(m,kind)) do
        local complete=true;for _,cap in ipairs(o.caps) do if not factory[cap] then complete=false end end
        local lanesOk=not o.lanes or (size.lanes or 0)>=1
        if o.legacy then out[#out+1]=o elseif not complete and lanesOk then out[#out+1]=o end
    end
    return out
end
function T.kindOf(xml)
    local kind=tostring(getXMLString(xml.handle,'vehicle.storeData.category') or ''):lower()=='planters' and 'planter' or 'drill'
    local explicit=getXMLString(xml.handle,'vehicle.rsPlacement#kind');if explicit=='planter' or explicit=='drill' then kind=explicit end
    return kind
end
function T.factory(xml,filename,configurations)
    local filename=(filename or ''):lower():gsub('\\','/')
    local kinze=filename:match('/kinze/planter4900/planter4900.xml$')~=nil
    local p={equipment={},equipmentCheck='Installed equipment',rowCount=0}
    for cap in pairs(T.capabilities) do
        local value=getXMLBool(xml.handle,'vehicle.rsPlacement#'..cap)
        if value==nil then value=kinze and (cap=='settingsLogging' or cap=='seedMonitor' or cap=='cabRateControl') end
        p[cap]=value==true
    end
    local size=T.sizes(xml,filename,T.kindOf(xml))
    p.rowCount=size.lanes;p.physicalRows=size.rows;p.rowsPerLane=size.rowsPerLane;p.rowSource=size.rowSource
    p.openers=size.openers;p.sections=size.sections;p.laneKind=size.laneKind;p.workingWidthM=size.widthM
    if filename:match('/fs25_johndeere_1760/1760_12row.xml$') then p.recognizedCleanerOptions=true end
    if configurations~=nil and filename:match('/fs25_johndeere_1760/1760_12row.xml$') then
        configurations=configurations or {}
        local function selected(name)
            local item=g_storeManager:getItemByXMLFilename(filename)
            local items=item and item.configurations and item.configurations[name]
            return items and items[configurations[name] or 1]
        end
        local cleaners=selected('design6')
        if cleaners and cleaners.name=='Precision Plant Air adjust row cleaners' then
            p.rowCleaners='pneumatic';p.rowCleanerCabAdjustment=true
            p.equipment[#p.equipment+1]='Air-adjust row cleaners (existing hydraulic-axis control)'
        end
        for _,entry in ipairs({{'design5','Gauge wheels'},{'design2','Left closing wheel'},{'design3','Right closing wheel'}}) do
            local item=selected(entry[1]);if item then p.equipment[#p.equipment+1]=entry[2]..': '..item.name end
        end
    end
    -- Factory-fitted monitored hardware comes with its own display.
    for _,cap in ipairs({'seedMonitor','blockageMonitor','soilSensor','autoShutoffController','automaticDownforce','automaticClosing','rowCleanerDisplayControl'}) do if p[cap] then p.factoryDisplay=true end end
    if p.automaticDownforce then p.cabDownforceControl=true;p.downforceSensor=true end
    if p.automaticClosing then p.improvedClosing=true;p.closingSensor=true;p.cabClosingControl=true end
    if p.rowDrive then p.cabRateControl=true;p.rowShutoff=true end
    return p,size
end
local function describeItem(m,option,kind,size)
    local d=option and (option.description or m.description) or m.description or 'Retrofit hardware. Sensing and automatic control are separate stages.'
    if option and type(option[kind])=='table' then
        local p=option[kind];local parts={}
        if p.base and p.base>0 then parts[#parts+1]=string.format('$%d',p.base) end
        if p.row then parts[#parts+1]=string.format('$%d/row x %d%s',p.row,size.rows>0 and size.rows or T.unknownRows,size.rows>0 and '' or ' (estimated)') end
        if p.opener then parts[#parts+1]=string.format('$%d/opener x %d%s',p.opener,size.openers>0 and size.openers or T.unknownOpeners,size.openers>0 and '' or ' (estimated)') end
        if p.section then parts[#parts+1]=string.format('$%d/section x %d',p.section,size.sections) end
        if #parts>0 then d=d..' Price: '..table.concat(parts,' + ')..'.' end
    end
    return d
end
function T.getConfigurations(manager,original,xml,key,baseDir,environment,isMod,storeItem)
    if manager~=g_vehicleConfigurationManager then return original(manager,xml,key,baseDir,environment,isMod,storeItem) end
    T.register(manager)
    local configs,defaults=original(manager,xml,key,baseDir,environment,isMod,storeItem)
    if key~='vehicle' or not xml:hasProperty('vehicle.sowingMachine') or getXMLBool(xml.handle,'vehicle.sowingMachine.waterSeeding#value')==true then return configs,defaults end
    local kind=T.kindOf(xml)
    local factory,size=T.factory(xml,storeItem and storeItem.xmlFilename)
    configs=configs or {};defaults=defaults or {}
    for _,m in ipairs(T.modules) do
        local list=T.optionsFor(m,kind)
        local cleanersOk=not m.cleaners or factory.recognizedCleanerOptions or factory.rowCleanerCabAdjustment
        if not configs[m.name] and #list>0 and cleanersOk then
            local options=T.options(m,kind,factory,size)
            local items={}
            for index=1,#options+1 do
                local option=options[index-1]
                local item=VehicleConfigurationItem.new(m.name);item:setIndex(index)
                item.configKey=string.format('vehicle.rsPlacement.%sConfigurations.%sConfiguration(%d)',m.name,m.name,index-1)
                item.name=option and option.title or (factory[m.capability] and 'Factory fitted' or 'Standard / not fitted')
                item.saveId=option and option.id or 'standard';item.price=option and T.price(option,kind,size) or 0;item.isDefault=index==1
                item.isSelectable=not (option and option.legacy)
                item.desc=describeItem(m,option,kind,size)
                items[index]=item
            end
            configs[m.name]=items;defaults[m.name]=1
        end
    end
    return configs,defaults
end
local function warn(profile,text) profile.technologyWarnings[#profile.technologyWarnings+1]=text end
function T.apply(profile,configurations,filename,xml)
    if xml then for key,value in pairs(T.factory(xml,filename,configurations)) do profile[key]=value end end
    profile.technologyModules={};profile.technologyLabels={};profile.technologyWarnings={}
    local kind=profile.kind or 'drill'
    for _,m in ipairs(T.modules) do
        local index=configurations and configurations[m.name] or 1
        local item=filename and ConfigurationUtil.getConfigItemByConfigId(filename,m.name,index)
        local chosen
        for _,o in ipairs(T.optionsFor(m,kind)) do if item and item.saveId==o.id then chosen=o end end
        if chosen then for _,cap in ipairs(chosen.caps) do profile[cap]=true end end
        profile.technologyModules[m.name]=chosen and 'retrofit' or (profile[m.capability] and 'factory' or 'notFitted')
        profile.technologyLabels[m.name]=chosen and item.name or (profile[m.capability] and 'Factory fitted' or 'Not fitted')
    end
    T.resolve(profile)
    return profile
end
-- Hardware dependencies. Incomplete combinations stay fitted but inactive.
function T.resolve(profile)
    profile.technologyWarnings=profile.technologyWarnings or {}
    if profile.rowDrive then profile.cabRateControl=true;profile.rowShutoff=true end
    local lanes=profile.rowCount or 0
    local laneWord=profile.laneKind=='section' and 'section' or 'row'
    if (profile.rowShutoff or profile.rowDrive) and lanes<1 then
        profile.rowShutoff=false;profile.rowDrive=false
        warn(profile,'Row/section shutoff: the row count or working width is unknown for this machine.')
    end
    local monitor=profile.settingsLogging==true or profile.factoryDisplay==true
    local function needsMonitor(cap,label)
        if profile[cap] and not monitor then profile[cap]=false;warn(profile,label..' inactive: fit a '..(profile.kind=='planter' and 'planter' or 'seeding')..' monitor.') end
    end
    needsMonitor('seedMonitor',profile.kind=='planter' and 'Seed sensors' or 'Seed counting')
    needsMonitor('blockageMonitor','Blockage monitoring')
    needsMonitor('soilSensor','Soil sensing')
    needsMonitor('autoShutoffController','Automatic GPS '..laneWord..' shutoff')
    needsMonitor('rowCleanerDisplayControl','Row cleaner control')
    if profile.automaticDownforce and not monitor then profile.automaticDownforce=false;warn(profile,'Automatic downforce inactive: fit a planter monitor. Cab adjustment still works.') end
    if profile.automaticClosing and not monitor then profile.automaticClosing=false;warn(profile,'Automatic closing inactive: fit a planter monitor. Cab adjustment still works.') end
    if profile.autoShutoffController and not profile.rowShutoff then
        warn(profile,'Automatic '..laneWord..' shutoff needs '..(laneWord=='row' and 'row clutches or electric row drives.' or 'section shutoff on the meter drive.'))
    end
    if profile.rowCleanerDisplayControl and not profile.rowCleanerCabAdjustment then
        profile.rowCleanerDisplayControl=false;warn(profile,'Row cleaner control: fit the recognized air-adjust cleaners first.')
    end
    profile.automaticDepth=profile.cabDepthControl==true and profile.soilSensor==true
    profile.controlledDelivery=profile.controlledDeliveryHardware==true and profile.precisionMeter==true and profile.rowDrive==true
    if profile.controlledDeliveryHardware and not profile.controlledDelivery then warn(profile,'High-speed delivery inactive: precision meters and electric row drives are both required.') end
    return profile
end
function T.describe(profile)
    local lines={profile.equipmentCheck or 'Equipment profile'}
    local kind=profile.kind or 'drill'
    if kind=='planter' and (profile.physicalRows or 0)>0 then
        lines[#lines+1]=string.format('Rows: %d (%s)%s',profile.physicalRows,({profile='equipment profile',known='known model',name='model name',file='file name',width='working width / 30 in'})[profile.rowSource] or 'estimated',
            (profile.rowsPerLane or 1)>1 and string.format(', controlled in %d-row sections',profile.rowsPerLane) or '')
    elseif kind=='drill' and (profile.openers or 0)>0 then
        lines[#lines+1]=string.format('Openers: about %d, %d shutoff sections',profile.openers,profile.sections or 0)
    end
    for _,m in ipairs(T.modules) do if #T.optionsFor(m,kind)>0 then lines[#lines+1]=m.title..': '..(profile.technologyLabels and profile.technologyLabels[m.name] or (profile[m.capability] and 'Fitted' or 'Not fitted')) end end
    for _,name in ipairs(profile.equipment or {}) do lines[#lines+1]=name end
    for _,warning in ipairs(profile.technologyWarnings or {}) do lines[#lines+1]=warning end
    lines[#lines+1]='Other hardware may need an equipment profile. Individual upgrades are available through workshop customization.'
    return table.concat(lines,'\n')
end
if ConfigurationUtil and Utils then ConfigurationUtil.getConfigurationsFromXML=Utils.overwrittenFunction(ConfigurationUtil.getConfigurationsFromXML,T.getConfigurations) end
