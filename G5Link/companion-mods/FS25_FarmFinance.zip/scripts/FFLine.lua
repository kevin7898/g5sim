-- FS25_FarmFinance - operating line of credit (pure rules).
--
-- A revolving line for running costs: draw and repay any time, interest
-- monthly on what is drawn, at a variable rate (market base + operating
-- spread + credit grade, re-priced every month). Like a real farm operating
-- line it must be paid down to zero at least once each crop year. Whatever
-- is still drawn at the clean-up period (after harvest) without having
-- touched zero becomes a carryover term loan, and counts against credit.
-- The limit is re-set at each clean-up from the operating loan rules.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region
local C = FF.Credit

FF.Line = {}
local LN = FF.Line

local function env()
    return FF.env or {}
end

local function addMoney(amount, farmId, typeKey)
    if amount ~= 0 and env().addMoney ~= nil then
        env().addMoney(amount, farmId, typeKey)
    end
end

local function notify(farmId, text, isWarning)
    if env().notify ~= nil then
        env().notify(farmId, text, isWarning)
    end
end

local function markDirty()
    if env().markDirty ~= nil then
        env().markDirty()
    end
end

function LN.isEnabled()
    return R.get("line.enabled", true) ~= false
end

function LN.get(farm)
    if farm == nil or farm.line == nil or not farm.line.open then
        return nil
    end
    return farm.line
end

function LN.getRate(farm)
    return C.rateFor(FF.state.baseRate or 0.065, "operating", farm.lastScore or 700)
end

-- Limit the bank would set today (operating rules, own balance added back).
function LN.quoteLimit(farmId)
    local farm = FF.Bank.getFarm(farmId)
    local quote = FF.Bank.quote(farmId, "operating", 1, nil)
    local line = LN.get(farm)
    local own = line ~= nil and line.balance or 0
    return math.max(math.floor((quote.limit + own) / 100) * 100, 0), quote
end

function LN.open(farmId)
    if not LN.isEnabled() then
        return false, "ff_reason_productDisabled"
    end
    local farm = FF.Bank.getFarm(farmId)
    if LN.get(farm) ~= nil then
        return false, "ff_reason_lineOpen"
    end
    local limit, quote = LN.quoteLimit(farmId)
    if quote.score < R.get("credit.minScore", 580) then
        return false, "ff_reason_score"
    end
    if limit < R.get("loans.minAmount", 5000) then
        return false, "ff_reason_noRoom"
    end
    farm.line = {
        open = true,
        limit = limit,
        balance = 0,
        cleanedThisYear = true,
        openedMonth = FF.state.monthIndex
    }
    notify(farmId, U.text("ff_msg_lineOpened", U.money(limit), U.percent(LN.getRate(farm))), false)
    markDirty()
    return true
end

function LN.draw(farmId, amount)
    local farm = FF.Bank.getFarm(farmId, false)
    local line = LN.get(farm)
    if line == nil then
        return false, "ff_reason_noLine"
    end
    amount = math.floor(amount or 0)
    if amount <= 0 then
        return false, "ff_reason_tooSmall"
    end
    if line.balance + amount > line.limit + 0.5 then
        return false, "ff_reason_overLimit"
    end
    line.balance = line.balance + amount
    addMoney(amount, farmId, "lineDraw")
    markDirty()
    return true
end

function LN.repay(farmId, amount)
    local farm = FF.Bank.getFarm(farmId, false)
    local line = LN.get(farm)
    if line == nil then
        return false, "ff_reason_noLine"
    end
    amount = math.min(amount or line.balance, line.balance)
    if amount <= 0 then
        return false, "ff_reason_nothingOwed"
    end
    if env().getMoney ~= nil and env().getMoney(farmId) < amount then
        return false, "ff_reason_noCash"
    end
    line.balance = line.balance - amount
    if line.balance <= 0.5 then
        line.balance = 0
        line.cleanedThisYear = true
    end
    addMoney(-amount, farmId, "lineRepay")
    markDirty()
    return true
end

function LN.close(farmId)
    local farm = FF.Bank.getFarm(farmId, false)
    local line = LN.get(farm)
    if line == nil then
        return false, "ff_reason_noLine"
    end
    if line.balance > 0 then
        return false, "ff_reason_lineNotZero"
    end
    farm.line = nil
    markDirty()
    return true
end

-- Monthly (called by the bank for each farm). Returns interest charged and
-- whether a carryover happened (a black mark on payment history).
function LN.processMonth(farm, period)
    local line = LN.get(farm)
    if line == nil then
        return 0, false
    end
    local charged = 0
    local carried = false
    if line.balance > 0 then
        local interest = line.balance * LN.getRate(farm) / 12
        addMoney(-interest, farm.farmId, "loanInterest")
        farm.ledger.interestPaid = (farm.ledger.interestPaid or 0) + interest
        charged = interest
    else
        -- A month spent at zero counts as the yearly clean-up.
        line.cleanedThisYear = true
    end

    if period == R.get("line.cleanUpPeriod", 10) then
        if not line.cleanedThisYear and line.balance > 0 then
            local years = R.get("line.carryoverYears", 3)
            local rate = LN.getRate(farm) + R.get("line.carryoverSpread", 0.01)
            FF.Bank.createLoan(farm.farmId, {
                productId = "operating",
                amount = line.balance,
                months = years * 12,
                rate = rate,
                source = "line",
                label = U.text("ff_label_carryover"),
                noDisbursement = true
            })
            notify(farm.farmId, U.text("ff_msg_lineCarryover", U.money(line.balance), years), true)
            line.balance = 0
            carried = true
        end
        -- A new crop year of the line starts: it has to touch zero again.
        line.cleanedThisYear = false
        line.limit = LN.quoteLimit(farm.farmId)
    end
    return charged, carried
end

return LN
