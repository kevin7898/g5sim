-- FS25_FarmFinance - region data: schema, inheritance and selection.
--
-- Rules live in code; numbers live in region XML files. A region names a
-- parent and only overrides what differs. Values are flattened to dotted
-- keys ("land.rentToValue", "rates.spread.realEstate.value") so inheritance
-- works key by key. Plain lists (rent payment dates) replace the parent's
-- list as a whole.
--
-- The resolver is pure Lua. The XML loader talks to FS only through a small
-- adapter (getString/getFloat/getInt/getBool/iterate), so tests can feed it
-- a fake document.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util

FF.Region = FF.Region or {}
local R = FF.Region

R.ROOT = "farmFinanceRegion"
R.SCHEMA_VERSION = 1

R.SCHEMA = {
    {key = "name", path = "name", type = "string"},
    {key = "sources", path = "sources", type = "string"},
    {key = "units.area", path = "units#area", type = "string"},
    {key = "units.currency", path = "units#currency", type = "string"},
    {key = "units.gameUnitsPerCurrency", path = "units#gameUnitsPerCurrency", type = "float"},

    {key = "land.rentToValue", path = "land.rentToValue#value", type = "float"},
    {key = "land.rentToValueMin", path = "land.rentToValue#min", type = "float"},
    {key = "land.rentToValueMax", path = "land.rentToValue#max", type = "float"},
    {key = "land.rentBenchmark", path = "land.rentBenchmark#value", type = "float"},
    {key = "land.rentOutFactor", path = "land.rentOutFactor#value", type = "float"},
    {key = "land.lease.termYears", path = "land.lease#termYears", type = "int"},
    {key = "land.lease.autoRenew", path = "land.lease#autoRenew", type = "bool"},
    {key = "land.lease.renegotiateEveryYears", path = "land.lease#renegotiateEveryYears", type = "int"},
    {key = "land.lease.noticeDeadlinePeriod", path = "land.lease#noticeDeadlinePeriod", type = "int"},
    {key = "land.lease.landlordNonRenewChance", path = "land.lease#landlordNonRenewChance", type = "float"},
    {key = "land.lease.tenantNonRenewChance", path = "land.lease#tenantNonRenewChance", type = "float"},
    {key = "land.cropShare.enabled", path = "land.cropShare#enabled", type = "bool"},
    {key = "land.cropShare.defaultTerm", path = "land.cropShare#defaultTerm", type = "string"},
    {key = "land.cropShare.sellByPeriod", path = "land.cropShare#sellByPeriod", type = "int"},
    {key = "land.cropShare.storageFeePerMonth", path = "land.cropShare#storageFeePerMonth", type = "float"},

    {key = "rates.base.start", path = "rates.base#start", type = "float"},
    {key = "rates.base.min", path = "rates.base#min", type = "float"},
    {key = "rates.base.max", path = "rates.base#max", type = "float"},
    {key = "rates.base.stepPerMonth", path = "rates.base#stepPerMonth", type = "float"},
    {key = "rates.latePenalty", path = "rates.latePenalty#value", type = "float"},

    {key = "loans.minAmount", path = "loans.minAmount#value", type = "float"},
    {key = "loans.defaultAfterLateMonths", path = "loans.defaultAfterLateMonths#value", type = "int"},

    {key = "credit.scale", path = "credit#scale", type = "string"},
    {key = "credit.label", path = "credit#label", type = "string"},
    {key = "credit.minScore", path = "credit.minScore#value", type = "int"},
    {key = "credit.reviewPeriod", path = "credit.reviewPeriod#value", type = "int"},
    {key = "credit.minHistoryMonths", path = "credit.minHistoryMonths#value", type = "int"},
    {key = "credit.collateral.land", path = "credit.collateral#land", type = "float"},
    {key = "credit.collateral.machinery", path = "credit.collateral#machinery", type = "float"},
    {key = "credit.collateral.buildings", path = "credit.collateral#buildings", type = "float"},
    {key = "credit.operating.incomeShare", path = "credit.operating#incomeShare", type = "float"},
    {key = "credit.operating.assetShare", path = "credit.operating#assetShare", type = "float"},

    {key = "inputs.account.enabled", path = "inputs.account#enabled", type = "bool"},
    {key = "inputs.account.name", path = "inputs.account#name", type = "string"},
    {key = "inputs.account.dueDatePeriod", path = "inputs.account#dueDatePeriod", type = "int"},
    {key = "inputs.account.nextSeasonFromPeriod", path = "inputs.account#nextSeasonFromPeriod", type = "int"},
    {key = "inputs.account.pastDueSpread", path = "inputs.account#pastDueSpread", type = "float"},
    {key = "inputs.account.limitShareOfAssets", path = "inputs.account#limitShareOfAssets", type = "float"},
    {key = "inputs.account.minLimit", path = "inputs.account#minLimit", type = "float"},
    {key = "inputs.account.maxLimit", path = "inputs.account#maxLimit", type = "float"},
    {key = "inputs.fillTypes", path = "inputs.fillTypes", type = "string"},

    {key = "equipment.loan.minDownPayment", path = "equipment.loan#minDownPayment", type = "float"},
    {key = "equipment.loan.usedSpread", path = "equipment.loan#usedSpread", type = "float"},
    {key = "equipment.promo.enabled", path = "equipment.promo#enabled", type = "bool"},
    {key = "equipment.promo.brandsPerMonth", path = "equipment.promo#brandsPerMonth", type = "int"},
    {key = "equipment.promo.months", path = "equipment.promo#months", type = "numberList"},
    {key = "equipment.promo.rebate", path = "equipment.promo#rebate", type = "float"},
    {key = "equipment.promo.minPrice", path = "equipment.promo#minPrice", type = "float"},
    {key = "equipment.promo.durationMonths", path = "equipment.promo#durationMonths", type = "int"},
    {key = "equipment.lease.enabled", path = "equipment.lease#enabled", type = "bool"},
    {key = "equipment.lease.termYears", path = "equipment.lease#termYears", type = "numberList"},
    {key = "equipment.lease.hoursPerYear", path = "equipment.lease#hoursPerYear", type = "numberList"},
    {key = "equipment.lease.spread", path = "equipment.lease#spread", type = "float"},
    {key = "equipment.lease.residualMargin", path = "equipment.lease#residualMargin", type = "float"},
    {key = "equipment.lease.depositPayments", path = "equipment.lease#depositPayments", type = "float"},
    {key = "equipment.lease.excessHourShare", path = "equipment.lease#excessHourShare", type = "float"},
    {key = "equipment.lease.extendDepreciation", path = "equipment.lease#extendDepreciation", type = "float"},
    {key = "equipment.rental.depositScale", path = "equipment.rental#depositScale", type = "float"},
    {key = "equipment.rental.perDayScale", path = "equipment.rental#perDayScale", type = "float"},
    {key = "equipment.rental.perHourScale", path = "equipment.rental#perHourScale", type = "float"},

    {key = "line.enabled", path = "line#enabled", type = "bool"},
    {key = "line.cleanUpPeriod", path = "line#cleanUpPeriod", type = "int"},
    {key = "line.carryoverSpread", path = "line#carryoverSpread", type = "float"},
    {key = "line.carryoverYears", path = "line#carryoverYears", type = "int"}
}

-- Repeated elements identified by an attribute: flattened as prefix.id.field
R.KEYED_LISTS = {
    {prefix = "rates.spread", path = "rates.spread", idAttr = "product", fields = {value = "float"}},
    {prefix = "rates.riskSpread", path = "rates.riskSpread", idAttr = "grade", fields = {value = "float", minScore = "int"}},
    {prefix = "credit.ratio", path = "credit.ratio", idAttr = "id", fields = {strong = "float", weak = "float"}},
    {prefix = "loans.product", path = "loans.product", idAttr = "id",
        fields = {termYears = "numberList", defaultTermYears = "int", collateral = "string", enabled = "bool"}},
    {prefix = "land.cropShareTerm", path = "land.cropShare.term", idAttr = "id",
        fields = {landownerShare = "float", inputShare = "float", enabled = "bool", order = "int"}}
}

-- Ordered lists replaced as a whole by a child region
R.LISTS = {
    {key = "land.rentPayments", path = "land.rentPayments.payment", fields = {period = "int", share = "float"}},
    -- cash discount on inputs bought in a given crop period (prepaying for next season)
    {key = "inputs.earlyPay", path = "inputs.earlyPay.step", fields = {period = "int", discount = "float"}}
}

R.regions = R.regions or {}
R.order = R.order or {}
R.mapRules = R.mapRules or {}
R.active = R.active or nil

function R.reset()
    R.regions = {}
    R.order = {}
    R.mapRules = {}
    R.active = nil
end

local function readTyped(adapter, path, valueType)
    if valueType == "float" then
        return adapter.getFloat(path)
    elseif valueType == "int" then
        local value = adapter.getInt(path)
        if value ~= nil then
            return math.floor(value)
        end
        return nil
    elseif valueType == "bool" then
        return adapter.getBool(path)
    elseif valueType == "numberList" then
        local text = adapter.getString(path)
        if text ~= nil then
            return U.numberList(text)
        end
        return nil
    end
    return adapter.getString(path)
end

-- Reads one region document through an adapter. Returns a region record
-- or nil plus an error text.
function R.readRegion(adapter, sourceName)
    local root = R.ROOT
    local id = adapter.getString(root .. "#id")
    if id == nil or id == "" then
        return nil, "missing id"
    end

    local region = {
        id = id,
        parent = adapter.getString(root .. "#parent"),
        abstract = adapter.getBool(root .. "#abstract") == true,
        schemaVersion = adapter.getInt(root .. "#schemaVersion") or 1,
        source = sourceName,
        values = {}
    }
    if region.parent == "" then
        region.parent = nil
    end
    if region.schemaVersion > R.SCHEMA_VERSION then
        U.warn("region '%s' uses schema %d, this build knows %d; loading what it can", id, region.schemaVersion, R.SCHEMA_VERSION)
    end

    for _, entry in ipairs(R.SCHEMA) do
        local value = readTyped(adapter, root .. "." .. entry.path, entry.type)
        if value ~= nil then
            region.values[entry.key] = value
        end
    end

    for _, list in ipairs(R.KEYED_LISTS) do
        adapter.iterate(root .. "." .. list.path, function(_, key)
            local itemId = adapter.getString(key .. "#" .. list.idAttr)
            if itemId ~= nil and itemId ~= "" then
                for field, fieldType in pairs(list.fields) do
                    local value = readTyped(adapter, key .. "#" .. field, fieldType)
                    if value ~= nil then
                        region.values[list.prefix .. "." .. itemId .. "." .. field] = value
                    end
                end
            end
        end)
    end

    for _, list in ipairs(R.LISTS) do
        local items = {}
        adapter.iterate(root .. "." .. list.path, function(_, key)
            local item = {}
            for field, fieldType in pairs(list.fields) do
                item[field] = readTyped(adapter, key .. "#" .. field, fieldType)
            end
            items[#items + 1] = item
        end)
        if #items > 0 then
            region.values[list.key] = items
        end
    end

    return region
end

function R.register(region)
    if R.regions[region.id] ~= nil then
        U.log("region '%s' from %s replaces the one from %s", region.id, tostring(region.source), tostring(R.regions[region.id].source))
    else
        R.order[#R.order + 1] = region.id
    end
    R.regions[region.id] = region
end

function R.addMapRule(match, regionId)
    if match ~= nil and match ~= "" and regionId ~= nil and regionId ~= "" then
        table.insert(R.mapRules, {match = string.lower(match), region = regionId})
    end
end

-- Builds the parent chain root-first. Returns chain or nil plus an error.
function R.getChain(regionId)
    local chain = {}
    local seen = {}
    local currentId = regionId
    while currentId ~= nil do
        if seen[currentId] then
            return nil, "parent loop at '" .. currentId .. "'"
        end
        seen[currentId] = true
        local region = R.regions[currentId]
        if region == nil then
            return nil, "unknown region '" .. currentId .. "'"
        end
        table.insert(chain, 1, region)
        currentId = region.parent
    end
    return chain
end

function R.resolve(regionId)
    local chain, err = R.getChain(regionId)
    if chain == nil then
        return nil, err
    end
    local values = {}
    local origin = {}
    for _, region in ipairs(chain) do
        for key, value in pairs(region.values) do
            values[key] = U.deepCopy(value)
            origin[key] = region.id
        end
    end
    local ids = {}
    for _, region in ipairs(chain) do
        ids[#ids + 1] = region.id
    end
    return {id = regionId, values = values, origin = origin, chain = ids}
end

function R.activate(regionId)
    local resolved, err = R.resolve(regionId)
    if resolved == nil then
        U.warn("could not use region '%s' (%s); falling back to _base", tostring(regionId), tostring(err))
        resolved = R.resolve("_base")
        if resolved == nil then
            resolved = {id = "_base", values = {}, origin = {}, chain = {}}
        end
    end
    R.active = resolved
    return resolved
end

-- Used by multiplayer clients: the server sends resolved values.
function R.setActiveResolved(regionId, values)
    R.active = {id = regionId, values = values or {}, origin = {}, chain = {regionId}}
end

function R.get(key, default)
    if R.active ~= nil then
        local value = R.active.values[key]
        if value ~= nil then
            return value
        end
    end
    return default
end

function R.getActiveId()
    return R.active ~= nil and R.active.id or "_base"
end

function R.getName(regionId)
    local region = R.regions[regionId or R.getActiveId()]
    if region ~= nil and region.values.name ~= nil then
        return region.values.name
    end
    if regionId == nil or regionId == R.getActiveId() then
        local name = R.get("name")
        if name ~= nil then
            return name
        end
    end
    return regionId or "?"
end

-- Selectable regions, in load order (abstract ones hidden).
function R.listSelectable()
    local list = {}
    for _, id in ipairs(R.order) do
        local region = R.regions[id]
        if region ~= nil and not region.abstract and id ~= "_base" then
            list[#list + 1] = id
        end
    end
    return list
end

-- Picks the region for a save: saved choice > map rule > fallback.
function R.select(savedId, mapTitle, mapName)
    if savedId ~= nil and savedId ~= "" and R.regions[savedId] ~= nil then
        return savedId, "saved"
    end
    local haystacks = {}
    if mapTitle ~= nil then
        haystacks[#haystacks + 1] = string.lower(mapTitle)
    end
    if mapName ~= nil then
        haystacks[#haystacks + 1] = string.lower(mapName)
    end
    for _, rule in ipairs(R.mapRules) do
        for _, haystack in ipairs(haystacks) do
            if string.find(haystack, rule.match, 1, true) ~= nil and R.regions[rule.region] ~= nil then
                return rule.region, "map"
            end
        end
    end
    if R.regions.us_cornbelt ~= nil then
        return "us_cornbelt", "default"
    end
    return "_base", "default"
end

-- Convenience accessors used by the rules code -------------------------

function R.getProductTerms(productId)
    local terms = R.get("loans.product." .. productId .. ".termYears")
    if type(terms) ~= "table" or #terms == 0 then
        return {1}
    end
    return terms
end

function R.isProductEnabled(productId)
    return R.get("loans.product." .. productId .. ".enabled", true) ~= false
end

function R.getRiskSpread(grade)
    return R.get("rates.riskSpread." .. grade .. ".value", 0)
end

function R.getRatio(ratioId)
    return R.get("credit.ratio." .. ratioId .. ".strong"), R.get("credit.ratio." .. ratioId .. ".weak")
end

-- Ids of a keyed list in the active region, sorted by their "order" field.
function R.listKeyedIds(prefix)
    local ids, seen = {}, {}
    if R.active == nil then
        return ids
    end
    local pattern = "^" .. string.gsub(prefix, "%.", "%%.") .. "%.([^%.]+)%."
    for key in pairs(R.active.values) do
        local id = string.match(key, pattern)
        if id ~= nil and not seen[id] then
            seen[id] = true
            ids[#ids + 1] = id
        end
    end
    table.sort(ids, function(a, b)
        local orderA = R.get(prefix .. "." .. a .. ".order", 99)
        local orderB = R.get(prefix .. "." .. b .. ".order", 99)
        if orderA ~= orderB then
            return orderA < orderB
        end
        return a < b
    end)
    return ids
end

-- Crop-share terms offered in the active region, as
-- {id, landownerShare, inputShare}, default first.
function R.getCropShareTerms()
    local terms = {}
    if R.get("land.cropShare.enabled", false) ~= true then
        return terms
    end
    local defaultId = R.get("land.cropShare.defaultTerm")
    for _, id in ipairs(R.listKeyedIds("land.cropShareTerm")) do
        local prefix = "land.cropShareTerm." .. id
        if R.get(prefix .. ".enabled", true) ~= false then
            local term = {
                id = id,
                landownerShare = R.get(prefix .. ".landownerShare", 0.5),
                inputShare = R.get(prefix .. ".inputShare", 0)
            }
            if id == defaultId then
                table.insert(terms, 1, term)
            else
                terms[#terms + 1] = term
            end
        end
    end
    return terms
end

-- FS XML adapter ------------------------------------------------------

function R.makeXmlAdapter(xmlFile)
    return {
        getString = function(path)
            return xmlFile:getString(path)
        end,
        getFloat = function(path)
            return xmlFile:getFloat(path)
        end,
        getInt = function(path)
            return xmlFile:getInt(path)
        end,
        getBool = function(path)
            return xmlFile:getBool(path)
        end,
        iterate = function(path, callback)
            xmlFile:iterate(path, callback)
        end
    }
end

local function directoryOf(filename)
    return string.match(filename, "^(.*[/\\])") or ""
end

function R.loadRegionFile(filename, sourceName)
    if fileExists == nil or not fileExists(filename) then
        U.warn("region file not found: %s", filename)
        return false
    end
    local xmlFile = XMLFile.load("ffRegion", filename)
    if xmlFile == nil then
        U.warn("could not read region file %s", filename)
        return false
    end
    local region, err = R.readRegion(R.makeXmlAdapter(xmlFile), sourceName)
    xmlFile:delete()
    if region == nil then
        U.warn("region file %s skipped: %s", filename, tostring(err))
        return false
    end
    R.register(region)
    return true
end

function R.loadMapRules(filename)
    if fileExists == nil or not fileExists(filename) then
        return
    end
    local xmlFile = XMLFile.load("ffMapRegions", filename)
    if xmlFile == nil then
        return
    end
    xmlFile:iterate("farmFinanceMapRegions.map", function(_, key)
        R.addMapRule(xmlFile:getString(key .. "#match"), xmlFile:getString(key .. "#region"))
    end)
    xmlFile:delete()
end

-- Loads an index file: <farmFinanceRegions><region file="x.xml"/><mapRegions file="m.xml"/></farmFinanceRegions>
function R.loadIndex(indexFilename, sourceName)
    if fileExists == nil or not fileExists(indexFilename) then
        return 0
    end
    local xmlFile = XMLFile.load("ffRegionIndex", indexFilename)
    if xmlFile == nil then
        return 0
    end
    local baseDir = directoryOf(indexFilename)
    local files = {}
    local mapFiles = {}
    xmlFile:iterate("farmFinanceRegions.region", function(_, key)
        local file = xmlFile:getString(key .. "#file")
        if file ~= nil and file ~= "" then
            files[#files + 1] = baseDir .. file
        end
    end)
    xmlFile:iterate("farmFinanceRegions.mapRegions", function(_, key)
        local file = xmlFile:getString(key .. "#file")
        if file ~= nil and file ~= "" then
            mapFiles[#mapFiles + 1] = baseDir .. file
        end
    end)
    xmlFile:delete()

    local count = 0
    for _, filename in ipairs(files) do
        if R.loadRegionFile(filename, sourceName) then
            count = count + 1
        end
    end
    for _, filename in ipairs(mapFiles) do
        R.loadMapRules(filename)
    end
    return count
end

-- Loads all three locations in order: this mod, other mods, modSettings.
function R.loadAll(modDirectory)
    R.reset()
    local total = R.loadIndex(modDirectory .. "regions/index.xml", FF.MOD_NAME)

    if g_modIsLoaded ~= nil and g_modManager ~= nil and g_modManager.getModByName ~= nil then
        for _, modName in ipairs(U.sortedKeys(g_modIsLoaded)) do
            if g_modIsLoaded[modName] == true and modName ~= FF.MOD_NAME then
                local ok, mod = pcall(g_modManager.getModByName, g_modManager, modName)
                local modDir = ok and type(mod) == "table" and mod.modDir or nil
                if type(modDir) == "string" then
                    local indexFile = modDir .. "farmFinance/regions.xml"
                    if fileExists(indexFile) then
                        total = total + R.loadIndex(indexFile, modName)
                    end
                end
            end
        end
    end

    if getUserProfileAppPath ~= nil then
        local userIndex = getUserProfileAppPath() .. "modSettings/FS25_FarmFinance/regions/index.xml"
        total = total + R.loadIndex(userIndex, "modSettings")
    end

    U.log("loaded %d region file(s), %d map rule(s)", total, #R.mapRules)
    return total
end

return R
