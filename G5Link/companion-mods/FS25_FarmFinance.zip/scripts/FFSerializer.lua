-- FS25_FarmFinance - compact table serializer (pure Lua 5.1).
-- Used to send the whole finance state to multiplayer clients as text.
-- Supports nil, booleans, finite numbers, strings and nested tables
-- (no cycles, no functions).

FarmFinance = FarmFinance or {}
local FF = FarmFinance

FF.Serializer = {}
local S = FF.Serializer

local function encodeValue(value, out, depth)
    if depth > 32 then
        error("FarmFinance serializer: table nesting too deep")
    end
    local valueType = type(value)
    if value == nil then
        out[#out + 1] = "n"
    elseif valueType == "boolean" then
        out[#out + 1] = value and "T" or "F"
    elseif valueType == "number" then
        if value ~= value or value == math.huge or value == -math.huge then
            value = 0
        end
        -- %d goes through a C long, which is 32-bit on Windows.
        if value == math.floor(value) and math.abs(value) < 2 ^ 31 then
            out[#out + 1] = "i" .. string.format("%d", value) .. ";"
        else
            out[#out + 1] = "d" .. string.format("%.17g", value) .. ";"
        end
    elseif valueType == "string" then
        out[#out + 1] = "s" .. tostring(#value) .. ":" .. value
    elseif valueType == "table" then
        local keys = {}
        for key, item in pairs(value) do
            local keyType = type(key)
            local itemType = type(item)
            if (keyType == "string" or keyType == "number") and itemType ~= "function" and itemType ~= "userdata" then
                keys[#keys + 1] = key
            end
        end
        out[#out + 1] = "t" .. tostring(#keys) .. ":"
        for _, key in ipairs(keys) do
            encodeValue(key, out, depth + 1)
            encodeValue(value[key], out, depth + 1)
        end
    else
        out[#out + 1] = "n"
    end
end

function S.encode(value)
    local out = {}
    encodeValue(value, out, 0)
    return table.concat(out)
end

local function decodeValue(text, position, depth)
    if depth > 32 then
        error("FarmFinance serializer: table nesting too deep")
    end
    local tag = string.sub(text, position, position)
    if tag == "n" then
        return nil, position + 1
    elseif tag == "T" then
        return true, position + 1
    elseif tag == "F" then
        return false, position + 1
    elseif tag == "i" or tag == "d" then
        local stop = string.find(text, ";", position + 1, true)
        if stop == nil then
            error("FarmFinance serializer: unterminated number")
        end
        local number = tonumber(string.sub(text, position + 1, stop - 1))
        return number or 0, stop + 1
    elseif tag == "s" then
        local colon = string.find(text, ":", position + 1, true)
        if colon == nil then
            error("FarmFinance serializer: bad string header")
        end
        local length = tonumber(string.sub(text, position + 1, colon - 1)) or 0
        local first = colon + 1
        return string.sub(text, first, first + length - 1), first + length
    elseif tag == "t" then
        local colon = string.find(text, ":", position + 1, true)
        if colon == nil then
            error("FarmFinance serializer: bad table header")
        end
        local count = tonumber(string.sub(text, position + 1, colon - 1)) or 0
        local result = {}
        local cursor = colon + 1
        for _ = 1, count do
            local key, item
            key, cursor = decodeValue(text, cursor, depth + 1)
            item, cursor = decodeValue(text, cursor, depth + 1)
            if key ~= nil then
                result[key] = item
            end
        end
        return result, cursor
    end
    error("FarmFinance serializer: unknown tag '" .. tostring(tag) .. "' at " .. tostring(position))
end

function S.decode(text)
    if text == nil or text == "" then
        return nil
    end
    local value = decodeValue(text, 1, 0)
    return value
end

-- Splits a long string into chunks for network streams.
function S.chunk(text, size)
    size = size or 1000
    local chunks = {}
    local length = #text
    local position = 1
    while position <= length do
        chunks[#chunks + 1] = string.sub(text, position, position + size - 1)
        position = position + size
    end
    if #chunks == 0 then
        chunks[1] = ""
    end
    return chunks
end

return S
