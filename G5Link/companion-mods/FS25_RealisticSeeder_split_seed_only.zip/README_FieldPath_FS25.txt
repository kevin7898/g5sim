FieldPath Realistic Seeder 2.0.0.0 - Phase 3 Preview

This build keeps the stable 1.0 crop-specific seed fill types, shop items, ProBox product-selector mapping, and FieldPath state output.

Phase 3 adds seed management metadata for FieldPath:
- seed brand catalog
- crop variety / hybrid catalog
- seed lot catalog
- germination percentage
- vigor percentage
- treatment package catalog
- seed package size / seeds per package
- inventory example
- planting record schema

Runtime output is written to:
modSettings/FS25_FieldPathCommand/

Important: Phase 3 does not yet force every purchased pallet/probox to create a unique inventory lot inside FS25. For now, FS25 still handles the physical fill type, and FieldPath gets the data model it needs to create seed inventory, purchase records, transfer records, and planting records.


0.1.0.28 notes
----------------
- Added a native ProBox Products selector hook for the original LAC ProBox store item.
- The original ProBox item, model, store image, brand selector, product label textures, and ProBox mod assets stay intact and external.
- The ProBox Products selector now maps supported products to RealisticSeeder fill types after purchase/load, e.g. Beans -> SEED_SOYBEAN, Corn/Corn Silage -> SEED_MAIZE, Wheat -> SEED_WHEAT.
- Runtime ProBox wrapper store entries are disabled by default to avoid duplicate ProBox shop entries.
- Unsupported ProBox product labels without matching RealisticSeeder fill types yet, such as Flax, Lentil, and Peas, are left as the base ProBox fill type for now.

FieldPath Realistic Seeder - FS25 prototype 0.1.0.28

This build intentionally includes only individual crop-specific seed pallets.
It keeps the custom seed fill types and FieldPath telemetry, while leaving ProBox integration for a soft hook once the ProBox mod package is available.

Expected log line:
Available mod: ... (Version: 0.1.0.20) FS25_RealisticSeeder


0.1.0.20 notes:
- Added soft detection for the LAC ProBox realistic/standard pricing packs.
- Companion RSHook versions of both ProBox packs can spawn crop-specific ProBoxes using the RealisticSeeder seed fill types.
- Pricing mode is selected by which ProBox pack the player installs: RealisticPricing_RSHook or StandardPricing_RSHook.
- FieldPath can read modSettings/FS25_FieldPathCommand/realisticSeederProBoxCompat.json to show the active mode.


v0.1.0.20 seed pricing integration
---------------------------------
RealisticSeeder now includes average crop-specific seed cost defaults and writes FieldPath-readable files to:
  modSettings/FS25_FieldPathCommand/realisticSeederSeedPricingDefaults.json
  modSettings/FS25_FieldPathCommand/realisticSeederSeedPricingSettings.json

FieldPath should calculate accounting cost as:
  finalSeedCostPerAcre = avgUsdPerAcre * globalMultiplier * cropMultiplier

The store XML prices are updated to crop-relative average defaults for the seed pallets. FieldPath can use the JSON settings for per-save or global price adjustments.


v0.1.0.20 note:
ProBox integration is now asset-clean. Do not ship patched copies of the ProBox mods.
Use the lightweight compatibility add-ons instead:
- FS25_RealisticSeederProBoxCompat_RealisticPricing.zip
- FS25_RealisticSeederProBoxCompat_StandardPricing.zip
These add-ons reference the original ProBox mod by $moddir$ path and contain no ProBox meshes, textures, shapes, or store images.


0.1.0.20 notes
----------------
- RealisticSeeder now includes the lightweight ProBox compatibility XMLs in this same mod zip.
- No files from either ProBox mod are redistributed. The XMLs use parentFile references to the original ProBox mods via $moddir$.
- If FS25_LAC_SeedProBoxPackRealisticPricing is installed, RealisticSeeder attempts to register crop-specific realistic ProBox seed entries.
- If FS25_LAC_SeedProBoxPackStandardPricing is installed, RealisticSeeder attempts to register crop-specific standard ProBox seed entries.
- If both are installed, FieldPath can select the pricingPack in modSettings/FS25_FieldPathCommand/realisticSeederProBoxSettings.json. Default is auto, which prefers realistic when both are present.
- If neither ProBox mod is installed, RealisticSeeder still works normally with crop-specific seed pallets only.


0.1.0.20: Fixed ProBox auto detection crash by removing FS25-blocked read-mode io.open calls and removed missing legacy specialization references.


0.1.0.20
- Fixed built-in ProBox compat XML loading by capturing the RealisticSeeder mod directory before loadMap.
- Added nil-safe fruit type handling in shop icon helper for heavily modded crop setups.
- ProBox assets remain external; install the original ProBox pack separately.
- Crop-specific ProBox entries are separate shop entries; the original ProBox item remains base-game SEEDS unless the original ProBox mod itself is edited.


0.1.0.20: Restored buyable seed big bags and seed pallets by writing complete root storeData for FS25 shop scanning and using the known-valid pallets shop category. Runtime ProBox shop injection is disabled to avoid FS25 overwrite-block errors; ProBox detection/status remains available for FieldPath.


0.1.0.20: Removed duplicate direct shop entries and added crop-specific Pioneer small-bag pallet shop entries using FS25 base-game assets.


0.1.0.23
- Normalized all crop-specific seed shop entries and hidden child products to use the FS25 in-game PIONEER brand.
- Added fieldpath/seedBrandMap.json so FieldPath can read the package/brand mapping later.


0.1.0.26: Re-enabled optional ProBox wrapper registration at runtime, removed forced Pioneer brand from ProBox wrappers so the original ProBox brand selector can be used, and added safer store-manager API fallbacks.


0.1.0.27: Rebuilt ProBox compatibility XMLs as complete generated wrappers instead of parentFile overrides, so FS25 no longer rejects them as DLC/mod-file overwrites. ProBox assets remain external.


Phase 3.1 treatment workflow
- FieldPath is intended to be the primary seed inventory and treatment manager.
- RealisticSeeder now ships standalone fallback manifests for untreated seed, pre-treated seed, seed treatment products, and on-farm treatment workflow states.
- Without FieldPath, the crop-specific fill types and shop products keep working normally; the advanced ledger/treatment history is simply not enforced.
- With FieldPath, seed lots can move through states: purchased untreated -> treated on farm -> loaded into tender/planter -> planted to a field record.
