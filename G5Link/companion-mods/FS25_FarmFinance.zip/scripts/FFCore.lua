-- FS25_FarmFinance - core namespace and helpers.
-- Pure Lua 5.1: no FS globals are required at load time, so the offline tests
-- can source this file directly.

FarmFinance = FarmFinance or {}
local FF = FarmFinance

FF.MOD_NAME = g_currentModName or FF.MOD_NAME or "FS25_FarmFinance"
FF.MOD_DIR = g_currentModDirectory or FF.MOD_DIR or ""
FF.VERSION = "0.3.0.0"
FF.STATE_VERSION = 1

-- Conflicting mods, by feature. Matching is by prefix so UsedPlus variants
-- (FS25_UsedPlus, FS25_UsedPlus_ADS_compat, ...) are all caught.
--   bank    : loans, credit, the vanilla loan takeover
--   rentIn  : renting a neighbour's land
--   rentOut : renting your own land to a neighbour
FF.CONFLICTS = {
    bank = {"FS25_UsedPlus", "FS25_BankCredit", "FS25_EnhancedLoanSystem", "FS25_HirePurchasing"},
    rentIn = {"FS25_UsedPlus", "FS25_FieldLeasing"},
    rentOut = {"FS25_RentYourField"}
}
FF.CONFLICT_FEATURES = {"bank", "rentIn", "rentOut"}

function FF.isServer()
    return FF.forceServer == true or g_server ~= nil
end

FF.Util = FF.Util or {}
local U = FF.Util

function U.clamp(value, minValue, maxValue)
    if value < minValue then
        return minValue
    end
    if value > maxValue then
        return maxValue
    end
    return value
end

function U.round(value, decimals)
    local factor = 10 ^ (decimals or 0)
    return math.floor(value * factor + 0.5) / factor
end

function U.isFiniteNumber(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

function U.toNumber(value, fallback)
    local number = tonumber(value)
    if not U.isFiniteNumber(number) then
        return fallback
    end
    return number
end

function U.deepCopy(value, seen)
    if type(value) ~= "table" then
        return value
    end
    seen = seen or {}
    if seen[value] ~= nil then
        return seen[value]
    end
    local copy = {}
    seen[value] = copy
    for key, item in pairs(value) do
        copy[U.deepCopy(key, seen)] = U.deepCopy(item, seen)
    end
    return copy
end

function U.sortedKeys(t)
    local keys = {}
    for key in pairs(t) do
        keys[#keys + 1] = key
    end
    table.sort(keys, function(a, b)
        local ta, tb = type(a), type(b)
        if ta ~= tb then
            return ta < tb
        end
        return a < b
    end)
    return keys
end

function U.count(t)
    local n = 0
    for _ in pairs(t or {}) do
        n = n + 1
    end
    return n
end

function U.split(text, separator)
    local result = {}
    if text == nil or text == "" then
        return result
    end
    separator = separator or ","
    local pattern = "([^" .. separator .. "]+)"
    for part in string.gmatch(text, pattern) do
        local trimmed = U.trim(part)
        if trimmed ~= "" then
            result[#result + 1] = trimmed
        end
    end
    return result
end

function U.trim(text)
    return (string.gsub(text or "", "^%s*(.-)%s*$", "%1"))
end

function U.startsWith(text, prefix)
    return type(text) == "string" and string.sub(text, 1, #prefix) == prefix
end

function U.numberList(text)
    local list = {}
    for _, part in ipairs(U.split(text, ",")) do
        local number = tonumber(part)
        if number ~= nil then
            list[#list + 1] = number
        end
    end
    return list
end

function U.log(fmt, ...)
    print(string.format("[FarmFinance] " .. fmt, ...))
end

function U.warn(fmt, ...)
    print(string.format("[FarmFinance] Warning: " .. fmt, ...))
end

-- Text lookup that works in game (mod-scoped g_i18n) and in tests.
function U.text(key, ...)
    local text = key
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        text = g_i18n:getText(key)
    end
    if select("#", ...) > 0 then
        local ok, formatted = pcall(string.format, text, ...)
        if ok then
            return formatted
        end
    end
    return text
end

function U.money(amount)
    amount = amount or 0
    if g_i18n ~= nil and g_i18n.formatMoney ~= nil then
        -- Same call the base game uses for prices (vendored Vehicle.lua:4317)
        return g_i18n:formatMoney(amount, 0, true, true)
    end
    return string.format("$%.0f", amount)
end

function U.percent(rate, decimals)
    return string.format("%." .. tostring(decimals or 2) .. "f%%", (rate or 0) * 100)
end

return FF
