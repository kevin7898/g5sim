-- All quantities are physical: no map size, terrain multiplier, or foliage count.
RSSeedRate={SQM_PER_ACRE=4046.8564224,KG_PER_LB=0.45359237}
local R=RSSeedRate
function R.litersForArea(areaSqm,ratePerAcre,unit,seedsPerPound,kgPerLiter)
    if not RSPlacementModel.finite(areaSqm) or areaSqm<0 or not RSPlacementModel.finite(ratePerAcre) or ratePerAcre<0
        or not RSPlacementModel.finite(kgPerLiter) or kgPerLiter<=0 then return nil,"Invalid seed calibration" end
    local pounds=areaSqm/R.SQM_PER_ACRE*ratePerAcre
    if unit=="seedsPerAcre" then
        if not RSPlacementModel.finite(seedsPerPound) or seedsPerPound<=0 then return nil,"Seed size is required" end
        pounds=pounds/seedsPerPound
    elseif unit~="poundsPerAcre" then return nil,"Unsupported rate unit" end
    return pounds*R.KG_PER_LB/kgPerLiter
end
local function cross(o,a,b) return (a.x-o.x)*(b.z-o.z)-(a.z-o.z)*(b.x-o.x) end
local function hull(points)
    table.sort(points,function(a,b) return a.x<b.x or (a.x==b.x and a.z<b.z) end)
    local out={}
    for _,p in ipairs(points) do while #out>=2 and cross(out[#out-1],out[#out],p)<=0 do table.remove(out) end;out[#out+1]=p end
    local lower=#out+1
    for i=#points-1,1,-1 do local p=points[i];while #out>=lower and cross(out[#out-1],out[#out],p)<=0 do table.remove(out) end;out[#out+1]=p end
    table.remove(out);return out
end
local function area(points)
    if #points<3 then return 0 end
    -- Translate first to avoid cancellation on large-map coordinates.
    local o=points[1];local sum=0
    for i=2,#points-1 do sum=sum+cross(o,points[i],points[i+1]) end
    return math.abs(sum)*0.5
end
function R.quad(sx,sz,wx,wz,hx,hz)
    return {{x=sx,z=sz},{x=wx,z=wz},{x=wx+hx-sx,z=wz+hz-sz},{x=hx,z=hz}}
end
function R.sweptArea(previous,current,dt,speedKmh)
    local currentArea=area(current)
    if not previous then return currentArea end
    local dx,dz=current[1].x-previous[1].x,current[1].z-previous[1].z
    local length=math.sqrt((current[4].x-current[1].x)^2+(current[4].z-current[1].z)^2)
    local budget=math.max(2,length+(speedKmh or 0)/3.6*math.max(0,dt or 0)/1000*3)
    if dx*dx+dz*dz>budget*budget then return currentArea end -- transport/teleport, not a connecting planting pass
    local points={};for _,p in ipairs(previous) do points[#points+1]=p end;for _,p in ipairs(current) do points[#points+1]=p end
    return math.max(0,area(hull(points))-area(previous))
end
