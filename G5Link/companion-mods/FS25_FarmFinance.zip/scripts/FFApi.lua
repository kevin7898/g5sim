-- FS25_FarmFinance - public API for other mods (see API.md in this mod).
--
-- Find it from another mod with:
--     local api = g_currentMission ~= nil and g_currentMission.farmFinanceAPI or nil
-- (also reachable as FarmFinanceAPI in the global table, when the game allows it).
-- Check api ~= nil and api.isReady() before use. Calls that move money or
-- change state work on the server only and return false, "notServer" on
-- clients. Read calls work everywhere (clients see the synced state).

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util

FarmFinanceAPI = FarmFinanceAPI or {}
local API = FarmFinanceAPI

API.VERSION = "1.0.0"
API.listeners = API.listeners or {}

local function isReady()
    return FF.state ~= nil
end

local function toFillTypeName(fillType)
    if type(fillType) == "number" then
        if g_fillTypeManager ~= nil then
            return g_fillTypeManager:getFillTypeNameByIndex(fillType)
        end
        return nil
    end
    if type(fillType) == "string" then
        return string.upper(fillType)
    end
    return nil
end

local function copy(value)
    return U.deepCopy(value)
end

-- General --------------------------------------------------------------------------

-- Returns API version and mod version.
function API.getVersion()
    return API.VERSION, FF.VERSION
end

-- True once Farm Finance has loaded the savegame (server) or received the
-- server's state (client).
function API.isReady()
    if not isReady() then
        return false
    end
    if FF.isServer() then
        return FF.loaded == true
    end
    return true
end

function API.isServer()
    return FF.isServer()
end

-- True when a conflicting finance mod switched the bank features off.
function API.isBankActive()
    return FF.blocked == nil or not FF.blocked.bank
end

-- Credit -------------------------------------------------------------------------------

-- score (300-850), grade ("A".."E")
function API.getCreditScore(farmId)
    if not isReady() then
        return nil, nil
    end
    local evaluation = FF.Bank.evaluate(farmId)
    return evaluation.score, evaluation.grade
end

-- Input purchases --------------------------------------------------------------------

function API.isInputFillType(fillType)
    return FF.Inputs.isInputFillType(toFillTypeName(fillType))
end

-- Adds a fill type (name) that counts as a farm input for this session.
function API.registerInputFillType(fillTypeName)
    return FF.Inputs.registerFillType(fillTypeName)
end

-- Cash discount for inputs bought right now (0..1), from the region's
-- early-pay schedule.
function API.getEarlyPayDiscount()
    if not isReady() then
        return 0
    end
    return FF.Inputs.getEarlyPayDiscount()
end

-- Snapshot of a farm's input account:
-- {enabled, autoCharge, limit, balance, available, pastDue, dueCropYear,
--  dueDatePeriod, pastDueRate, earlyPayDiscount}
function API.getInputAccount(farmId)
    if not isReady() then
        return nil
    end
    local farm = FF.Bank.getFarm(farmId)
    local account = FF.Inputs.getAccount(farm)
    local balance, pastDue = FF.Inputs.getBalance(farm)
    local available, limit = FF.Inputs.getAvailable(farmId)
    return {
        enabled = FF.Inputs.isEnabled() and API.isBankActive(),
        autoCharge = account.autoCharge,
        limit = limit,
        balance = balance,
        available = available,
        pastDue = pastDue,
        dueCropYear = FF.Inputs.getDueCropYear(),
        dueDatePeriod = FF.Region.get("inputs.account.dueDatePeriod", 10),
        pastDueRate = FF.Inputs.getPastDueRate(),
        earlyPayDiscount = FF.Inputs.getEarlyPayDiscount()
    }
end

-- Charge an input sale your mod makes to a farm (seed at your co-op, a
-- liquid fertilizer fill station, chemicals from your silo yard...).
-- Do NOT take the money yourself: Farm Finance books the expense and
-- decides how it is paid.
--   amount : total price (game money)
--   info (optional table):
--     fillType       : fill type name or index (for the expense category)
--     liters         : quantity, for the record
--     description    : text shown on the account, e.g. "Seed - Miller Co-op"
--     moneyType      : a MoneyType to book the expense under
--                      (default PURCHASE_SEEDS for SEEDS, else PURCHASE_FERTILIZER)
--     allowAccount   : false = never put it on the account (default true)
--     applyDiscount  : false = no early-pay discount when paid cash (default true)
-- Returns ok, method ("account" | "cash"), value (amount booked on the
-- account, or the discount refunded for cash), reason (when not ok).
-- When Farm Finance's bank is off, the farm is simply charged cash.
function API.payForInputs(farmId, amount, info)
    if not isReady() then
        return false, nil, 0, "notReady"
    end
    if not FF.isServer() then
        return false, nil, 0, "notServer"
    end
    amount = tonumber(amount) or 0
    if amount <= 0 or farmId == nil or farmId <= 0 then
        return false, nil, 0, "invalid"
    end
    info = info or {}
    local fillTypeName = toFillTypeName(info.fillType)
    local moneyType = info.moneyType
    if moneyType == nil and FF.env ~= nil and FF.env.inputMoneyType ~= nil then
        moneyType = FF.env.inputMoneyType(fillTypeName)
    end

    -- Book the expense (this is the purchase itself).
    FF.Inputs.suppressPurchaseHook = true
    local ok, err = pcall(function()
        if FF.env ~= nil and FF.env.addMoneyType ~= nil then
            FF.env.addMoneyType(-amount, farmId, moneyType)
        end
    end)
    FF.Inputs.suppressPurchaseHook = false
    if not ok then
        return false, nil, 0, tostring(err)
    end

    if not API.isBankActive() then
        return true, "cash", 0
    end
    local method, value = FF.Inputs.onInputPurchase(farmId, amount, {
        description = info.description,
        allowAccount = info.allowAccount,
        applyDiscount = info.applyDiscount
    })
    API.fire("inputPurchased", farmId, amount, method, value, fillTypeName, info.liters)
    return true, method or "cash", value or 0
end

-- Crop share ---------------------------------------------------------------------------

-- Is this field on a crop-share lease for this farm? Returns bool and the
-- landowner's share (0..1).
function API.isCropShareField(farmId, farmlandId)
    if not isReady() then
        return false, 0
    end
    local contract = FF.CropShare.getShareContract(farmId, farmlandId)
    if contract == nil then
        return false, 0
    end
    return true, contract.landownerShare or 0
end

-- Report a harvest that didn't go through a combine (custom harvesters,
-- yield mods). Returns the landowner's liters.
function API.reportHarvest(farmId, farmlandId, fillType, liters)
    if not isReady() or not FF.isServer() then
        return 0
    end
    return FF.CropShare.onHarvest(farmId, farmlandId, toFillTypeName(fillType), tonumber(liters) or 0)
end

-- Report a grain sale that didn't go through a SellingStation (virtual
-- hauls, contracts, your own sell point). Farm Finance pays the landowner
-- their share of it. Returns landowner liters and value.
function API.reportGrainSale(farmId, fillType, liters, pricePerLiter)
    if not isReady() or not FF.isServer() then
        return 0, 0
    end
    local name = toFillTypeName(fillType)
    local taken, value = FF.CropShare.onSale(farmId, name, tonumber(liters) or 0, tonumber(pricePerLiter))
    if value > 0 and FF.env ~= nil and FF.env.addMoney ~= nil then
        FF.env.addMoney(-value, farmId, "cropShareLandowner")
        API.fire("landownerPaid", farmId, name, taken, value)
    end
    return taken, value
end

-- Report seed, fertilizer or spray used on a field (when your machine
-- doesn't use the base-game seeder or sprayer). Returns the landowner's
-- credit to the farm.
function API.reportInputUse(farmId, farmlandId, cost)
    if not isReady() or not FF.isServer() then
        return 0
    end
    return FF.CropShare.onInputUse(farmId, farmlandId, tonumber(cost) or 0)
end

-- {FILLTYPENAME = {liters, value, oldestCropYear}} of grain the farm holds
-- for landowners.
function API.getLandownerGrain(farmId)
    if not isReady() then
        return {}
    end
    return copy(FF.CropShare.getHeld(farmId))
end

-- Land ----------------------------------------------------------------------------------

-- The Farm Finance lease on a farmland, or nil:
-- {kind = "in"|"out", leaseType = "cash"|"share", farmId, annualRent,
--  landownerShare, inputShare, endCropYear}
function API.getLandContract(farmlandId)
    if not isReady() then
        return nil
    end
    local contract = FF.Land.getContractByFarmland(farmlandId)
    if contract == nil then
        return nil
    end
    return {
        kind = contract.kind,
        leaseType = contract.leaseType or "cash",
        farmId = contract.farmId,
        annualRent = contract.annualRent,
        landownerShare = contract.landownerShare,
        inputShare = contract.inputShare,
        endCropYear = contract.endCropYear
    }
end

-- Region ----------------------------------------------------------------------------------

function API.getRegionId()
    return FF.Region.getActiveId()
end

-- Any region value by key, e.g. "land.rentToValue" (see regions/_base.xml).
function API.getRegionValue(key, default)
    return copy(FF.Region.get(key, default))
end

-- Full read access ----------------------------------------------------------------------------
-- Every call returns copies: changing them changes nothing in Farm Finance.

-- Farm ids that have Farm Finance records.
function API.getFarmIds()
    local ids = {}
    if not isReady() then
        return ids
    end
    for _, farm in pairs(FF.state.farms) do
        ids[#ids + 1] = farm.farmId
    end
    table.sort(ids)
    return ids
end

-- Market: {baseRate, trend (-1|0|1), trendMonthsLeft, history = {{month, rate}},
--  promos = {BRAND = {months, rebate, startMonth, endMonth}}, monthIndex, cropYear, period}
function API.getMarket()
    if not isReady() then
        return nil
    end
    local s = FF.state
    return {
        baseRate = s.baseRate,
        trend = s.rateTrend,
        trendMonthsLeft = s.rateTrendMonths,
        history = copy(s.rateHistory or {}),
        promos = copy(s.promos or {}),
        monthIndex = s.monthIndex,
        cropYear = s.cropYear,
        period = s.period
    }
end

-- Credit in full: {score, grade, parts = {payment, solvency, liquidity,
--  repayment, length} (0..1), ratios = {debtToAsset, currentRatio,
--  termDebtCoverage, workingCapital, netWorth, totalAssets, totalDebt, ...},
--  snapshot = {cash, landValue, machineryValue, buildingValue, inventoryValue,
--  debts, income12, opex12, debtService12, ...}, history = {onTime, late,
--  missed, streak, defaults, monthsOnRecord}, review, limits = {product = {limit, rate}}}
function API.getCreditReport(farmId)
    if not isReady() then
        return nil
    end
    local evaluation = FF.Bank.evaluate(farmId)
    local farm = FF.Bank.getFarm(farmId)
    local limits = {}
    for _, productId in ipairs({"realEstate", "equipment", "operating"}) do
        local term = FF.Region.get("loans.product." .. productId .. ".defaultTermYears", 1)
        local quote = FF.Bank.quote(farmId, productId, term, nil)
        limits[productId] = {limit = quote.limit, rate = quote.rate, termYears = term}
    end
    return {
        score = evaluation.score,
        grade = evaluation.grade,
        parts = copy(evaluation.parts),
        ratios = copy(evaluation.ratios),
        snapshot = copy(evaluation.snapshot),
        history = copy(farm.history),
        review = copy(farm.review),
        limits = limits
    }
end

-- Loans: list of {id, productId, label, source, principal, balance, rate,
--  payment, monthsTotal, monthsLeft, status, lateMonths, collateralUid}.
-- includeClosed = true adds paid-off loans (status "paid").
function API.getLoans(farmId, includeClosed)
    local list = {}
    if not isReady() then
        return list
    end
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return list
    end
    for _, id in ipairs(U.sortedKeys(farm.loans)) do
        list[#list + 1] = copy(farm.loans[id])
    end
    if includeClosed then
        for _, loan in ipairs(farm.closed or {}) do
            list[#list + 1] = copy(loan)
        end
    end
    return list
end

-- Machine leases: list of {id, name, storeXml, price, payment, residual,
--  deposit, rate, months, monthsLeft, hoursPerYear, status, vehicleUid}.
function API.getLeases(farmId)
    local list = {}
    if not isReady() then
        return list
    end
    local farm = FF.Bank.getFarm(farmId, false)
    for _, id in ipairs(U.sortedKeys(farm ~= nil and farm.leases or {})) do
        list[#list + 1] = copy(farm.leases[id])
    end
    return list
end

-- Is this machine (by uniqueId) leased or loan collateral?
-- Returns {leased = bool, leaseId, collateralForLoanId}.
function API.getVehicleFinance(vehicleUid)
    if not isReady() or vehicleUid == nil then
        return nil
    end
    local result = {leased = false}
    local lease = FF.Equipment.getLeaseByUid(tostring(vehicleUid))
    if lease ~= nil then
        result.leased = true
        result.leaseId = lease.id
    end
    for _, farm in pairs(FF.state.farms) do
        for _, loan in pairs(farm.loans or {}) do
            if loan.collateralUid == tostring(vehicleUid) then
                result.collateralForLoanId = loan.id
            end
        end
    end
    return result
end

-- Land contracts of a farm (both directions): list of the full contract
-- records ({id, kind, leaseType, farmlandId, name, annualRent, landownerShare,
--  inputShare, endCropYear, noticeBy, ...}).
function API.getLandContracts(farmId)
    local list = {}
    if not isReady() then
        return list
    end
    local farm = FF.Bank.getFarm(farmId, false)
    for _, id in ipairs(U.sortedKeys(farm ~= nil and farm.land or {})) do
        list[#list + 1] = copy(farm.land[id])
    end
    return list
end

-- Crop-share field reports: {stats = {{contractId, name, cropYear, fillType,
--  harvested, landowner, delivered, deliveredValue, settled, settledValue}},
--  inputs = {{contractId, cropYear, cost, credit}}, held, lastPrice}
function API.getCropShareReport(farmId)
    if not isReady() then
        return nil
    end
    local farm = FF.Bank.getFarm(farmId, false)
    local share = farm ~= nil and farm.cropShare or {}
    return {
        stats = copy(share.stats or {}),
        inputs = copy(share.inputs or {}),
        held = copy(FF.CropShare.getHeld(farmId)),
        lastPrice = copy(share.lastPrice or {})
    }
end

-- Operating line: {open, limit, balance, rate, cleanedThisYear} or nil.
function API.getOperatingLine(farmId)
    if not isReady() then
        return nil
    end
    local farm = FF.Bank.getFarm(farmId, false)
    local line = FF.Line.get(farm)
    if line == nil then
        return nil
    end
    local result = copy(line)
    result.rate = FF.Line.getRate(farm)
    return result
end

-- Input account charges: list of {id, amount, remaining, dueCropYear, month,
--  description, missedDue}. (Totals: getInputAccount.)
function API.getInputCharges(farmId)
    if not isReady() then
        return {}
    end
    local farm = FF.Bank.getFarm(farmId, false)
    return copy(farm ~= nil and farm.inputs ~= nil and farm.inputs.charges or {})
end

-- Totals paid and received: {interestPaid, principalPaid, rentPaid, rentIncome}
-- plus 12-month operating income and costs {income12, opex12, months}.
function API.getLedger(farmId)
    if not isReady() then
        return nil
    end
    local farm = FF.Bank.getFarm(farmId)
    local result = copy(farm.ledger)
    result.income12, result.opex12, result.months = FF.FarmData.getTrailing(farm)
    return result
end

-- Everything for one farm in one table.
function API.getFarmSummary(farmId)
    if not isReady() then
        return nil
    end
    return {
        farmId = farmId,
        credit = API.getCreditReport(farmId),
        loans = API.getLoans(farmId),
        leases = API.getLeases(farmId),
        land = API.getLandContracts(farmId),
        cropShare = API.getCropShareReport(farmId),
        operatingLine = API.getOperatingLine(farmId),
        inputAccount = API.getInputAccount(farmId),
        inputCharges = API.getInputCharges(farmId),
        ledger = API.getLedger(farmId),
        debt = copy(FF.Bank.getDebtSummary(farmId))
    }
end

-- The whole region in effect: {id, name, values = {key = value, ...}}.
function API.getRegion()
    return {
        id = FF.Region.getActiveId(),
        name = FF.Region.getName(FF.Region.getActiveId()),
        values = copy(FF.Region.active ~= nil and FF.Region.active.values or {})
    }
end

-- Installed regions: list of {id, name, parent, abstract, source}.
function API.listRegions()
    local list = {}
    for _, id in ipairs(FF.Region.order or {}) do
        local region = FF.Region.regions[id]
        if region ~= nil then
            list[#list + 1] = {id = id, name = region.values.name, parent = region.parent, abstract = region.abstract, source = region.source}
        end
    end
    return list
end

-- Mods that switched Farm Finance features off: {bank = {...}, rentIn = {...}, rentOut = {...}}
function API.getConflicts()
    return copy(FF.conflicts or {})
end

-- What the one-time importer brought over from older mods (text lines).
function API.getImportReport()
    if not isReady() then
        return {}
    end
    return copy(FF.state.importReport or {})
end

-- Events ------------------------------------------------------------------------------------
-- "inputPurchased"  (farmId, amount, method, value, fillTypeName, liters)
-- "landownerPaid"   (farmId, fillTypeName, liters, value)
-- "monthProcessed"  (period)

function API.subscribe(eventName, callback, target)
    if type(callback) ~= "function" then
        return false
    end
    API.listeners[eventName] = API.listeners[eventName] or {}
    table.insert(API.listeners[eventName], {callback = callback, target = target})
    return true
end

function API.unsubscribe(eventName, target)
    local list = API.listeners[eventName]
    if list == nil then
        return
    end
    for index = #list, 1, -1 do
        if list[index].target == target then
            table.remove(list, index)
        end
    end
end

function API.fire(eventName, ...)
    for _, listener in ipairs(API.listeners[eventName] or {}) do
        local ok, err
        if listener.target ~= nil then
            ok, err = pcall(listener.callback, listener.target, ...)
        else
            ok, err = pcall(listener.callback, ...)
        end
        if not ok then
            U.warn("API listener for %s failed: %s", tostring(eventName), tostring(err))
        end
    end
end

return API
