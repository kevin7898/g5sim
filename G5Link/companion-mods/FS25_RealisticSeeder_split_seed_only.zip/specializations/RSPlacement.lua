-- Mechanical placement specialization. Native ground/calendar/seed ownership
-- checks remain in the original sowing function; only its density call is split.
RSPlacement = {nextId=0,context=nil}
local P=RSPlacement
local M=RSPlacementModel
local A=RSPlacementAPI
P.keys={"depthMm","ratePercent","pressurePercent","closingPercent","meterPercent","ratePerAcre","seedsPerPound"}
for _,key in ipairs(RSControlModel.keys) do P.keys[#P.keys+1]=key end
P.recordLimit=128
-- Explicit starting calibrations, not seed-tag measurements or prescriptions.
P.seedCalibrations={WHEAT={120,1500000,12500},WV_WINTERWHEAT={120,1500000,12500},WV_SPRINGWHEAT={120,1500000,12500},
    SOYBEAN={50,140000,3000},MAIZE={20,34000,1800},BARLEY={100,1400000,14000},OAT={90,1200000,14000},
    CANOLA={5,450000,90000},SORGHUM={8,100000,15000},SUNFLOWER={5,25000,5000},SUGARBEET={5,45000,10000}}
function P.getCalibration(vehicle)
    local s=vehicle.spec_rsPlacement;local sow=vehicle.spec_sowingMachine
    local fruit=g_fruitTypeManager:getFruitTypeByIndex(sow.seeds[sow.currentSeed])
    local preset=P.seedCalibrations[fruit and fruit.name] or {30,150000,5000}
    local unit=s.profile.kind=="planter" and "seedsPerAcre" or "poundsPerAcre"
    local reference=unit=="seedsPerAcre" and preset[2] or preset[1]
    local selected=s.settings.ratePerAcre or 0
    local size=s.settings.seedsPerPound or 0
    local source,index=RealisticSeederUtil.getSeedSource(vehicle)
    local fill=source and index and g_fillTypeManager:getFillTypeByIndex(source:getFillUnitFillType(index))
    if not fill and g_fillTypeManager.getFillTypeByName then fill=g_fillTypeManager:getFillTypeByName("SEED_"..(fruit and fruit.name or "")) end
    if not fill and g_fillTypeManager.getFillTypeByName then fill=g_fillTypeManager:getFillTypeByName("SEEDS") end
    return {unit=unit,ratePerAcre=(selected>0 and selected or reference)*s.settings.ratePercent/100,
        baseRatePerAcre=selected>0 and selected or reference,referenceRatePerAcre=reference,
        seedsPerPound=size>0 and size or preset[3],seedSizeSource=size>0 and "operatorEntered" or "nominalDefault",
        rateSource=selected>0 and "operatorEntered" or "nominalDefault",
        kgPerLiter=fill and fill.massPerLiter and fill.massPerLiter*1000 or nil}
end

function P.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(SowingMachine,specializations)
end
function P.initSpecialization()
    if RSTechnology then RSTechnology.register(g_vehicleConfigurationManager) end
    local schema=Vehicle.xmlSchemaSavegame
    for _,key in ipairs(P.keys) do schema:register(XMLValueType.FLOAT,"vehicles.vehicle(?).rsPlacement#"..key,"Manual placement setting") end
    for _,key in ipairs({"id","lastInspection"}) do schema:register(XMLValueType.STRING,"vehicles.vehicle(?).rsPlacement#"..key,"Placement state") end
    for _,key in ipairs({"revision","sequence"}) do schema:register(XMLValueType.INT,"vehicles.vehicle(?).rsPlacement#"..key,"Placement revision") end
    for _,key in ipairs({"plantedSqm","skippedSqm","meteredSqm","seedLiters"}) do schema:register(XMLValueType.FLOAT,"vehicles.vehicle(?).rsPlacement#"..key,"Lifetime placement counter") end
    schema:register(XMLValueType.STRING,"vehicles.vehicle(?).rsPlacement.record(?)#data","Version 1 settings record")
    local xml=Vehicle.xmlSchema
    xml:register(XMLValueType.STRING,"vehicle.rsPlacement#kind","drill or planter")
    xml:register(XMLValueType.FLOAT,"vehicle.rsPlacement#workingSpeedKmh","Profile working speed",12)
    xml:register(XMLValueType.INT,"vehicle.rsPlacement#rowCount","Supported single-work-area row layout (1-24)",0)
    for key in pairs(RSTechnology.capabilities) do
        xml:register(XMLValueType.BOOL,"vehicle.rsPlacement#"..key,"Explicitly fitted capability",false)
    end
end
function P.registerEventListeners(vehicleType)
    for _,name in ipairs({"onLoad","onPostLoad","onDelete","onReadStream","onWriteStream","onRegisterActionEvents","onUpdateTick"}) do
        SpecializationUtil.registerEventListener(vehicleType,name,P)
    end
end
function P.registerOverwrittenFunctions(vehicleType)
    SpecializationUtil.registerOverwrittenFunction(vehicleType,"processSowingMachineArea",P.processSowingMachineArea)
end
function P.registerFunctions(vehicleType)
    SpecializationUtil.registerFunction(vehicleType,"rsSetPlacementSetting",P.setSetting)
end

function P:onLoad(savegame)
    local xml=self.xmlFile
    -- storeData.category is schema-converted to a StoreCategory object in FS25.
    local category=tostring(getXMLString(xml.handle,"vehicle.storeData.category") or ""):lower()
    local kind=xml:getValue("vehicle.rsPlacement#kind",category=="planters" and "planter" or "drill")
    if kind~="planter" then kind="drill" end
    local filename=(self.configFileName or ""):lower():gsub("\\","/")
    -- Base-game 4905 Blue Drive uses the legacy planter4900 asset path.
    -- Its seed-monitor profile does not imply a fitted depth sensor.
    local kinze=filename:match("/kinze/planter4900/planter4900.xml$")~=nil
    local ratedSpeed=getXMLFloat(xml.handle,"vehicle.base.speedLimit#value") or (kind=="planter" and 8 or 12)
    local profile={kind=kind,profileId=kinze and "kinze4905BlueDrive" or "genericManual",
        workingSpeedKmh=xml:getValue("vehicle.rsPlacement#workingSpeedKmh",ratedSpeed),
        settingsLogging=xml:getValue("vehicle.rsPlacement#settingsLogging",kinze),
        seedMonitor=xml:getValue("vehicle.rsPlacement#seedMonitor",kinze),
        depthSensor=xml:getValue("vehicle.rsPlacement#depthSensor",false),
        cabRateControl=xml:getValue("vehicle.rsPlacement#cabRateControl",kinze),automaticDepth=false,automaticDownforce=false}
    if RSTechnology then RSTechnology.apply(profile,self.configurations,self.configFileName,xml) end
    profile.workingSpeedKmh=M.clamp(profile.workingSpeedKmh,3,25)
    P.nextId=P.nextId+1
    self.spec_rsPlacement={enabled=not self.spec_sowingMachine.waterSeeding,profile=profile,
        settings=M.settings(),revision=0,sequence=0,records={},actionEvents={},
        id=string.format("rs-%s-%d",tostring(g_time or 0),P.nextId),
        counters={plantedSqm=0,skippedSqm=0,meteredSqm=0,seedLiters=0},lastRecordMs=-10000,meterFootprints={}}
    g_currentMission.realisticSeederAPI=A
end
function P:onPostLoad(savegame)
    local s=self.spec_rsPlacement
    if s.profile.rowDrive and self.spec_workArea then
        local count=0
        for _,area in ipairs(self.spec_workArea.workAreas or {}) do
            if area.functionName=='processSowingMachineArea' then count=count+1 end
        end
        if count~=1 then
            s.profile.rowDrive=false
            s.profile.technologyWarnings=s.profile.technologyWarnings or {}
            table.insert(s.profile.technologyWarnings,'Individual row drive disabled: this implement needs a single sowing work area.')
        end
    end
    if savegame and not savegame.resetVehicles then
        local xml,key=savegame.xmlFile,savegame.key..".rsPlacement"
        s.id=xml:getValue(key.."#id",s.id)
        local input={};for _,name in ipairs(P.keys) do input[name]=xml:getValue(key.."#"..name,s.settings[name]) end
        s.settings=M.settings(input)
        s.revision=xml:getValue(key.."#revision",0);s.sequence=xml:getValue(key.."#sequence",0)
        s.inspection=xml:getValue(key.."#lastInspection")
        for name in pairs(s.counters) do s.counters[name]=xml:getValue(key.."#"..name,0) end
        for i=0,P.recordLimit-1 do
            local text=xml:getValue(key..string.format(".record(%d)#data",i))
            if not text then break end
            local row=P.decodeRecord(text)
            if row then
                row.schemaVersion=1;row.vehicleId=s.id;row.settingsSource="operatorEntered"
                s.records[#s.records+1]=row
            end
        end
    end
    if self.uniqueId then
        s.id=self.uniqueId
        for _,row in ipairs(s.records) do row.vehicleId=s.id end
    end
end
function P:saveToXMLFile(xml,key)
    local s=self.spec_rsPlacement
    A.ensureIdentity(self)
    for _,name in ipairs(P.keys) do xml:setValue(key.."#"..name,s.settings[name]) end
    for _,name in ipairs({"id","revision","sequence"}) do xml:setValue(key.."#"..name,s[name]) end
    for name,value in pairs(s.counters) do xml:setValue(key.."#"..name,value) end
    if s.inspection then xml:setValue(key.."#lastInspection",s.inspection) end
    for i,row in ipairs(s.records) do xml:setValue(key..string.format(".record(%d)#data",i-1),P.encodeRecord(row)) end
end
function P:onDelete()
    if P.context and P.context.vehicle==self then P.context=nil end
end
function P:onUpdateTick(dt)
    local s=self.spec_rsPlacement
    if not s or not s.enabled then return end
    if s.profile.rowCleanerCabAdjustment and self.getAnimationTime then
        local tool=RSControlModel.cleanerTool(self)
        if tool then s.settings.rowCleanerPosition=self:getAnimationTime(tool.animName)*100 end
    end
    local active=(not self.spec_sowingMachine.needsActivation or self:getIsTurnedOn())
        and (not self.getIsLowered or self:getIsLowered())
    if not active then s.meterFootprints={} end
end

function P.writeSettings(vehicle,streamId)
    local s=vehicle.spec_rsPlacement
    streamWriteString(streamId,s.id);streamWriteInt32(streamId,s.revision)
    for _,name in ipairs(P.keys) do streamWriteFloat32(streamId,s.settings[name]) end
end
function P.readSettings(vehicle,streamId)
    local s=vehicle.spec_rsPlacement
    s.id=streamReadString(streamId);s.revision=streamReadInt32(streamId)
    local values={};for _,name in ipairs(P.keys) do values[name]=streamReadFloat32(streamId) end
    s.settings=M.settings(values)
end
function P:onWriteStream(streamId,connection) P.writeSettings(self,streamId) end
function P:onReadStream(streamId,connection) P.readSettings(self,streamId) end

function P:setSetting(name,value,noEventSend)
    local s=self.spec_rsPlacement
    if not s or not s.enabled or not M.limits[name] or not M.finite(value) then return false,"Invalid setting" end
    if value<M.limits[name][1] or value>M.limits[name][2] then return false,"Setting outside allowed range" end
    if name=="ratePerAcre" and s.profile.kind=="drill" and value>1000 then return false,"Drill rate must be at most 1000 lb/acre" end
    local allowed,why=RSControlModel.allowed(s.profile,name,value)
    if not allowed then return false,why end
    if not RSControlModel.cabAllowed(s.profile,name) then
        if self:getLastSpeed()>0.5 or self:getIsTurnedOn() then return false,"Stop and switch off before adjusting this setting" end
    end
    if not self.isServer and not noEventSend then
        g_client:getServerConnection():sendEvent(RSPlacementSettingEvent.new(self,name,value))
        return true,"Requested"
    end
    if s.settings[name]==value and (name~="ratePerAcre" or s.settings.ratePercent==100) then return true end
    if name=='rowCleanerPosition' then
        local ok,reason=RSControlModel.applyCleaner(self,value)
        if not ok then return false,reason end
    end
    s.settings[name]=value
    if name=="ratePerAcre" then s.settings.ratePercent=100 end
    s.revision=s.revision+1
    if self.isServer then
        P.record(self,"seed.settings")
        if not noEventSend and g_server then g_server:broadcastEvent(RSPlacementSettingEvent.new(self,name,value),nil,nil,self) end
    end
    return true
end

P.recordKeys={"sequence","event","revision","timeMs","day","period","crop","depthMm","ratePercent","pressurePercent","closingPercent","meterPercent","x","z","plantedSqm","skippedSqm","skipsPercent","doublesPercent","distributionCvPercent","x0","z0","x1","z1","x2","z2","ratePerAcre","seedsPerPound","rateUnit","meteredSqm","seedLiters","seedSizeSource","rateSource","kgPerLiter"}
P.legacyRecordKeyCount=#P.recordKeys
for _,name in ipairs({"soilMoisture","soilCompaction","soilMoistureSource","soilCompactionSource","pressureTargetPercent","closingTargetPercent","sidewallRiskPercent","establishedSeedsPerAcre","populationYieldPercent","yieldPotentialPercent","yieldMethod"}) do
    P.recordKeys[#P.recordKeys+1]=name
end
P.soilRecordKeyCount=#P.recordKeys
for _,name in ipairs(RSControlModel.keys) do P.recordKeys[#P.recordKeys+1]=name end
for _,name in ipairs({'appliedDepthMm','appliedPressurePercent','appliedClosingPercent'}) do P.recordKeys[#P.recordKeys+1]=name end
P.recordStrings={event=true,crop=true,rateUnit=true,seedSizeSource=true,rateSource=true,soilMoistureSource=true,soilCompactionSource=true,yieldMethod=true}
function P.encodeRecord(row)
    local out={};for _,name in ipairs(P.recordKeys) do out[#out+1]=tostring(row[name] or ""):gsub("[|\r\n]","") end
    return table.concat(out,"|")
end
function P.decodeRecord(text)
    local out={};local i=1
    for value in (text.."|"):gmatch("(.-)|") do
        local name=P.recordKeys[i];if not name then return nil end
        out[name]=P.recordStrings[name] and value~="" and value or tonumber(value);i=i+1
    end
    return (i==#P.recordKeys+1 or i==P.soilRecordKeyCount+1 or i==P.legacyRecordKeyCount+1) and out.sequence and out or nil
end
function P.record(vehicle,event)
    local s=vehicle.spec_rsPlacement
    if not s.profile.settingsLogging or not vehicle.isServer then return end
    s.sequence=s.sequence+1
    local snap=A.getSnapshot(vehicle)
    local x,_,z=getWorldTranslation(vehicle.rootNode)
    local env=g_currentMission.environment
    local row={schemaVersion=1,vehicleId=s.id,sequence=s.sequence,event=event,revision=s.revision,
        timeMs=g_time or 0,day=env.currentMonotonicDay or env.currentDay,period=env.currentPeriod,
        crop=snap.crop,x=x,z=z,plantedSqm=s.counters.plantedSqm,skippedSqm=s.counters.skippedSqm,
        settingsSource="operatorEntered"}
    for _,name in ipairs(P.keys) do row[name]=s.settings[name] end
    row.ratePerAcre=snap.application.ratePerAcre;row.seedsPerPound=snap.application.seedsPerPound;row.rateUnit=snap.application.unit
    row.seedSizeSource=snap.application.seedSizeSource;row.rateSource=snap.application.rateSource;row.kgPerLiter=snap.application.kgPerLiter
    row.meteredSqm=s.counters.meteredSqm;row.seedLiters=s.counters.seedLiters
    if event=="seed.placement" and s.lastWorkArea then
        for name,value in pairs(s.lastWorkArea) do row[name]=value end
    end
    if event=="seed.placement" then
        for _,name in ipairs({"skipsPercent","doublesPercent","distributionCvPercent"}) do row[name]=snap.measurements[name] end
        local sample=s.lastSample
        if sample and sample.population then
            if sample.controls then
                row.appliedDepthMm=sample.controls.applied.depthMm;row.appliedPressurePercent=sample.controls.applied.pressurePercent;row.appliedClosingPercent=sample.controls.applied.closingPercent
            end
            local soil=sample.soil
            row.soilMoisture=soil.moisture;row.soilCompaction=soil.compaction
            row.soilMoistureSource=soil.moistureSource;row.soilCompactionSource=soil.compactionSource
            row.pressureTargetPercent=soil.pressureTarget;row.closingTargetPercent=soil.closingTarget
            row.sidewallRiskPercent=sample.sidewallRiskPercent
            for _,name in ipairs({"establishedSeedsPerAcre","populationYieldPercent","yieldPotentialPercent","yieldMethod"}) do row[name]=sample.population[name] end
        end
    end
    s.records[#s.records+1]=row
    if #s.records>P.recordLimit then table.remove(s.records,1) end
    A.publish(vehicle,event,row)
end

function P:processSowingMachineArea(superFunc,workArea,dt)
    local s=self.spec_rsPlacement
    if not s or not s.enabled then return superFunc(self,workArea,dt) end
    local sow=self.spec_sowingMachine
    local fruit=g_fruitTypeManager:getFruitTypeByIndex(sow.workAreaParameters.seedsFruitType)
    if not fruit then return superFunc(self,workArea,dt) end
    local x1,_,z1=getWorldTranslation(workArea.width or self.rootNode)
    local x2,_,z2=getWorldTranslation(workArea.height or self.rootNode)
    local soil=RSSoilConditions and RSSoilConditions.sample((x1+x2)/2,(z1+z2)/2) or nil
    local sample=M.evaluate(s.profile,s.settings,fruit.name,self:getLastSpeed(),self:getVehicleDamage(),soil)
    local calibration=P.getCalibration(self)
    local densityRate=calibration.ratePerAcre/calibration.referenceRatePerAcre
    local preset=P.seedCalibrations[fruit.name]
    local reference=preset and preset[2] or calibration.referenceRatePerAcre*(calibration.unit=="poundsPerAcre" and calibration.seedsPerPound or 1)
    sample.population=M.populationResponse(fruit.name,calibration,reference,sample)
    local previous=P.context
    local rowX,_,rowZ=getWorldTranslation(workArea.start)
    local context={vehicle=self,sample=sample,salt=fruit.index*1009,attemptedSqm=0,skippedSqm=0,densityRate=densityRate,calibration=calibration,reference=reference,crop=fruit.name,
        rowLayout={sx=rowX,sz=rowZ,wx=x1,wz=z1}}
    P.context=context
    local ok,changed,total=pcall(superFunc,self,workArea,dt)
    P.context=previous
    if not ok then error(changed) end
    s.acceptedRows=context.acceptedRows;s.acceptedWorkArea=workArea;s.acceptedTimeMs=g_time or 0
    if context.attemptedSqm>0 then
        sample.timeMs=g_time or 0;sample.settingsRevision=s.revision;s.lastSample=sample
        local x0,_,z0=getWorldTranslation(workArea.start)
        local x1,_,z1=getWorldTranslation(workArea.width)
        local x2,_,z2=getWorldTranslation(workArea.height)
        s.lastWorkArea={x0=x0,z0=z0,x1=x1,z1=z1,x2=x2,z2=z2}
        local quad=RSSeedRate.quad(x0,z0,x1,z1,x2,z2)
        s.meterFootprints=s.meterFootprints or {}
        local metered=RSSeedRate.sweptArea(s.meterFootprints[workArea],quad,dt,sample.speedKmh)
        s.meterFootprints[workArea]=quad
        local liters=RSSeedRate.litersForArea(metered,calibration.ratePerAcre,calibration.unit,calibration.seedsPerPound,calibration.kgPerLiter)
        if liters and self.isServer then
            -- Meter faults affect delivery; depth/closure/emergence NEVER refund seed.
            liters=liters*sample.deliveryScale*(context.rowRateFactor or 1)
            s.pendingLiters=(s.pendingLiters or 0)+liters
            s.pendingMeteredSqm=(s.pendingMeteredSqm or 0)+metered*(context.activeRowFraction or 1)
        end
        local sqm=(changed or 0)*g_currentMission:getFruitPixelsToSqm()
        if self.isServer then s.counters.plantedSqm=s.counters.plantedSqm+sqm end
        -- Legacy counter name: yield-equivalent masked area, before native eligibility.
        if self.isServer then s.counters.skippedSqm=s.counters.skippedSqm+context.skippedSqm end
        s.inspection=string.format("Last pass sample (simulated): depth %.0f mm (+/- %.0f), seed contact %.0f%%, %s %.1f%%. Target rate %.0f %s. Placement risk %.1f%%.",
            sample.actualDepthMm,sample.depthSpreadMm,sample.contactPercent,
            s.profile.kind=="planter" and "meter skips" or "delivery misses",sample.skipsPercent,
            calibration.ratePerAcre,calibration.unit=="seedsPerAcre" and "seeds/acre" or "lb/acre",sample.placementLossPercent)
        local soil=sample.soil
        local moisture=soil.moisture and string.format("%.0f%% (%s)",soil.moisture*100,soil.moistureSource) or "unavailable - neutral assumption"
        local compaction=soil.compaction and string.format("%.0f%% (%s)",soil.compaction*100,soil.compactionSource) or "unavailable - neutral assumption"
        s.inspection=s.inspection..string.format("\n\nSeedbed moisture: %s. Compaction: %s.\nModeled control targets: opener %.0f%% / closing %.0f%%. Sidewall risk %.1f%%.\nEstimated established population: %.0f plants/acre. Placement/population yield potential: %.1f%%.\nYield is represented by native crop coverage, not individual plants. Other crop, soil and weather effects still apply. This is a model estimate, not a sensor reading or guaranteed harvest.",
            moisture,compaction,soil.pressureTarget,soil.closingTarget,sample.sidewallRiskPercent,
            sample.population.establishedSeedsPerAcre,sample.population.yieldPotentialPercent)
        if sample.geometryFallback then s.inspection=s.inspection.."\nUnsupported work-area geometry: native coverage fallback used; modeled yield mask was not applied to every primitive." end
        if sample.controls then
            local a=sample.controls.applied;local modes=sample.controls.modes
            s.inspection=s.inspection..string.format('\n\nApplied controls: depth %.1f mm (%s), opener %.0f%% (%s), closing %.0f%% (%s). Soil-adaptive depth uses modeled seedbed moisture, not a measured vertical soil profile.',a.depthMm,modes.depth,a.pressurePercent,modes.downforce,a.closingPercent,modes.closing)
        end
        if metered>0 then s.pendingRecord=true end
    elseif s.meterFootprints then
        s.meterFootprints[workArea]=nil
    end
    return changed,total
end

-- Native seed usage uses this temporary scale only during its end-of-pass hook.
function P.endProcessing(vehicle,original,...)
    local s=vehicle.spec_rsPlacement;local sow=vehicle.spec_sowingMachine
    if not s or not s.enabled then return original(vehicle,...) end
    local scale=sow.seedUsageScale
    local oldChanged=sow.workAreaParameters.lastChangedArea
    local fruit=g_fruitTypeManager:getFruitTypeByIndex(sow.workAreaParameters.seedsFruitType)
    local metered=s.pendingMeteredSqm or 0
    local source,index=RealisticSeederUtil.getSeedSource(vehicle)
    local before=source and index and source:getFillUnitFillLevel(index)
    if vehicle.isServer and s.pendingLiters~=nil and fruit and fruit.seedUsagePerSqm>0 then
        -- Preserve native inventory, AI purchase and farm accounting paths. Only
        -- substitute the meter's physical quantity; foliage/statistics stay native.
        sow.workAreaParameters.lastChangedArea=metered/g_currentMission:getFruitPixelsToSqm()
        local damageFactor=1+vehicle:getVehicleDamage()*(SowingMachine.DAMAGED_USAGE_INCREASE or 0)
        sow.seedUsageScale=metered>0 and s.pendingLiters/(metered*fruit.seedUsagePerSqm*damageFactor) or 0
    end
    local ok,a,b=pcall(original,vehicle,...)
    sow.seedUsageScale=scale;sow.workAreaParameters.lastChangedArea=oldChanged
    if ok and vehicle.isServer and s.pendingLiters~=nil then
        s.counters.meteredSqm=(s.counters.meteredSqm or 0)+metered
        local used=s.pendingLiters
        local helperBuys=vehicle.getIsAIActive and vehicle:getIsAIActive() and g_currentMission.missionInfo.helperBuySeeds
        if before and not helperBuys then used=math.max(0,before-source:getFillUnitFillLevel(index)) end
        s.counters.seedLiters=(s.counters.seedLiters or 0)+used
    end
    s.pendingLiters=nil;s.pendingMeteredSqm=nil
    if not ok then error(a) end
    if s.pendingRecord and (g_time or 0)-s.lastRecordMs>=1000 then s.lastRecordMs=g_time or 0;P.record(vehicle,"seed.placement") end
    s.pendingRecord=nil
    return a,b
end

function P.densityPrimitive(original,fruit,sx,sz,wx,wz,hx,hz,ground,ridge,angle,growth,...)
    local c=P.context
    if not c then return original(fruit,sx,sz,wx,wz,hx,hz,ground,ridge,angle,growth,...) end
    local s=c.vehicle.spec_rsPlacement
    local sample=c.sample
    -- Encode yield potential once in native crop coverage; do NOT also apply the
    -- old linear stand-loss mask or a harvest multiplier (both double-penalize).
    local probability
    if sample.population then probability=1-sample.population.yieldPotentialPercent/100
    else probability=1-(1-sample.skipsPercent/100)*(1-sample.placementLossPercent/100)*math.min(1,c.densityRate or s.settings.ratePercent/100) end
    local extra={...};local extraN=select("#",...)
    local area=math.abs((wx-sx)*(hz-sz)-(wz-sz)*(hx-sx))
    c.attemptedSqm=c.attemptedSqm+area
    if probability<0.001 then return original(fruit,sx,sz,wx,wz,hx,hz,ground,ridge,angle,growth,...) end
    local changed,total=0,0
    local run
    local function flush()
        if not run then return end
        local a,b=original(fruit,run.x0,run.z0,run.x1,run.z1,run.x2,run.z2,ground,ridge,angle,growth,unpack(extra,1,extraN))
        changed=changed+(a or 0);total=total+(b or 0);run=nil
    end
    local partitioned=M.partition(sx,sz,wx,wz,hx,hz,1,function(x0,z0,x1,z1,x2,z2,i,j,sqm)
        if M.random(i,j,c.salt)>=probability then
            if run and run.j==j and run.i+1==i then run.x1=x1;run.z1=z1;run.i=i
            else flush();run={x0=x0,z0=z0,x1=x1,z1=z1,x2=x2,z2=z2,i=i,j=j} end
        else flush();c.skippedSqm=c.skippedSqm+sqm end
    end)
    flush()
    if not partitioned then
        sample.geometryFallback=true
        return original(fruit,sx,sz,wx,wz,hx,hz,ground,ridge,angle,growth,...)
    end
    return changed,total
end

-- Supported row layouts divide one native rectangular sowing work area. Every
-- row still goes through native eligibility and the same placement model.
function P.density(original,fruit,sx,sz,wx,wz,hx,hz,ground,ridge,angle,growth,...)
    local c=P.context
    if not c or not c.vehicle.spec_rsPlacement.profile.rowDrive then return P.densityPrimitive(original,fruit,sx,sz,wx,wz,hx,hz,ground,ridge,angle,growth,...) end
    local s=c.vehicle.spec_rsPlacement;local n=s.profile.rowCount or 0
    if n<1 or n>24 or not c.calibration then return P.densityPrimitive(original,fruit,sx,sz,wx,wz,hx,hz,ground,ridge,angle,growth,...) end
    local base=c.sample;local oldDensity=c.densityRate;local rows={};local changed,total,active,rateSum=0,0,0,0
    local averageYield,averageEstablished=0,0
    for row=1,n do
        local a,b=(row-1)/n,row/n
        -- Other map mods may pad/flip the native density plane. Locate rows
        -- against the physical implement width, not that expanded plane.
        local layout=c.rowLayout;local dx,dz=wx-sx,wz-sz;local length2=dx*dx+dz*dz
        if layout and length2>0.000001 then
            local function project(t)
                local x=layout.sx+(layout.wx-layout.sx)*t
                local z=layout.sz+(layout.wz-layout.sz)*t
                return M.clamp(((x-sx)*dx+(z-sz)*dz)/length2,0,1)
            end
            a,b=project(a),project(b)
        end
        local x0,z0=sx+(wx-sx)*a,sz+(wz-sz)*a
        local x1,z1=sx+(wx-sx)*b,sz+(wz-sz)*b
        local x2,z2=hx+(wx-sx)*a,hz+(wz-sz)*a
        local on=RSControlModel.rowEnabled(s.settings,row)
        local factor=s.settings['rowRate'..row]/100
        rows[row]={row=row,active=on,targetRatePerAcre=c.calibration.ratePerAcre*factor,actualRatePerAcre=on and c.calibration.ratePerAcre*factor*base.deliveryScale or 0,
            skipsPercent=on and base.skipsPercent or nil,doublesPercent=on and base.doublesPercent or nil,source='simulatedRowDrive'}
        if on then
            active=active+1;rateSum=rateSum+factor
            local sample={};for key,value in pairs(base) do sample[key]=value end
            local calibration={};for key,value in pairs(c.calibration) do calibration[key]=value end
            calibration.ratePerAcre=calibration.ratePerAcre*factor
            sample.population=M.populationResponse(c.crop,calibration,c.reference,sample)
            averageYield=averageYield+sample.population.yieldPotentialPercent;averageEstablished=averageEstablished+sample.population.establishedSeedsPerAcre
            c.sample=sample;c.densityRate=oldDensity*factor
            local aa,bb=0,0
            if math.abs(a-b)>0.000001 then aa,bb=P.densityPrimitive(original,fruit,x0,z0,x1,z1,x2,z2,ground,ridge,angle,growth,...) end
            c.acceptedRows=c.acceptedRows or {}
            if (aa or 0)>0 then c.acceptedRows[#c.acceptedRows+1]={row=row,x0=x0,z0=z0,x1=x1,z1=z1,x2=x2,z2=z2,real=aa,total=bb or 0} end
            changed=changed+(aa or 0);total=total+(bb or 0)
        else c.attemptedSqm=c.attemptedSqm+math.abs((x1-x0)*(z2-z0)-(z1-z0)*(x2-x0)) end
    end
    c.sample=base;c.densityRate=oldDensity;c.rowRateFactor=rateSum/n;c.activeRowFraction=active/n;base.rows=rows
    if active>0 then base.population.yieldPotentialPercent=averageYield/active;base.population.establishedSeedsPerAcre=averageEstablished/active end
    return changed,total
end

function P:onRegisterActionEvents(active)
    if not self.isClient or not self.spec_rsPlacement.enabled then return end
    local s=self.spec_rsPlacement;self:clearActionEventsTable(s.actionEvents)
    if active then
        local _,id=self:addActionEvent(s.actionEvents,InputAction.RS_PLACEMENT_SETUP,self,P.openSetup,false,true,false,true)
        g_inputBinding:setActionEventText(id,"Seed placement setup / inspection")
        g_inputBinding:setActionEventTextPriority(id,GS_PRIO_NORMAL)
    end
end
function P.openSetup(vehicle)
    RSSetupDialog.show(vehicle)
end

RSPlacementSettingEvent={}
local E=RSPlacementSettingEvent
local eventMt=Class(E,Event)
InitEventClass(E,"RSPlacementSettingEvent")
function E.emptyNew() return Event.new(eventMt) end
function E.new(vehicle,name,value)
    local event=E.emptyNew();event.vehicle=vehicle;event.name=name;event.value=value;return event
end
function E:writeStream(streamId,connection)
    NetworkUtil.writeNodeObject(streamId,self.vehicle);streamWriteString(streamId,self.name);streamWriteFloat32(streamId,self.value)
end
function E:readStream(streamId,connection)
    self.vehicle=NetworkUtil.readNodeObject(streamId);self.name=streamReadString(streamId);self.value=streamReadFloat32(streamId);self:run(connection)
end
function E:run(connection)
    local v=self.vehicle
    if not v or not v.spec_rsPlacement or not M.limits[self.name] or not M.finite(self.value) then return end
    if not connection:getIsServer() then
        local root=v:getRootVehicle()
        if not root or root:getControllerConnection()~=connection then return end
        local ok=v:rsSetPlacementSetting(self.name,self.value,true)
        if ok then g_server:broadcastEvent(E.new(v,self.name,self.value),nil,nil,v) end
    else
        local s=v.spec_rsPlacement
        if self.value>=M.limits[self.name][1] and self.value<=M.limits[self.name][2] then
            s.settings[self.name]=self.value;s.revision=s.revision+1
            if self.name=="ratePerAcre" then s.settings.ratePercent=100 end
        end
    end
end

-- Install once, before vehicle types finalize; preserve existing hook chains.
for _,name in ipairs({"updateSowingArea","updateDirectSowingArea"}) do
    local original=FSDensityMapUtil[name]
    FSDensityMapUtil[name]=function(...) return P.density(original,...) end
end
local endProcessing=SowingMachine.onEndWorkAreaProcessing
SowingMachine.onEndWorkAreaProcessing=function(vehicle,...) return P.endProcessing(vehicle,endProcessing,...) end

addModEventListener({deleteMap=function()
    P.context=nil;A.listeners={};A.link=nil
    if g_currentMission then g_currentMission.realisticSeederAPI=nil end
end})
