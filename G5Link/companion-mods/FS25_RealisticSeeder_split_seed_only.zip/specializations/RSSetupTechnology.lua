-- Additional inline pages share one draft and one validated Apply action.
local D=RSSetupDialog
local C=RSControlModel
local inputs={depthMinMm='minimumDepthInput',depthMaxMm='maximumDepthInput',rowCleanerPosition='cleanerPositionInput'}
local loadDraft=D.loadDraft
function D:loadDraft()
 loadDraft(self)
 self.controlDraft={};self.initialControls={};self.selectedRow=1
 for _,key in ipairs(C.keys) do self.controlDraft[key]=self.vehicle.spec_rsPlacement.settings[key];self.initialControls[key]=self.controlDraft[key] end
end
function D:readTechnologyInputs()
 if not self.controlDraft then return end
 if self.detailMode=='controls' then for key,id in pairs(inputs) do self.controlDraft[key]=self[id]:getText() end
 elseif self.detailMode=='rows' then self.controlDraft['rowRate'..self.selectedRow]=self.rowRateInput:getText() end
end
local refresh=D.refresh
function D:refresh()
 self:readTechnologyInputs();refresh(self)
 local p=self.vehicle.spec_rsPlacement.profile
 self.depthButtonLabel:setText(p.cabDepthControl and 'Depth target (cab)' or 'Depth (manual adjustment)')
 self.pressureButtonLabel:setText(p.cabDownforceControl and 'Opener pressure / auto bias' or 'Opener pressure (manual)')
 self.closingButtonLabel:setText(p.cabClosingControl and 'Closing pressure / auto bias' or 'Closing / packing (manual)')
end
local showInformation=D.showInformation
function D:showInformation(mode,text)
 self:readTechnologyInputs();showInformation(self,mode,text)
end
function D:onClickControls()self:showInformation('controls','')end
function D:onClickRows()self:showInformation('rows','')end
function D:toggleMode(key)
 self:readTechnologyInputs()
 local value=tonumber(self.controlDraft[key])==1 and 0 or 1
 local ok,why=C.allowed(self.vehicle.spec_rsPlacement.profile,key,value)
 if ok then self.controlDraft[key]=value else self.message=why;self.statusText:setText(why) end
 self:refreshDetails()
end
function D:onDepthMode()self:toggleMode('depthMode')end
function D:onDownforceMode()self:toggleMode('downforceMode')end
function D:onClosingMode()self:toggleMode('closingMode')end
function D:selectRow(delta)
 self:readTechnologyInputs()
 self.selectedRow=(self.selectedRow-1+delta)%math.max(1,self.vehicle.spec_rsPlacement.profile.rowCount or 0)+1
 self:refreshDetails()
end
function D:onPreviousRow()self:selectRow(-1)end
function D:onNextRow()self:selectRow(1)end
function D:onToggleRow()
 self:readTechnologyInputs()
 local p=self.vehicle.spec_rsPlacement.profile
 if not p.rowShutoff then self.statusText:setText('Row clutches, electric row drives or section shutoff are required.');return end
 local mask=tonumber(self.controlDraft.rowOffMask) or 0;local bit=2^(self.selectedRow-1)
 self.controlDraft.rowOffMask=C.rowEnabled({rowOffMask=mask},self.selectedRow) and mask+bit or mask-bit
 self:refreshDetails()
end
function D:onAutoShutoff()
 self:readTechnologyInputs()
 local value=tonumber(self.controlDraft.autoShutoff)==1 and 0 or 1
 local ok,why=C.allowed(self.vehicle.spec_rsPlacement.profile,'autoShutoff',value)
 if ok then self.controlDraft.autoShutoff=value else self.message=why;self.statusText:setText(why) end
 self:refreshDetails()
end
function D:onShutoffOverlap()
 self:readTechnologyInputs()
 if not self.vehicle.spec_rsPlacement.profile.rowShutoff then return end
 self.controlDraft.shutoffOverlap=((tonumber(self.controlDraft.shutoffOverlap) or 0)+1)%3
 self:refreshDetails()
end
function D:refreshDetails()
 local mode=self.detailMode;local p=self.vehicle.spec_rsPlacement.profile
 local report=mode=='inspection' or mode=='equipment'
 self.technologyText:setVisible(mode==nil);self.sampleText:setVisible(mode==nil);self.hardwareText:setVisible(false)
 self.detailText:setVisible(report);self.detailText:setText(self.detailReport or '')
 self.controlPanel:setVisible(mode=='controls');self.rowsPanel:setVisible(mode=='rows')
 self.detailsHeading:setText(({inspection='LAST PASS INSPECTION (SIMULATED)',equipment='EQUIPMENT / UPGRADE HELP',controls='CONTROL MODES - DRAFT',rows='INDIVIDUAL ROW CONTROL - DRAFT'})[mode] or 'INSTALLED TECHNOLOGY')
 self.inspectionButton:setText(mode=='inspection' and 'Back to technology' or 'Inspect last pass')
 self.equipmentButton:setText(mode=='equipment' and 'Back to technology' or 'Equipment / upgrade help')
 if not self.controlDraft then return end
 for key,id in pairs(inputs) do self[id]:setText(tostring(self.controlDraft[key])) end
 for _,entry in ipairs({{'depthMode','depthModeButton','Depth','cabDepthControl'},{'downforceMode','downforceModeButton','Downforce','cabDownforceControl'},{'closingMode','closingModeButton','Closing / packing','cabClosingControl'}}) do
  local key,id,label,cab=unpack(entry);local modeName=tonumber(self.controlDraft[key])==1 and 'Automatic' or (p[cab] and 'Cab adjustable' or 'Manual')
  self[id]:setText(label..': '..modeName);self[id]:setDisabled(not p[C.modeCaps[key]] and tonumber(self.controlDraft[key])~=1)
 end
 self.minimumDepthInput:setDisabled(not p.automaticDepth);self.maximumDepthInput:setDisabled(not p.automaticDepth)
 self.cleanerPositionInput:setDisabled(not p.rowCleanerDisplayControl)
 local sample=self.vehicle.spec_rsPlacement.lastSample
 local controls=sample and sample.controls
 local text='Automatic pressure: 50% is neutral bias; higher adds force.\nMissing soil data holds the manual target. Soil-adaptive depth uses modeled seedbed moisture, not a vertical moisture scan.'
 if controls then local a=controls.applied;text=text..string.format('\nLast applied: %.1f mm / opener %.0f%% / closing %.0f%%',a.depthMm,a.pressurePercent,a.closingPercent) end
 self.controlNote:setText(text)
 local lane=p.laneKind=='section' and 'Section' or ((p.rowsPerLane or 1)>1 and 'Row group' or 'Row')
 self.rowTitle:setText(lane..' '..self.selectedRow..' of '..tostring(p.rowCount or 0)..' (from the left)')
 self.rowRateInput:setText(tostring(self.controlDraft['rowRate'..self.selectedRow] or 100));self.rowRateInput:setDisabled(not p.rowDrive)
 self.rowEnableButton:setText(lane..': '..(C.rowEnabled({rowOffMask=tonumber(self.controlDraft.rowOffMask) or 0},self.selectedRow) and 'ON' or 'OFF'))
 self.rowEnableButton:setDisabled(not p.rowShutoff)
 local s=self.vehicle.spec_rsPlacement
 local controller=C.shutoffController(p,s.settings,s.external)
 if controller and controller.external then
  self.autoShutoffButton:setText('Auto shutoff: '..controller.source..' ('..(controller.enabled and 'ON' or 'OFF')..')');self.autoShutoffButton:setDisabled(true)
 else
  self.autoShutoffButton:setText('Auto shutoff: '..(not p.autoShutoffController and 'not fitted' or tonumber(self.controlDraft.autoShutoff)==1 and 'ON' or 'OFF'))
  self.autoShutoffButton:setDisabled(not p.rowShutoff or not p.autoShutoffController)
 end
 self.overlapButton:setText('Overlap: '..(C.overlapNames[tonumber(controller and controller.external and controller.overlap or self.controlDraft.shutoffOverlap) or 0] or '---'))
 self.overlapButton:setDisabled(not p.rowShutoff or (controller~=nil and controller.external==true))
 local lines={not p.rowShutoff and 'Fit row clutches, electric row drives (planters) or section shutoff (drills) to use this page.'
  or (p.rowDrive and 'Rate is a percentage of the main application target.' or 'Clutches/sections switch on and off; the rate is set for the whole machine.')..
   (controller and '\nAutomatic shutoff turns lanes off ahead of ground already planted.' or '\nManual shutoff only. Add the GPS shutoff unlock or a G5Link Section Control activation for automatic shutoff.')}
 local first=math.floor((self.selectedRow-1)/8)*8+1
 for i=first,math.min(first+7,p.rowCount or 0) do
  local live=s.rowStatus and s.rowStatus[i]
  local state=C.rowEnabled({rowOffMask=tonumber(self.controlDraft.rowOffMask) or 0},i) and (live and live.reason=='covered' and 'AUTO OFF' or 'ON') or 'OFF'
  lines[#lines+1]=p.rowDrive and string.format('%s %d: %s  |  %s%%',lane,i,state,tostring(self.controlDraft['rowRate'..i])) or string.format('%s %d: %s',lane,i,state)
 end
 self.rowSummary:setText(table.concat(lines,'\n'))
end
function D.collectTechnologyChanges(vehicle,draft,initial)
 local changes={};local p=vehicle.spec_rsPlacement.profile
 for _,key in ipairs(C.keys) do
  local value=tonumber(draft[key]);local limits=RSPlacementModel.limits[key]
  if not RSPlacementModel.finite(value) or value<limits[1] or value>limits[2] then return nil,'Invalid technology value: '..key end
  if value~=initial[key] then
   local ok,why=C.allowed(p,key,value);if not ok then return nil,why end
   if not C.cabAllowed(p,key) and (vehicle:getLastSpeed()>.5 or vehicle:getIsTurnedOn()) then return nil,'Stop and switch off for mechanical adjustments.' end
   changes[#changes+1]={key=key,value=value}
  end
 end
 if tonumber(draft.depthMinMm)>tonumber(draft.depthMaxMm) then return nil,'Minimum depth must not exceed maximum depth.' end
 return changes
end
function D:onApply()
 self:readTechnologyInputs()
 local fields={};for _,row in ipairs(D.rows) do fields[row.key]=self[row.id]:getText();self[row.id]:setForcePressed(false) end
 local changes,message=D.collectChanges(self.vehicle,fields,self.initialValues,self.presetLoaded,self.draftRevision)
 local technology,why=D.collectTechnologyChanges(self.vehicle,self.controlDraft,self.initialControls)
 if not changes or not technology then self.message=message or why;self:refresh();return end
 for _,c in ipairs(technology) do changes[#changes+1]=c end
 -- Preflight actuator availability before applying any part of a mixed draft.
 for _,c in ipairs(changes) do if c.key=='rowCleanerPosition' and not C.cleanerTool(self.vehicle) then self.message='Row cleaner actuator unavailable. Nothing applied.';self:refresh();return end end
 for _,c in ipairs(changes) do local ok,reason=self.vehicle:rsSetPlacementSetting(c.key,c.value);if not ok then self.message=reason;self:refresh();return end end
 self.message=#changes==0 and 'No settings changed.' or 'Settings applied. Save the farm to keep them.'
 self.detailMode=nil;self:loadDraft();self:refresh()
end
