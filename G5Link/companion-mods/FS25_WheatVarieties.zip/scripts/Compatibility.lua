local WV = WheatVarieties
local Compat = {}
WV.Compatibility = Compat

local function wheatFillIndex()
    local wheat = g_fillTypeManager and g_fillTypeManager:getFillTypeByName("WHEAT")
    return wheat and wheat.index
end

function Compat.extendFillSet(set)
    local wheatIndex = wheatFillIndex()
    if type(set) ~= "table" or not wheatIndex or not set[wheatIndex] then return false end
    local changed = false
    for _, def in ipairs(WV.definitions) do
        local fill = WV.state.fills[def.name]
        if fill and not set[fill.index] then set[fill.index] = true; changed = true end
    end
    return changed
end

function Compat.patchFillUnits(vehicle)
    local spec = vehicle.spec_fillUnit
    for _, unit in ipairs(spec and spec.fillUnits or {}) do Compat.extendFillSet(unit.supportedFillTypes) end
end

function Compat.patchSeeder(vehicle)
    local spec = vehicle.spec_sowingMachine
    if not spec or not spec.seeds then return end
    local wheat = g_fruitTypeManager and g_fruitTypeManager:getFruitTypeByName("WHEAT")
    local selected = spec.seeds[spec.currentSeed or 1]
    local acceptsWheat = wheat and WV.contains(spec.seeds, wheat.index)
    local own = {}
    for _, fruit in pairs(WV.state.fruits) do own[fruit.index] = true end
    local seeds = {}
    for _, index in ipairs(spec.seeds) do
        if not own[index] then seeds[#seeds + 1] = index end
    end
    -- Keep the same provisional ordering while savegame/network seed indices
    -- are being read. Removing/readding entries during join would clamp indices.
    -- Terrain validation removes unsupported varieties before play begins.
    if acceptsWheat and WV.state.fruitsLoaded and WV.state.ready ~= false and WV.state.phase ~= "failed" then
        for _, def in ipairs(WV.definitions) do seeds[#seeds + 1] = WV.state.fruits[def.name].index end
    end
    spec.seeds = seeds
    local selectedIndex = #seeds > 0 and 1 or 0
    for index, fruit in ipairs(seeds) do if fruit == selected then selectedIndex = index end end
    spec.currentSeed = selectedIndex
    if selectedIndex > 0 and vehicle.setSeedIndex then vehicle:setSeedIndex(selectedIndex, true) end
end

function Compat.patchCutter(vehicle)
    local spec = vehicle.spec_cutter
    local wheat = g_fruitTypeManager and g_fruitTypeManager:getFruitTypeByName("WHEAT")
    -- Converted forage/pickup headers require their own adapters.
    if not spec or not wheat or spec.fillTypeConverter or next(spec.fruitTypeConverters or {}) ~= nil then return end
    if not WV.contains(spec.fruitTypeIndices, wheat.index) then return end
    for _, def in ipairs(WV.definitions) do
        local fruit, fill = WV.state.fruits[def.name], WV.state.fills[def.name]
        if fruit and fill then
            if not WV.contains(spec.fruitTypeIndices, fruit.index) then table.insert(spec.fruitTypeIndices, fruit.index) end
            if not WV.contains(spec.outputFillTypes, fill.index) then table.insert(spec.outputFillTypes, fill.index) end
        end
    end
end

function Compat.patchStorage(storage, key)
    -- Limit automatic storage expansion to silos, not production or animal storage.
    if type(key) ~= "string" or not (key:match("^placeable%.silo%.") or key:match("^placeable%.siloExtension%.")) then return end
    local wheat = wheatFillIndex()
    if not wheat or not storage.fillTypes or not storage.fillTypes[wheat] then return end
    if not storage.capacities or storage.capacities[wheat] ~= nil then return end
    for _, name in ipairs({"fillLevels", "fillLevelsLastSynced", "fillLevelsLastPublished", "sortedFillTypes"}) do
        if type(storage[name]) ~= "table" then WV.log("Storage layout unsupported: %s", name); return end
    end
    for _, def in ipairs(WV.definitions) do
        local fill = WV.state.fills[def.name]
        if fill and not storage.fillTypes[fill.index] then
            storage.fillTypes[fill.index] = true
            storage.fillLevels[fill.index] = 0
            storage.fillLevelsLastSynced[fill.index] = 0
            storage.fillLevelsLastPublished[fill.index] = 0
            table.insert(storage.sortedFillTypes, fill.index)
        end
    end
    table.sort(storage.sortedFillTypes)
end

function Compat.patchStation(station, placeable)
    if not placeable or placeable.spec_productionPoint or placeable.spec_factory or placeable.spec_husbandry then return end
    if not (placeable.spec_silo or placeable.spec_sellingStation) then return end
    local wheat = wheatFillIndex()
    if not wheat then return end
    local added, candidates = false, {}
    for _, def in ipairs(WV.definitions) do
        local fill = WV.state.fills[def.name]
        if fill then
            local hasStorage, canStore = false, false
            for storage in pairs(station.targetStorages or {}) do
                hasStorage = true
                if storage.fillTypes and storage.fillTypes[fill.index] then canStore = true end
            end
            if canStore or (not hasStorage and placeable.spec_sellingStation) then candidates[fill.index] = fill end
        end
    end
    for _, trigger in ipairs(station.unloadTriggers or {}) do
        if trigger.fillTypes and trigger.fillTypes[wheat] then
            for index in pairs(candidates) do
                if not trigger.fillTypes[index] then trigger.fillTypes[index] = true; added = true end
            end
        end
    end
    if added and station.updateSupportedFillTypes then station:updateSupportedFillTypes() end
    if #(station.unloadTriggers or {}) == 0 and station.supportedFillTypes and station.supportedFillTypes[wheat] then
        for index in pairs(candidates) do station.supportedFillTypes[index] = true end
    end
    if station.acceptedFillTypes and station.acceptedFillTypes[wheat] and station.addAcceptedFillType then
        local priced = false
        for index, fill in pairs(candidates) do
            if station.supportedFillTypes and station.supportedFillTypes[index] and not station.acceptedFillTypes[index] then
                station:addAcceptedFillType(index, fill.pricePerLiter, false, false)
                priced = true
            end
        end
        if priced and station.initPricingDynamics then station:initPricingDynamics() end
    end
end

function Compat.patchLoadTrigger(trigger, key)
    if type(key) == "string" and key:match("^placeable%.silo%.") then Compat.extendFillSet(trigger.fillTypes) end
end

function Compat.syncVisuals()
    local wheat = g_fillTypeManager and g_fillTypeManager:getFillTypeByName("WHEAT")
    if not wheat then return end
    for _, fill in pairs(WV.state.fills) do
        -- Reuse the material texture layer, not the ground-heap identity.
        fill.textureArrayIndex = wheat.textureArrayIndex
    end
end

function Compat.material(manager, original, fillType, materialType, materialIndex, ...)
    for _, fill in pairs(WV.state.fills) do
        if fill.index == fillType then
            return original(manager, wheatFillIndex(), materialType, materialIndex, ...)
        end
    end
    return original(manager, fillType, materialType, materialIndex, ...)
end
