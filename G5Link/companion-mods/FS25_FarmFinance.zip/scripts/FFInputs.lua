-- FS25_FarmFinance - input account and early-pay discount (pure rules).
--
-- Seed, fertilizer and chemicals can go on a farm-supply account instead of
-- cash, like the pay-after-harvest programs seed companies and retailers run.
--   * The limit comes from the farm's assets and credit grade.
--   * No interest until the due date (early winter after the season the
--     inputs are for). On the due date the account is paid from cash as far
--     as cash allows; anything left is past due and charges interest.
--   * Inputs paid in cash in the prepay season get an early-pay discount.
-- The game has already taken the cash when a purchase is reported here; the
-- account "gives it back" (a draw) and books the charge instead.
-- Game calls go through FF.env: addMoney, addMoneyQuiet, getMoney, notify,
-- getPeriod, snapshot.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region

FF.Inputs = {}
local IN = FF.Inputs

IN.GRADE_FACTOR = {A = 1.0, B = 0.9, C = 0.75, D = 0.5, E = 0}
IN.extraFillTypes = IN.extraFillTypes or {}

local function env()
    return FF.env or {}
end

local function addMoney(amount, farmId, typeKey, quiet)
    if amount == 0 then
        return
    end
    if quiet and env().addMoneyQuiet ~= nil then
        env().addMoneyQuiet(amount, farmId, typeKey)
    elseif env().addMoney ~= nil then
        env().addMoney(amount, farmId, typeKey)
    end
end

local function notify(farmId, text, isWarning)
    if env().notify ~= nil then
        env().notify(farmId, text, isWarning)
    end
end

local function markDirty()
    if env().markDirty ~= nil then
        env().markDirty()
    end
end

local function currentPeriod()
    if env().getPeriod ~= nil then
        return env().getPeriod()
    end
    return FF.state.period or 1
end

function IN.isEnabled()
    return R.get("inputs.account.enabled", true) ~= false
end

function IN.getAccount(farm)
    farm.inputs = farm.inputs or {}
    local account = farm.inputs
    if account.autoCharge == nil then
        account.autoCharge = true
    end
    account.charges = account.charges or {}
    account.discounts = account.discounts or 0
    account.interestPaid = account.interestPaid or 0
    return account
end

-- Fill types --------------------------------------------------------------------

function IN.isInputFillType(name)
    if name == nil then
        return false
    end
    name = string.upper(tostring(name))
    if IN.extraFillTypes[name] then
        return true
    end
    for _, item in ipairs(U.split(R.get("inputs.fillTypes", ""), ",")) do
        if string.upper(item) == name then
            return true
        end
    end
    return false
end

function IN.registerFillType(name)
    if name ~= nil and name ~= "" then
        IN.extraFillTypes[string.upper(tostring(name))] = true
        return true
    end
    return false
end

-- Terms ---------------------------------------------------------------------------

function IN.getEarlyPayDiscount(period)
    period = period or currentPeriod()
    for _, step in ipairs(R.get("inputs.earlyPay", {})) do
        if step.period == period then
            return step.discount or 0
        end
    end
    return 0
end

-- Crop year a purchase made now is due in.
function IN.getDueCropYear(period)
    period = period or currentPeriod()
    if period >= R.get("inputs.account.nextSeasonFromPeriod", 7) then
        return FF.state.cropYear + 1
    end
    return FF.state.cropYear
end

function IN.isPastDue(charge, period)
    period = period or currentPeriod()
    local duePeriod = R.get("inputs.account.dueDatePeriod", 10)
    if charge.dueCropYear < FF.state.cropYear then
        return true
    end
    return charge.dueCropYear == FF.state.cropYear and (charge.missedDue == true or period > duePeriod)
end

function IN.getPastDueRate()
    return (FF.state.baseRate or 0.065) + R.get("inputs.account.pastDueSpread", 0.10)
end

function IN.getBalance(farm)
    local total, pastDue = 0, 0
    if farm == nil or farm.inputs == nil then
        return 0, 0
    end
    for _, charge in ipairs(farm.inputs.charges or {}) do
        total = total + charge.remaining
        if charge.missedDue then
            pastDue = pastDue + charge.remaining
        end
    end
    return total, pastDue
end

function IN.getLimit(farmId)
    local farm = FF.Bank.getFarm(farmId)
    local evaluation = FF.Bank.evaluate(farmId)
    if evaluation.score < R.get("credit.minScore", 580) then
        return 0, evaluation
    end
    local assets = evaluation.snapshot.totalAssets or 0
    local limit = assets * R.get("inputs.account.limitShareOfAssets", 0.05)
    limit = U.clamp(limit, R.get("inputs.account.minLimit", 25000), R.get("inputs.account.maxLimit", 2000000))
    limit = limit * (IN.GRADE_FACTOR[evaluation.grade] or 0)
    local _, pastDue = IN.getBalance(farm)
    if pastDue > 0 then
        limit = 0
    end
    return math.floor(limit / 100) * 100, evaluation
end

function IN.getAvailable(farmId)
    local farm = FF.Bank.getFarm(farmId)
    local limit = IN.getLimit(farmId)
    local balance = IN.getBalance(farm)
    return math.max(limit - balance, 0), limit, balance
end

-- Purchases ---------------------------------------------------------------------------

-- Books `amount` on the account (one charge per month and due year).
local function addCharge(farm, amount, description)
    local account = IN.getAccount(farm)
    local dueCropYear = IN.getDueCropYear()
    local month = FF.state.monthIndex
    for _, charge in ipairs(account.charges) do
        if charge.month == month and charge.dueCropYear == dueCropYear and not charge.missedDue then
            charge.amount = charge.amount + amount
            charge.remaining = charge.remaining + amount
            charge.description = description or charge.description
            return charge
        end
    end
    local charge = {
        id = FF.Bank.nextId("I"),
        amount = amount,
        remaining = amount,
        dueCropYear = dueCropYear,
        month = month,
        description = description
    }
    table.insert(account.charges, charge)
    return charge
end

-- The farm paid `amount` in cash for inputs. Moves it onto the account when
-- auto-charge is on and there is room; otherwise applies the early-pay
-- discount. Returns method ("account" or "cash") and the amount booked or
-- refunded as discount.
function IN.onInputPurchase(farmId, amount, info)
    if amount == nil or amount <= 0 or FF.state == nil then
        return nil, 0
    end
    info = info or {}
    local farm = FF.Bank.getFarm(farmId)
    local account = IN.getAccount(farm)
    local quiet = info.quiet == true

    if IN.isEnabled() and account.autoCharge and info.allowAccount ~= false then
        local available = IN.getAvailable(farmId)
        if available >= amount then
            addCharge(farm, amount, info.description)
            addMoney(amount, farmId, "inputAccountDraw", quiet)
            markDirty()
            return "account", amount
        end
        if not account.warnedFull then
            account.warnedFull = true
            notify(farmId, U.text("ff_msg_accountFull"), true)
        end
    end

    if info.applyDiscount ~= false then
        local discount = IN.getEarlyPayDiscount()
        if discount > 0 then
            local rebate = amount * discount
            addMoney(rebate, farmId, "inputDiscount", quiet)
            account.discounts = account.discounts + rebate
            markDirty()
            return "cash", rebate
        end
    end
    return "cash", 0
end

-- Pays toward the account from cash, past-due and oldest charges first.
-- amount nil = everything owed.
function IN.payNow(farmId, amount)
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil or farm.inputs == nil then
        return false, "ff_reason_nothingOwed"
    end
    local account = IN.getAccount(farm)
    local balance = IN.getBalance(farm)
    if balance <= 0 then
        return false, "ff_reason_nothingOwed"
    end
    amount = math.min(amount or balance, balance)
    if env().getMoney ~= nil and env().getMoney(farmId) < amount then
        return false, "ff_reason_noCash"
    end
    table.sort(account.charges, function(a, b)
        if (a.missedDue == true) ~= (b.missedDue == true) then
            return a.missedDue == true
        end
        if a.dueCropYear ~= b.dueCropYear then
            return a.dueCropYear < b.dueCropYear
        end
        return (a.month or 0) < (b.month or 0)
    end)
    local left = amount
    for _, charge in ipairs(account.charges) do
        if left <= 0 then
            break
        end
        local pay = math.min(charge.remaining, left)
        charge.remaining = charge.remaining - pay
        left = left - pay
    end
    IN.removePaid(account)
    addMoney(-amount, farmId, "inputAccountPayment")
    markDirty()
    return true
end

function IN.removePaid(account)
    for index = #account.charges, 1, -1 do
        if account.charges[index].remaining <= 0.5 then
            table.remove(account.charges, index)
        end
    end
    local hasPastDue = false
    for _, charge in ipairs(account.charges) do
        if charge.missedDue then
            hasPastDue = true
        end
    end
    if not hasPastDue then
        account.warnedFull = nil
    end
end

function IN.setAutoCharge(farmId, enabled)
    local farm = FF.Bank.getFarm(farmId)
    IN.getAccount(farm).autoCharge = enabled == true
    markDirty()
    return true
end

-- Monthly (called by the bank for each farm). Returns the amount the farm
-- paid toward the account and whether any of it is past due.
function IN.processMonth(farm, period)
    if farm.inputs == nil then
        return 0, false
    end
    local account = IN.getAccount(farm)
    local paid = 0
    local pastDue = false

    -- Interest on past-due charges
    local rate = IN.getPastDueRate()
    for _, charge in ipairs(account.charges) do
        if charge.missedDue and charge.remaining > 0 then
            local interest = charge.remaining * rate / 12
            addMoney(-interest, farm.farmId, "inputAccountInterest")
            account.interestPaid = account.interestPaid + interest
            paid = paid + interest
            pastDue = true
        end
    end

    -- Due date: pay what is due from cash; the rest goes past due.
    if period == R.get("inputs.account.dueDatePeriod", 10) then
        local due = 0
        for _, charge in ipairs(account.charges) do
            if charge.dueCropYear <= FF.state.cropYear and not charge.missedDue then
                due = due + charge.remaining
            end
        end
        if due > 0 then
            local cash = env().getMoney ~= nil and env().getMoney(farm.farmId) or due
            local pay = math.min(due, math.max(cash, 0))
            local left = pay
            for _, charge in ipairs(account.charges) do
                if charge.dueCropYear <= FF.state.cropYear and not charge.missedDue then
                    local part = math.min(charge.remaining, left)
                    charge.remaining = charge.remaining - part
                    left = left - part
                    if charge.remaining > 0.5 then
                        charge.missedDue = true
                    end
                end
            end
            if pay > 0 then
                addMoney(-pay, farm.farmId, "inputAccountPayment")
                paid = paid + pay
            end
            if pay < due - 0.5 then
                pastDue = true
                notify(farm.farmId, U.text("ff_msg_accountPastDue", U.money(due - pay)), true)
            else
                notify(farm.farmId, U.text("ff_msg_accountPaid", U.money(pay)), false)
            end
            IN.removePaid(account)
        end
    end
    return paid, pastDue
end

return IN
