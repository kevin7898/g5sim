local WV = WheatVarieties
local Compat = WV.Compatibility
local Registration = WV.Registration

function WV.install()
    if #WV.hooks > 0 then return end
    WV.hook(Utils, "getModNameAndBaseDirectory", function(filename, original, ...)
        if filename == WV.state.adaptedMap then filename = WV.state.originalMap end
        return original(filename, ...)
    end, true)
    WV.hook(BaseMission, "loadMap", function(mission, original, filename, ...)
        local ok, adapted = WV.try(WV.Terrain.prepare, filename)
        return original(mission, ok and adapted or filename, ...)
    end, true)
    WV.hook(FoliageSystem, "loadModFoliageType", function(system, original, name, ...)
        -- Older builds saved dynamic-loader entries. These crops are now
        -- embedded in the adapted map, so do not register them a second time.
        if WV.state.terrainAdapted and WV.Terrain.isOwnFoliage(name) then return end
        return original(system, name, ...)
    end, true)
    WV.hook(FoliageSystem, "loadModFoliageTypes", function(system, original, ...)
        WV.Terrain.filterSavedFoliage(system)
        return original(system, ...)
    end, true)
    WV.hook(FillTypeManager, "loadMapData", function(manager, original, ...)
        local result = WV.pack(original(manager, ...))
        if result[1] ~= false then WV.try(Registration.loadFills, manager) end
        return unpack(result, 1, result.n)
    end, true)
    WV.hook(FruitTypeManager, "loadMapData", function(manager, original, xml, missionInfo, ...)
        local result = WV.pack(original(manager, xml, missionInfo, ...))
        if result[1] ~= false then WV.try(Registration.loadFruits, manager, missionInfo) end
        return unpack(result, 1, result.n)
    end, true)
    WV.hook(FruitTypeDesc, "setTerrainDataPlaneIndex", function(fruit, original, index, ...)
        local result = WV.pack(original(fruit, index, ...))
        WV.state.terrainIndices = WV.state.terrainIndices or {}
        if fruit.name then WV.state.terrainIndices[fruit.name] = index end
        return unpack(result, 1, result.n)
    end)
    WV.hook(FillUnit, "onLoad", function(vehicle, original, ...)
        local result = WV.pack(original(vehicle, ...))
        WV.try(Compat.patchFillUnits, vehicle)
        return unpack(result, 1, result.n)
    end)
    WV.hook(SowingMachine, "onLoad", function(vehicle, original, ...)
        local result = WV.pack(original(vehicle, ...))
        WV.try(Compat.patchSeeder, vehicle)
        return unpack(result, 1, result.n)
    end)
    WV.hook(Cutter, "onLoad", function(vehicle, original, ...)
        local result = WV.pack(original(vehicle, ...))
        WV.try(Compat.patchCutter, vehicle)
        return unpack(result, 1, result.n)
    end)
    WV.hook(Storage, "load", function(storage, original, components, xml, key, ...)
        local result = WV.pack(original(storage, components, xml, key, ...))
        if result[1] then WV.try(Compat.patchStorage, storage, key) end
        return unpack(result, 1, result.n)
    end)
    WV.hook(StorageSystem, "addUnloadingStation", function(system, original, station, placeable, ...)
        local result = WV.pack(original(system, station, placeable, ...))
        if result[1] then WV.try(Compat.patchStation, station, placeable) end
        return unpack(result, 1, result.n)
    end)
    WV.hook(LoadTrigger, "load", function(trigger, original, components, xml, key, ...)
        local result = WV.pack(original(trigger, components, xml, key, ...))
        if result[1] then WV.try(Compat.patchLoadTrigger, trigger, key) end
        return unpack(result, 1, result.n)
    end)
    WV.hook(MaterialManager, "getMaterial", Compat.material)
    WV.hook(MaterialManager, "getParticleMaterial", Compat.material)
end

function WV:onMissionStarted()
    if WV.state.checked then return end
    WV.state.checked = true
    WV.try(Registration.validateTerrain)
    if WV.state.ready then WV.DoubleCrop.apply() end
    Compat.syncVisuals()
    for _, vehicle in pairs(g_currentMission and g_currentMission.vehicles or {}) do
        WV.try(Compat.patchSeeder, vehicle)
        WV.try(Compat.patchFillUnits, vehicle)
        WV.try(Compat.patchCutter, vehicle)
    end
    self:consoleStatus()
end

function WV:loadMap()
    if g_messageCenter and MessageType and MessageType.CURRENT_MISSION_START then
        g_messageCenter:subscribe(MessageType.CURRENT_MISSION_START, WV.onMissionStarted, self)
    else
        WV.fail("CURRENT_MISSION_START is unavailable; terrain validation cannot run")
    end
    if addConsoleCommand then
        addConsoleCommand("wvStatus", "Report wheat variety registration and terrain status", "consoleStatus", self)
    end
end

function WV:consoleStatus()
    WV.log("Version=%s phase=%s ready=%s errors=%d", WV.VERSION, WV.state.phase, tostring(WV.state.ready == true), #WV.state.errors)
    for _, def in ipairs(WV.definitions) do
        local fill, fruit = WV.state.fills[def.name], WV.state.fruits[def.name]
        WV.log("%s component=%s fill=%s fruit=%s grainYield=%s strawYield=%s plane=%s typeIndex=%s",
            def.name, def.componentId, tostring(fill and fill.index), tostring(fruit and fruit.index),
            tostring(fruit and fruit.literPerSqm), tostring(fruit and fruit.windrowLiterPerSqm),
            tostring(fruit and fruit.terrainDataPlaneId), tostring(WV.state.terrainIndices and WV.state.terrainIndices[def.name]))
    end
    WV.log("Blending=off; ground tipping=unsupported; production/animal feed=not adapted; NPC contracts=off")
    return "Wheat Varieties: " .. WV.state.phase .. " (details in log.txt)"
end

function WV:deleteMap()
    if g_messageCenter then g_messageCenter:unsubscribeAll(self) end
    if removeConsoleCommand then removeConsoleCommand("wvStatus") end
    WV.unhookAll()
    WV.state = { phase = "notLoaded", errors = {}, fruits = {}, fills = {} }
end

local ok, message = pcall(WV.install)
if not ok then WV.unhookAll(); WV.fail(message) end
addModEventListener(WV)
WV.log("Experimental build %s loaded. Separate grain types; terrain activation remains subject to validation.", WV.VERSION)
