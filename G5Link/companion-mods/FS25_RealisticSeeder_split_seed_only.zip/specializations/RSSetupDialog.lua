-- Native setup panel. All edits use the same validated vehicle setter as the API events.
RSSetupDialog={modDirectory=g_currentModDirectory}
local D=RSSetupDialog
local mt=Class(D,DialogElement)
D.rows={
 {id='depthButton',key='depthMm',label='Depth (manual adjustment)',unit='mm',hint='Stop and switch off to adjust mechanical depth, 5-100 mm. A depth sensor only reports depth; it cannot move the adjustment.'},
 {id='rateButton',key='ratePerAcre',label='Application rate',hint='Enter your target population or weight per acre. Setting this resets rate trim to 100%.'},
 {id='seedButton',key='seedsPerPound',label='Seed size',unit='seeds/lb',hint='Use seeds per pound from the seed bag tag. This calibrates seed count to weight.'},
 {id='pressureButton',key='pressurePercent',label='Opener pressure',unit='%',hint='0-100% control effort, not PSI. Firm/dry soils need more; wet soils need less. Inspect a test pass.'},
 {id='closingButton',key='closingPercent',label='Closing / packing',unit='%',hint='Dry soil needs firmer contact. Too much packing in wet soil increases sidewall risk. Inspect a test pass.'},
 {id='meterButton',key='meterPercent',label='Meter / feed calibration',unit='%',hint='50-150%; 100% is nominal. Changes modeled delivery, misses and seed usage.'}}
function D.new()
 local self=DialogElement.new(nil,mt)

 return self
end
function D.show(vehicle,message)
 if not vehicle or not vehicle.spec_rsPlacement or not vehicle.spec_rsPlacement.enabled then return end
 if not D.instance then
  local dialog=D.new()
  if not g_gui:loadGui(D.modDirectory..'gui/RSSetupDialog.xml','RSSetupDialog',dialog) then return end
  D.instance=dialog
 end
 D.instance.vehicle=vehicle;D.instance.message=message
 g_gui:showDialog('RSSetupDialog')
end
function D:onOpen()
 D:superClass().onOpen(self)
 self.detailMode=nil;self.detailReport=nil
 self:loadDraft()
 self:refresh()
 FocusManager:setFocus(self.depthButton)
end
function D:refresh()
 local v=self.vehicle;local s=v.spec_rsPlacement
 local c=RSPlacement.getCalibration(v)
 local unit=c.unit=='seedsPerAcre' and 'seeds/acre' or 'lb/acre'
 self.machineTitle:setText(v:getFullName())
 local fruit=v.spec_sowingMachine and g_fruitTypeManager:getFruitTypeByIndex(v.spec_sowingMachine.seeds[v.spec_sowingMachine.currentSeed])
 self.cropText:setText((s.profile.kind=='planter' and 'PLANTER' or 'DRILL / AIR SEEDER')..'  |  '..(fruit and (fruit.title or fruit.name) or 'No crop selected'))
 for _,row in ipairs(D.rows) do
  local label=row.label
  if row.key=='meterPercent' then label=s.profile.kind=='planter' and 'Meter calibration' or 'Feed / air calibration' end
  self[row.id..'Label']:setText(label)
  self[row.id..'Unit']:setText(row.unit or unit)
 end
 local stopped=v:getLastSpeed()<=0.5 and not v:getIsTurnedOn()
 self.accessText:setText(stopped and 'Edit values, then Apply changes. See Controls for fitted cab adjustments and automatic modes.' or 'Working: only settings with fitted cab controls can be changed. Stop / switch off for mechanical adjustments.')
 self.statusText:setText(self.message or 'Draft settings - use Apply changes to update this machine.')
 local acres=(s.counters.meteredSqm or 0)/RSSeedRate.SQM_PER_ACRE
 local liters=s.counters.seedLiters or 0
 local weight=c.kgPerLiter and liters*c.kgPerLiter/0.45359237
 local usage=string.format('Lifetime metered: %.2f ac  |  Seed used: %.1f L',acres,liters)
 if weight then usage=usage..string.format(' (~%.1f lb at current seed density)',weight) end
 self.usageText:setText(usage..'\nIncludes metering overlaps; differs from unique FieldPath coverage.')
 local sample=s.lastSample
 local measure={}
 if s.profile.depthSensor then
  measure[#measure+1]=sample and string.format('Depth sensor: %.1f mm',sample.actualDepthMm) or 'Depth sensor: awaiting planted sample'
 else measure[#measure+1]='Depth sensor: not fitted' end
 if s.profile.seedMonitor then
  if sample then
   measure[#measure+1]=s.profile.kind=='planter' and string.format('Skips %.1f%% / doubles %.1f%%',sample.skipsPercent,sample.doublesPercent) or string.format('Misses %.1f%% / distribution CV %.1f%%',sample.skipsPercent,sample.distributionCvPercent)
  else measure[#measure+1]='Seed monitor: awaiting planted sample' end
 else measure[#measure+1]='Seed monitor: not fitted' end
 if sample and sample.settingsRevision~=s.revision then measure[#measure+1]='Previous settings - plant another test strip.' end
 self.sampleText:setText('LAST PLANTED SAMPLE (SIMULATED)\n'..table.concat(measure,'\n'))
 local lines={}
 local benefits={rsLogger='Records settings and passes in FieldPath',rsSeedMonitor=s.profile.kind=='planter' and 'Reports skips and doubles' or 'Reports delivery misses and distribution',rsDepthSensor='Reports modeled actual depth',rsMeterDrive='Allows application-rate changes while working'}
 for _,m in ipairs(RSTechnology.modules) do
  local state=s.profile.technologyModules and s.profile.technologyModules[m.name] or (s.profile[m.capability] and 'factory' or 'notFitted')
  local status=({retrofit='AFTERMARKET',factory='FACTORY',notFitted='NOT FITTED'})[state] or 'NOT FITTED'
  if not m.kind or m.kind==s.profile.kind then lines[#lines+1]=m.title..': '..(s.profile.technologyLabels and s.profile.technologyLabels[m.name] or status) end
 end
 for _,warning in ipairs(s.profile.technologyWarnings or {}) do lines[#lines+1]=warning end
 for _,item in ipairs(s.profile.equipment or {}) do lines[#lines+1]=item end
 self.technologyText:setText(table.concat(lines,'\n'))
 local hardware=s.profile.equipment or {}
 self.hardwareText:setText(#hardware>0 and table.concat(hardware,'\n') or 'No additional hardware identified by this equipment profile.')
 self:refreshDetails()
end
function D.number(value)
 return string.format('%.2f',value):gsub('%.?0+$','')
end
function D:loadDraft()
 local s=self.vehicle.spec_rsPlacement;local c=RSPlacement.getCalibration(self.vehicle)
 if not self.message and (c.rateSource=='nominalDefault' or c.seedSizeSource=='nominalDefault') then
  self.message='Rate or seed size uses nominal defaults. Check the seed bag and field conditions before planting.'
 end
 self.initialValues={};self.presetLoaded=false;self.draftRevision=s.revision
 for _,row in ipairs(D.rows) do
  local value=s.settings[row.key]
  if row.key=='ratePerAcre' then value=c.ratePerAcre elseif row.key=='seedsPerPound' then value=c.seedsPerPound end
  self.initialValues[row.key]=value;self[row.id]:setText(D.number(value))
 end
 self.presets={};local current=self.vehicle.spec_sowingMachine
 local fruit=g_fruitTypeManager:getFruitTypeByIndex(current.seeds[current.currentSeed])
 local names={};for name in pairs(RSPlacement.seedCalibrations) do names[#names+1]=name end;table.sort(names)
 self.presetIndex=1
 for _,name in ipairs(names) do
  local crop=g_fruitTypeManager:getFruitTypeByName(name)
  if crop then
   self.presets[#self.presets+1]={name=name,title=crop.title or name}
   if fruit and fruit.name==name then self.presetIndex=#self.presets end
  end
 end
 self:updatePresetLabel()
end
function D:updatePresetLabel()
 local preset=self.presets[self.presetIndex]
 self.presetText:setText(preset and ('Preset: '..preset.title) or 'No crop presets available')
 self.presetNote:setText('Starting values only - verify seed bag and field conditions. A preset never changes the seed loaded in the machine.')
end
function D:onPreviousPreset()
 if #self.presets>0 then self.presetIndex=(self.presetIndex-2)%#self.presets+1;self:updatePresetLabel() end
end
function D:onNextPreset()
 if #self.presets>0 then self.presetIndex=self.presetIndex%#self.presets+1;self:updatePresetLabel() end
end
function D:onLoadPreset()
 local preset=self.presets[self.presetIndex];if not preset then return end
 local rates=RSPlacement.seedCalibrations[preset.name];local depth=RSPlacementModel.crops[preset.name]
 local values={depthMm=depth and (depth[1]+depth[2])/2 or 40,ratePerAcre=self.vehicle.spec_rsPlacement.profile.kind=='planter' and rates[2] or rates[1],
  seedsPerPound=rates[3],pressurePercent=50,closingPercent=50,meterPercent=100}
 for _,row in ipairs(D.rows) do self[row.id]:setText(D.number(values[row.key])) end
 self.presetLoaded=true
 self.message='Loaded '..preset.title..' starting values into the draft. Review, then Apply changes. Loaded seed stays unchanged.'
 self:refresh()
end
function D:onEditStarted(element)
 for _,row in ipairs(D.rows) do if self[row.id]==element then self.message=row.hint;self.statusText:setText(self.message);break end end
end
function D:onFieldDone(element)
 element:setForcePressed(false)
 FocusManager:setFocus(self.applyButton)
end
function D.collectChanges(vehicle,fields,initialValues,presetLoaded,draftRevision)
 local s=vehicle.spec_rsPlacement
 if draftRevision~=s.revision then return nil,'Machine settings changed. Close and reopen setup before editing.' end
 local changes={}
 for _,row in ipairs(D.rows) do
  local value=tonumber(((fields[row.key] or ''):gsub(',','')))
  local lo,hi=unpack(RSPlacementModel.limits[row.key])
  if row.key=='ratePerAcre' then lo=0.01;if s.profile.kind=='drill' then hi=1000 end end
  if row.key=='seedsPerPound' then lo=1 end
  if not RSPlacementModel.finite(value) or value<lo or value>hi then
   return nil,string.format('%s: enter a number from %s to %s.',row.label,lo,hi)
  end
  if presetLoaded or math.abs(value-initialValues[row.key])>0.005 then
   if not RSControlModel.cabAllowed(s.profile,row.key) and (vehicle:getLastSpeed()>0.5 or vehicle:getIsTurnedOn()) then
    return nil,'Stop and switch off before changing '..row.label:lower()..'. Nothing applied.'
   end
   changes[#changes+1]={key=row.key,value=value}
  end
 end
 return changes
end
function D:onApply()
 local fields={}
 for _,row in ipairs(D.rows) do fields[row.key]=self[row.id]:getText();self[row.id]:setForcePressed(false) end
 local changes,message=D.collectChanges(self.vehicle,fields,self.initialValues,self.presetLoaded,self.draftRevision)
 if not changes then self.message=message;self:refresh();return end
 for _,change in ipairs(changes) do
  local ok,reason=self.vehicle:rsSetPlacementSetting(change.key,change.value)
  if not ok then self.message=reason;self:refresh();return end
 end
 self.message=#changes==0 and 'No settings changed.' or (self.vehicle.isServer and 'Settings applied. Save the farm to keep them.' or 'Changes requested from the server.')
 self:loadDraft();self:refresh()
end
function D:refreshDetails()
 local showing=self.detailMode~=nil
 for _,id in ipairs({'technologyText','sampleText','hardwareText'}) do self[id]:setVisible(not showing) end
 self.detailText:setVisible(showing)
 self.detailText:setText(self.detailReport or '')
 self.detailsHeading:setText(self.detailMode=='inspection' and 'LAST PASS INSPECTION (SIMULATED)' or self.detailMode=='equipment' and 'EQUIPMENT / UPGRADE HELP' or 'INSTALLED TECHNOLOGY')
 self.inspectionButton:setText(self.detailMode=='inspection' and 'Back to technology' or 'Inspect last pass')
 self.equipmentButton:setText(self.detailMode=='equipment' and 'Back to technology' or 'Equipment / upgrade help')
end
function D:showInformation(mode,text)
 if self.detailMode==mode then self.detailMode=nil;self.detailReport=nil
 else self.detailMode=mode;self.detailReport=text end
 self:refreshDetails()
end
function D:onClickInspection()
 local report=self.vehicle.spec_rsPlacement.inspection
 self:showInformation('inspection',report and report~='' and report or 'Plant a test strip first, then inspect the placed seed. No sample is available yet.')
end
function D:onClickEquipment()
 self:showInformation('equipment',RSTechnology.describe(self.vehicle.spec_rsPlacement.profile)..'\n\nBuy individual modules using Customize at the workshop or store. Sensors do not automate depth or downforce. Existing row cleaners retain their original machine controls.')
end
