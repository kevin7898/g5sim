-- ProBoxProductSelectionHook.lua
-- Native ProBox integration for RealisticSeeder.
-- Uses the original ProBox store item and its Brands/Products selectors, then maps
-- the selected Products design2 configuration to a crop-specific RealisticSeeder
-- seed fill type after the ProBox is loaded/purchased. No ProBox assets are shipped.

RealisticSeederProBoxProductSelectionHook = RealisticSeederProBoxProductSelectionHook or {}
RealisticSeederProBoxProductSelectionHook.updateIntervalMs = 1000
RealisticSeederProBoxProductSelectionHook.timerMs = 0
RealisticSeederProBoxProductSelectionHook.status = {
    scanned = 0,
    patched = 0,
    skippedUnsupported = 0,
    active = false,
}

-- LAC ProBox Products selector order from design2Configurations in probox_selectable.xml.
-- Unsupported ProBox product labels are intentionally left alone until matching
-- RealisticSeeder fill types exist.
RealisticSeederProBoxProductSelectionHook.design2Map = {
    [1]  = { product = "Alfalfa",     fillType = "SEED_ALFALFA" },
    [2]  = { product = "Barley",      fillType = "SEED_BARLEY" },
    [3]  = { product = "Beans",       fillType = "SEED_SOYBEAN" },
    [4]  = { product = "Canola",      fillType = "SEED_CANOLA" },
    [5]  = { product = "Corn",        fillType = "SEED_MAIZE" },
    [6]  = { product = "Corn Silage", fillType = "SEED_MAIZE" },
    [7]  = { product = "Flax",        fillType = nil },
    [8]  = { product = "Lentil",      fillType = nil },
    [9]  = { product = "Oats",        fillType = "SEED_OAT" },
    [10] = { product = "Peas",        fillType = nil },
    [11] = { product = "Sorghum",     fillType = "SEED_SORGHUM" },
    [12] = { product = "Sunflower",   fillType = "SEED_SUNFLOWER" },
    [13] = { product = "Wheat",       fillType = "SEED_WHEAT" },
}

RealisticSeederProBoxProductSelectionHook.allRealisticSeedFillTypes = {
    "SEED_MAIZE", "SEED_SOYBEAN", "SEED_WHEAT", "SEED_BARLEY", "SEED_OAT",
    "SEED_CANOLA", "SEED_SORGHUM", "SEED_SUNFLOWER", "SEED_COTTON",
    "SEED_POTATO", "SEED_SUGARBEET", "SEED_BEETROOT", "SEED_CARROT",
    "SEED_ONION", "SEED_PARSNIP", "SEED_GRASS", "SEED_ALFALFA",
    "SEED_CLOVER", "SEED_OILSEEDRADISH"
}

local function rsPbHasMod(modName)
    if g_modIsLoaded ~= nil and g_modIsLoaded[modName] ~= nil then
        return g_modIsLoaded[modName] == true
    end
    if g_modManager ~= nil and g_modManager.getModByName ~= nil then
        return g_modManager:getModByName(modName) ~= nil
    end
    return false
end

local function rsPbWriteFile(path, text)
    local file = io.open(path, "w")
    if file ~= nil then
        file:write(text)
        file:close()
        return true
    end
    return false
end

local function rsPbEscapeJson(value)
    value = tostring(value or "")
    value = value:gsub('\\', '\\\\')
    value = value:gsub('"', '\\"')
    return value
end

function RealisticSeederProBoxProductSelectionHook:getVehicles()
    if g_currentMission == nil then
        return nil
    end
    if g_currentMission.vehicles ~= nil then
        return g_currentMission.vehicles
    end
    if g_currentMission.vehicleSystem ~= nil and g_currentMission.vehicleSystem.vehicles ~= nil then
        return g_currentMission.vehicleSystem.vehicles
    end
    return nil
end

function RealisticSeederProBoxProductSelectionHook:getVehiclePath(vehicle)
    return tostring(vehicle.configFileName or vehicle.xmlFilename or "")
end

function RealisticSeederProBoxProductSelectionHook:getIsSupportedOriginalProBox(vehicle)
    if vehicle == nil then
        return false
    end

    local path = self:getVehiclePath(vehicle):lower()
    local typeName = tostring(vehicle.typeName or ""):lower()

    -- Only patch the original LAC ProBox item. Our generated wrapper entries and
    -- other ProBox-style mods are left alone unless explicitly supported later.
    if path:find("fs25_lac_seedproboxpackrealisticpricing", 1, true) ~= nil and path:find("probox_selectable.xml", 1, true) ~= nil then
        return true
    end
    if path:find("fs25_lac_seedproboxpackstandardpricing", 1, true) ~= nil and path:find("probox_selectable.xml", 1, true) ~= nil then
        return true
    end
    if typeName == "fs25_lac_seedproboxpackrealisticpricing.probox" or typeName == "fs25_lac_seedproboxpackstandardpricing.probox" then
        return true
    end

    return false
end

function RealisticSeederProBoxProductSelectionHook:getDesign2Index(vehicle)
    if vehicle == nil or vehicle.configurations == nil then
        return 1
    end
    local value = vehicle.configurations["design2"] or vehicle.configurations.design2 or vehicle.configurations["design2Configuration"]
    value = tonumber(value) or 1
    if value < 1 then
        value = 1
    end
    return value
end

function RealisticSeederProBoxProductSelectionHook:getFillTypeIndex(fillTypeName)
    if fillTypeName == nil or g_fillTypeManager == nil or g_fillTypeManager.getFillTypeByName == nil then
        return nil
    end
    local fillType = g_fillTypeManager:getFillTypeByName(fillTypeName)
    if fillType ~= nil then
        return fillType.index
    end
    return nil
end

function RealisticSeederProBoxProductSelectionHook:addSupportedFillType(vehicle, fillUnitIndex, fillTypeIndex)
    if vehicle == nil or vehicle.spec_fillUnit == nil or vehicle.spec_fillUnit.fillUnits == nil then
        return false
    end
    local fillUnit = vehicle.spec_fillUnit.fillUnits[fillUnitIndex]
    if fillUnit == nil or fillTypeIndex == nil then
        return false
    end

    fillUnit.supportedFillTypes = fillUnit.supportedFillTypes or {}
    fillUnit.supportedFillTypes[fillTypeIndex] = true

    if fillUnit.supportedFillTypeNames ~= nil and g_fillTypeManager ~= nil and g_fillTypeManager.getFillTypeByIndex ~= nil then
        local fillType = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
        if fillType ~= nil and fillType.name ~= nil then
            fillUnit.supportedFillTypeNames[fillType.name] = true
        end
    end

    return true
end

function RealisticSeederProBoxProductSelectionHook:addAllSupportedSeedFillTypes(vehicle, fillUnitIndex)
    for _, fillTypeName in ipairs(self.allRealisticSeedFillTypes) do
        local fillTypeIndex = self:getFillTypeIndex(fillTypeName)
        if fillTypeIndex ~= nil then
            self:addSupportedFillType(vehicle, fillUnitIndex, fillTypeIndex)
        end
    end
end

function RealisticSeederProBoxProductSelectionHook:getCurrentFillTypeName(vehicle, fillUnitIndex)
    if vehicle == nil or vehicle.getFillUnitFillType == nil or g_fillTypeManager == nil or g_fillTypeManager.getFillTypeByIndex == nil then
        return nil
    end
    local ok, fillTypeIndex = pcall(vehicle.getFillUnitFillType, vehicle, fillUnitIndex)
    if not ok then
        return nil
    end
    local fillType = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
    if fillType ~= nil then
        return fillType.name
    end
    return nil
end

function RealisticSeederProBoxProductSelectionHook:setFillType(vehicle, fillUnitIndex, fillTypeIndex)
    if vehicle == nil or vehicle.spec_fillUnit == nil or vehicle.spec_fillUnit.fillUnits == nil then
        return false
    end
    local fillUnit = vehicle.spec_fillUnit.fillUnits[fillUnitIndex]
    if fillUnit == nil or fillTypeIndex == nil then
        return false
    end

    self:addSupportedFillType(vehicle, fillUnitIndex, fillTypeIndex)

    -- Keep the current liters; only change what product those liters represent.
    -- This is intentionally direct and defensive because the base ProBox starts
    -- full at purchase time and FS25 may reject a normal add/remove transaction
    -- if the old base-game SEEDS type is not compatible with the new seed type.
    fillUnit.fillType = fillTypeIndex
    fillUnit.fillTypeToDisplay = fillTypeIndex

    if vehicle.setFillUnitForcedMaterialFillType ~= nil then
        pcall(vehicle.setFillUnitForcedMaterialFillType, vehicle, fillUnitIndex, fillTypeIndex)
    end
    if vehicle.setFillUnitFillTypeToDisplay ~= nil then
        pcall(vehicle.setFillUnitFillTypeToDisplay, vehicle, fillUnitIndex, fillTypeIndex, true)
    end
    if vehicle.raiseDirtyFlags ~= nil and vehicle.spec_fillUnit.dirtyFlag ~= nil then
        pcall(vehicle.raiseDirtyFlags, vehicle, vehicle.spec_fillUnit.dirtyFlag)
    end

    return true
end

function RealisticSeederProBoxProductSelectionHook:patchVehicle(vehicle)
    if not self:getIsSupportedOriginalProBox(vehicle) then
        return false
    end

    self.status.scanned = self.status.scanned + 1

    local design2Index = self:getDesign2Index(vehicle)
    local mapping = self.design2Map[design2Index]
    if mapping == nil then
        return false
    end

    -- Always let the original ProBox accept realistic seed fill types when refilled.
    self:addAllSupportedSeedFillTypes(vehicle, 1)

    if mapping.fillType == nil then
        if vehicle.rsProBoxUnsupportedProductLogged ~= design2Index then
            print(string.format("[RealisticSeeder] ProBox Products selector '%s' has no RealisticSeeder fill type yet; leaving base fill type unchanged", tostring(mapping.product)))
            vehicle.rsProBoxUnsupportedProductLogged = design2Index
            self.status.skippedUnsupported = self.status.skippedUnsupported + 1
        end
        return false
    end

    local fillTypeIndex = self:getFillTypeIndex(mapping.fillType)
    if fillTypeIndex == nil then
        if vehicle.rsProBoxMissingFillTypeLogged ~= mapping.fillType then
            print(string.format("[RealisticSeeder] ProBox Products selector wanted missing fill type %s", tostring(mapping.fillType)))
            vehicle.rsProBoxMissingFillTypeLogged = mapping.fillType
        end
        return false
    end

    local currentName = self:getCurrentFillTypeName(vehicle, 1)
    if currentName == "FERTILIZER" then
        return false
    end

    local signature = tostring(design2Index) .. ":" .. tostring(fillTypeIndex)
    if vehicle.rsProBoxProductHookSignature == signature then
        return false
    end

    if self:setFillType(vehicle, 1, fillTypeIndex) then
        vehicle.rsProBoxProductHookSignature = signature
        self.status.patched = self.status.patched + 1
        print(string.format("[RealisticSeeder] ProBox Products selector mapped '%s' to %s while keeping original ProBox textures", tostring(mapping.product), tostring(mapping.fillType)))
        return true
    end

    return false
end

function RealisticSeederProBoxProductSelectionHook:scanVehicles()
    local vehicles = self:getVehicles()
    if vehicles == nil then
        return
    end
    for _, vehicle in pairs(vehicles) do
        self:patchVehicle(vehicle)
    end
end

function RealisticSeederProBoxProductSelectionHook:loadMap()
    local realisticInstalled = rsPbHasMod("FS25_LAC_SeedProBoxPackRealisticPricing")
    local standardInstalled = rsPbHasMod("FS25_LAC_SeedProBoxPackStandardPricing")
    self.status.active = realisticInstalled or standardInstalled

    if self.status.active then
        print("[RealisticSeeder] ProBox native Products selector hook active: original ProBox item will map Products to crop-specific seed fill types")
    end

    if getUserProfileAppPath ~= nil and createFolder ~= nil then
        local dir = getUserProfileAppPath() .. "modSettings/FS25_FieldPathCommand"
        createFolder(dir)
        rsPbWriteFile(dir .. "/realisticSeederProBoxNativeSelector.json", string.format(
            '{"schema":1,"active":%s,"realisticOriginal":%s,"standardOriginal":%s,"mode":"nativeProductSelectorHook","keepsProBoxTextures":true,"redistributesProBoxAssets":false}',
            tostring(self.status.active), tostring(realisticInstalled), tostring(standardInstalled)))
    end
end

function RealisticSeederProBoxProductSelectionHook:update(dt)
    if not self.status.active then
        return
    end
    self.timerMs = (self.timerMs or 0) + (dt or 0)
    if self.timerMs >= self.updateIntervalMs then
        self.timerMs = 0
        self:scanVehicles()
    end
end

addModEventListener(RealisticSeederProBoxProductSelectionHook)
