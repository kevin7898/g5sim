-- FS25_FarmFinance - loan arithmetic (pure Lua 5.1).
-- Rates are yearly fractions; payments are monthly.

FarmFinance = FarmFinance or {}
local FF = FarmFinance

FF.LoanMath = {}
local M = FF.LoanMath

local EPSILON = 1e-9

-- Monthly annuity payment for principal over n months at a yearly rate.
function M.payment(principal, annualRate, months)
    if principal <= 0 or months <= 0 then
        return 0
    end
    local r = (annualRate or 0) / 12
    if math.abs(r) < EPSILON then
        return principal / months
    end
    return principal * r / (1 - (1 + r) ^ (-months))
end

-- Largest principal a monthly payment can carry over n months.
function M.principalForPayment(monthlyPayment, annualRate, months)
    if monthlyPayment <= 0 or months <= 0 then
        return 0
    end
    local r = (annualRate or 0) / 12
    if math.abs(r) < EPSILON then
        return monthlyPayment * months
    end
    return monthlyPayment * (1 - (1 + r) ^ (-months)) / r
end

-- Present value of a single amount due in n months.
function M.presentValue(amount, annualRate, months)
    local r = (annualRate or 0) / 12
    if months <= 0 or math.abs(r) < EPSILON then
        return amount
    end
    return amount / (1 + r) ^ months
end

-- One month of an annuity loan. Returns interest, principal, newBalance.
-- On the last month (or if the payment would overshoot) the remaining
-- balance is cleared exactly.
function M.step(balance, annualRate, payment, monthsLeft)
    if balance <= 0 then
        return 0, 0, 0
    end
    local interest = balance * (annualRate or 0) / 12
    local principal = payment - interest
    if monthsLeft ~= nil and monthsLeft <= 1 then
        principal = balance
    end
    if principal > balance then
        principal = balance
    end
    if principal < 0 then
        principal = 0
    end
    local newBalance = balance - principal
    if newBalance < 0.005 then
        newBalance = 0
    end
    return interest, principal, newBalance
end

-- Payments due in the next 12 months for an annuity (principal + interest).
function M.nextTwelveMonths(balance, annualRate, payment, monthsLeft)
    local total = 0
    local principalTotal = 0
    local current = balance
    local left = monthsLeft
    for _ = 1, math.min(12, math.max(left or 12, 0)) do
        if current <= 0 then
            break
        end
        local interest, principal, newBalance = M.step(current, annualRate, payment, left)
        total = total + interest + principal
        principalTotal = principalTotal + principal
        current = newBalance
        left = (left or 12) - 1
    end
    return total, principalTotal
end

return M
