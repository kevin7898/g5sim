local WV = WheatVarieties
local Terrain = {}
WV.Terrain = Terrain

local function findFoliageSystem(xml, key)
    if hasXMLProperty(xml, key .. ".Layers.FoliageSystem") then
        return key .. ".Layers.FoliageSystem"
    end
    for index = 0, getXMLNumOfChildren(xml, key) - 1 do
        local child = key .. ".*(" .. index .. ")"
        local name = getXMLElementName(xml, child)
        if name == "TransformGroup" or name == "TerrainTransformGroup" then
            local found = findFoliageSystem(xml, child)
            if found then return found end
        end
    end
end

function Terrain.requiredChannels(typeBits, totalBits, typeCount)
    assert(typeBits > 0 and totalBits > typeBits, "Unsupported foliage channel layout")
    local requiredBits = typeBits
    while typeCount > 2 ^ requiredBits - 1 do requiredBits = requiredBits + 1 end
    local requiredTotal = totalBits + requiredBits - typeBits
    assert(requiredTotal <= 16, "Expanded foliage exceeds the engine's 16-channel limit")
    return requiredBits, requiredTotal
end

local function prepareMap(xml, filename)
    local wheat = assert(g_fruitTypeManager:getFruitTypeByName("WHEAT"), "Wheat is unavailable")
    local system = assert(findFoliageSystem(xml, "i3D.Scene"), "Map has no foliage system")
    local target, count
    local layerIndex = 0
    while hasXMLProperty(xml, system .. ".FoliageMultiLayer(" .. layerIndex .. ")") do
        local layer = system .. ".FoliageMultiLayer(" .. layerIndex .. ")"
        local typeIndex, containsWheat = 0, false
        while hasXMLProperty(xml, layer .. ".FoliageType(" .. typeIndex .. ")") do
            local name = getXMLString(xml, layer .. ".FoliageType(" .. typeIndex .. ")#name")
            if name and name:upper() == wheat.layerName:upper() then containsWheat = true end
            typeIndex = typeIndex + 1
        end
        if containsWheat then
            assert(target == nil, "Wheat appears in multiple foliage layers")
            target, count = layer, typeIndex
        end
        layerIndex = layerIndex + 1
    end
    assert(target, "Cannot locate the map's wheat foliage layer")
    local oldBits = assert(getXMLInt(xml, target .. "#numTypeIndexChannels"), "Missing foliage type channels")
    local oldTotal = assert(getXMLInt(xml, target .. "#numChannels"), "Missing foliage channels")
    local newBits, newTotal = Terrain.requiredChannels(oldBits, oldTotal, count + #WV.definitions)
    local densityId = getXMLInt(xml, target .. "#densityMapId")
    local baseDirectory = filename:match("^(.*[/\\])") or ""
    local fileIndex, maxId, densityFilename = 0, 0, nil
    while hasXMLProperty(xml, "i3D.Files.File(" .. fileIndex .. ")") do
        local key = "i3D.Files.File(" .. fileIndex .. ")"
        local id = assert(getXMLInt(xml, key .. "#fileId"), "Missing I3D file ID")
        local path = assert(getXMLString(xml, key .. "#filename"), "Missing I3D file path")
        maxId = math.max(maxId, id)
        -- Keep I3D's $data/$dataS aliases. Utils.getFilename strips their '$',
        -- which makes the native I3D loader resolve them below the cache.
        if path:sub(1, 1) ~= "$" then path = Utils.getFilename(path, baseDirectory) end
        setXMLString(xml, key .. "#filename", path)
        if id == densityId then densityFilename = path end
        fileIndex = fileIndex + 1
    end
    assert(densityFilename, "Missing crop density-map file")
    if newBits ~= oldBits then
        local gdm = densityFilename:gsub("%.[^./\\]+$", ".gdm")
        assert(fileExists(gdm), "Capacity expansion requires a GDM source with type-channel metadata: " .. gdm)
    end
    local shapes = getXMLString(xml, "i3D.Shapes#externalShapesFile")
    if shapes then
        -- The native shapes loader cannot resolve an externalShapesFile inside
        -- another ZIP when the I3D itself is loaded from the profile cache.
        local cachedShapes = WV.cacheDirectory .. "map.i3d.shapes"
        assert(type(copyFile) == "function", "This engine cannot cache map geometry")
        copyFile(Utils.getFilename(shapes, baseDirectory), cachedShapes, true)
        assert(fileExists(cachedShapes), "Cannot cache map geometry")
        setXMLString(xml, "i3D.Shapes#externalShapesFile", "map.i3d.shapes")
    end
    setXMLInt(xml, target .. "#numTypeIndexChannels", newBits)
    setXMLInt(xml, target .. "#numChannels", newTotal)
    -- Compression partitions do not change the meaning of crop/state bits.
    -- Retain the map's own compression configuration during native conversion.
    for index, def in ipairs(WV.definitions) do
        local id = maxId + index
        local key = "i3D.Files.File(" .. (fileIndex + index - 1) .. ")"
        setXMLInt(xml, key .. "#fileId", id)
        setXMLString(xml, key .. "#filename", def.foliageFilename)
        key = target .. ".FoliageType(" .. (count + index - 1) .. ")"
        setXMLString(xml, key .. "#name", def.layerName)
        setXMLInt(xml, key .. "#foliageXmlId", id)
    end
    local adapted = WV.cacheDirectory .. "map.i3d"
    assert(saveXMLFileTo(xml, adapted), "Cannot write adapted map I3D")
    WV.state.originalMap = filename
    WV.state.adaptedMap = adapted
    WV.state.terrainAdapted = true
    WV.log("Adapted foliage capacity %d -> %d slots; %d existing types plus %d varieties. Native GDM conversion %d -> %d type channels.",
        2 ^ oldBits - 1, 2 ^ newBits - 1, count, #WV.definitions, oldBits, newBits)
    return adapted
end

function Terrain.isOwnFoliage(name)
    for _, def in ipairs(WV.definitions) do
        if type(name) == "string" and name:upper() == def.layerName:upper() then return true end
    end
    return false
end

function Terrain.prepare(filename)
    assert(WV.state.fruitsLoaded, "Fruit registration must precede terrain loading")
    assert(type(saveXMLFileTo) == "function", "This engine cannot write an adapted map definition")
    local xml = loadXMLFile("wvMap", filename)
    assert(xml and xml ~= 0, "Cannot read map I3D: " .. filename)
    local ok, result = pcall(prepareMap, xml, filename)
    delete(xml)
    assert(ok, result)
    return result
end

function Terrain.filterSavedFoliage(system)
    if not WV.state.terrainAdapted then return end
    local own = {}
    for _, def in ipairs(WV.definitions) do own[def.layerName:upper()] = true end
    local entries = system.modFoliageTypesToLoad or {}
    for index = #entries, 1, -1 do
        if own[(entries[index].name or ""):upper()] then table.remove(entries, index) end
    end
end
