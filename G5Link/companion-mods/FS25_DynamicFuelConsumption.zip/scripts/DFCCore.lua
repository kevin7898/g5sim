-- =============================================================
-- Dynamic Fuel Consumption — DFCCore.lua
-- Settings, save/load, mission lifecycle. Same proven persistence
-- pattern as most ModHub settings mods: hook
-- FSCareerMissionInfo.saveToXMLFile / Mission00.loadMission00Finished
-- so config travels with the savegame.
-- =============================================================

if DynamicFuelConsumption ~= nil then
    return
end

DynamicFuelConsumption = {}
DynamicFuelConsumption.MOD_NAME = g_currentModName
DynamicFuelConsumption.MOD_DIR  = g_currentModDirectory
DynamicFuelConsumption.VERSION  = "1.0.0.0"

-- =============================================================
-- CONSTANTS
-- =============================================================

-- Realism multiplier applied on TOP of the physics model output.
-- 1.0x = trust the BSFC/idle model as computed. Exists because no
-- generic BSFC curve will be exactly right for every modded engine;
-- this is the escape hatch, not the primary tuning knob.
DynamicFuelConsumption.REALISM_MULT_VALUES  = { 0.70, 0.85, 1.00, 1.15, 1.30, 1.50 }
DynamicFuelConsumption.REALISM_MULT_DEFAULT = 3   -- index -> 1.00x

-- Idle burn level, maps to DFCEngineModel.IDLE_LPERH_PER_100HP keys
DynamicFuelConsumption.IDLE_LEVEL_KEYS    = { "LOW", "MEDIUM", "HIGH" }
DynamicFuelConsumption.IDLE_LEVEL_DEFAULT = 2   -- MEDIUM

DynamicFuelConsumption.SAVE_FILE = "FS25_DynamicFuelConsumption.xml"

-- =============================================================
-- SETTINGS
-- =============================================================
local s = {
    realismMultIdx = DynamicFuelConsumption.REALISM_MULT_DEFAULT,
    idleLevelIdx   = DynamicFuelConsumption.IDLE_LEVEL_DEFAULT,
    notifications  = true,
}
DynamicFuelConsumption.settings = s

function DynamicFuelConsumption.getRealismMultiplier()
    return DynamicFuelConsumption.REALISM_MULT_VALUES[s.realismMultIdx] or 1.0
end

function DynamicFuelConsumption.getIdleLevelKey()
    return DynamicFuelConsumption.IDLE_LEVEL_KEYS[s.idleLevelIdx] or "MEDIUM"
end

-- =============================================================
-- SAVE / LOAD
-- =============================================================
local function getSettingsPath()
    if g_currentMission and g_currentMission.missionInfo then
        local dir = g_currentMission.missionInfo.savegameDirectory
        if dir ~= nil then
            return dir .. "/" .. DynamicFuelConsumption.SAVE_FILE
        end
    end
    return nil
end

function DynamicFuelConsumption.saveSettings()
    local path = getSettingsPath()
    if path == nil then return end

    local xml = createXMLFile("dfcSettings", path, "dfc")
    if xml == nil or xml == 0 then return end

    setXMLInt (xml, "dfc#realismMultIdx", s.realismMultIdx)
    setXMLInt (xml, "dfc#idleLevelIdx",   s.idleLevelIdx)
    setXMLBool(xml, "dfc#notifications",  s.notifications)

    saveXMLFile(xml)
    delete(xml)
end

function DynamicFuelConsumption.loadSettings()
    local path = getSettingsPath()
    if path == nil or not fileExists(path) then return end

    local xml = loadXMLFile("dfcSettings", path)
    if xml == nil or xml == 0 then return end

    local function getInt(key, default)
        return Utils.getNoNil(getXMLInt(xml, key), default)
    end
    local function getBool(key, default)
        return Utils.getNoNil(getXMLBool(xml, key), default)
    end

    s.realismMultIdx = getInt ("dfc#realismMultIdx", s.realismMultIdx)
    s.idleLevelIdx   = getInt ("dfc#idleLevelIdx",   s.idleLevelIdx)
    s.notifications  = getBool("dfc#notifications",  s.notifications)

    if s.realismMultIdx < 1 or s.realismMultIdx > #DynamicFuelConsumption.REALISM_MULT_VALUES then
        s.realismMultIdx = DynamicFuelConsumption.REALISM_MULT_DEFAULT
    end
    if s.idleLevelIdx < 1 or s.idleLevelIdx > #DynamicFuelConsumption.IDLE_LEVEL_KEYS then
        s.idleLevelIdx = DynamicFuelConsumption.IDLE_LEVEL_DEFAULT
    end

    delete(xml)
end

-- =============================================================
-- MISSION LIFECYCLE
-- =============================================================
local notificationShown = false
local notificationTimer = -1

local function onLoadFinished(mission, node)
    DynamicFuelConsumption.loadSettings()

    if s.notifications and not notificationShown then
        notificationTimer = 3000
    end

    if DynamicFuelConsumptionSettingsUI ~= nil and DynamicFuelConsumptionSettingsUI.onSettingsLoaded ~= nil then
        DynamicFuelConsumptionSettingsUI.onSettingsLoaded()
    end
end

local function showDFCNotification()
    if g_currentMission == nil then return end
    local msg = g_i18n:getText("dfc_msg_enabled")

    if g_currentMission.addIngameNotification ~= nil
       and FSBaseMission ~= nil
       and FSBaseMission.INGAME_NOTIFICATION_OK ~= nil then
        g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, msg)
    elseif g_currentMission.showBlinkingWarning ~= nil then
        g_currentMission:showBlinkingWarning(msg, 4000)
    end
end

FSBaseMission.update = Utils.appendedFunction(FSBaseMission.update, function(self, dt)
    if notificationTimer > 0 then
        notificationTimer = notificationTimer - dt
        if notificationTimer <= 0 then
            notificationTimer = -1
            if not notificationShown then
                notificationShown = true
                showDFCNotification()
            end
        end
    end
end)

Mission00.loadMission00Finished = Utils.appendedFunction(
    Mission00.loadMission00Finished,
    function(self, node)
        onLoadFinished(self, node)
    end
)

FSCareerMissionInfo.saveToXMLFile = Utils.appendedFunction(
    FSCareerMissionInfo.saveToXMLFile,
    function(self)
        DynamicFuelConsumption.saveSettings()
    end
)
