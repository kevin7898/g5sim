--[[
    In-game settings section for FS25_HydraulicAutosteerWheel.

    Adds a "Hydraulic Autosteer Wheel" section to the "Additional Settings" tab that the
    FS25_additionalGameSettings mod (by Rockstar) adds to Menu > Settings. Without that mod
    the section goes to Menu > Settings > General instead.

    Rows are cloned from the game's own option rows (the approach most FS25 script mods use).
    Changes apply immediately and are saved to modSettings/FS25_HydraulicAutosteerWheel.xml.
]]

HydraulicWheelSettingsUI = {}
HydraulicWheelSettingsUI.CONTROLS = {}
HydraulicWheelSettingsUI.injected = false

local function onOff()
    return { g_i18n:getText("ui_on"), g_i18n:getText("ui_off") }
end

local function degTexts(values)
    local t = {}
    for i, v in ipairs(values) do t[i] = string.format("%d°", v) end
    return t
end

-- Order here is the order in the menu.
HydraulicWheelSettingsUI.ITEMS = {
    {
        key = "autosteerStyle",
        title = "Autosteer style",
        toolTip = "Hydraulic: factory autosteer, the wheel stays still while it steers. Electric: aftermarket motor on the wheel, the wheel turns with every correction.",
        values = { "hydraulic", "electric" },
        texts = { "Hydraulic", "Electric" },
    },
    {
        key = "steeringRangeDeg",
        title = "Steering range (lock to lock)",
        toolTip = "How far the wheel turns from full left to full right lock on the tractor.",
        values = { 540, 720, 900, 1080, 1260, 1440, 1800 },
    },
    {
        key = "hardwareLockDeg",
        title = "Wheel base rotation",
        toolTip = "Rotation the companion app sets on the wheel base. Leave at 2520° on a direct drive base so the centre has the most room to move.",
        values = { 1080, 1440, 1800, 2160, 2520 },
    },
    {
        key = "disengageDeg",
        title = "Hydraulic: disengage after",
        toolTip = "How far you turn the wheel before hydraulic autosteer hands control back to you.",
        values = { 4, 6, 8, 10, 15, 20 },
    },
    {
        key = "electricOverrideDeg",
        title = "Electric: override after",
        toolTip = "How far you can hold the wheel against the electric motor before it disengages.",
        values = { 10, 15, 20, 30, 45 },
    },
    {
        key = "slipAtWalls",
        title = "Slip at the steering stops",
        toolTip = "Push past a steering stop and it slowly gives way, like a real orbitrol valve. Lets you unwind the wheel by hand.",
        values = { true, false },
        texts = "onOff",
    },
    {
        key = "reindexWhileEngaged",
        title = "Re-centre wheel during autosteer",
        toolTip = "Hydraulic style: if the centre has drifted far, the motor quietly turns the wheel back toward true centre while autosteer drives.",
        values = { true, false },
        texts = "onOff",
    },
    {
        key = "reindexKeepDeg",
        title = "Re-centre when drift exceeds",
        toolTip = "Below this the wheel never moves on its own.",
        values = { 180, 360, 540, 720 },
    },
    {
        key = "hydraulicFeel",
        title = "No self-centering",
        toolTip = "Mute the game's self-centering force. Real hydraulic steering does not return the wheel to centre.",
        values = { true, false },
        texts = "onOff",
    },
    {
        key = "invertVehicleSteer",
        title = "Invert tractor steering at takeover",
        toolTip = "Turn on if the tractor's wheels flip the wrong way when you take over from autosteer.",
        values = { true, false },
        texts = "onOff",
    },
    {
        key = "wallMode",
        title = "Steering stops",
        toolTip = "Companion: stops drawn by the FanatecWalls app (recommended). Game: experimental, uses the game's force feedback. Off: no moving stops.",
        values = { "companion", "game", "off" },
        texts = { "Companion app", "Game FFB", "Off" },
    },
}

local function getTexts(item)
    if item.texts == "onOff" then return onOff() end
    if item.texts ~= nil then return item.texts end
    return degTexts(item.values)
end

local function getStateIndex(item)
    local current = HydraulicWheel.cfg[item.key]
    if type(current) == "number" then
        local best, bestDiff = 1, math.huge
        for i, v in ipairs(item.values) do
            local d = math.abs(v - current)
            if d < bestDiff then best, bestDiff = i, d end
        end
        return best
    end
    for i, v in ipairs(item.values) do
        if v == current then return i end
    end
    return 1
end

-- Callback target for the cloned controls
HydraulicWheelSettingsControls = {}

function HydraulicWheelSettingsControls.onMenuOptionChanged(self, state, menuOption)
    local item = HydraulicWheelSettingsUI.byId[menuOption.id]
    if item == nil then return end
    local value = item.values[state]
    if value ~= nil then
        HydraulicWheel:setSetting(item.key, value)
    end
end

local function updateFocusIds(element)
    if element == nil then return end
    element.focusId = FocusManager:serveAutoFocusId()
    for _, child in pairs(element.elements) do
        updateFocusIds(child)
    end
end

function HydraulicWheelSettingsUI.inject()
    if HydraulicWheelSettingsUI.injected then return end

    local inGameMenu = g_gui.screenControllers[InGameMenu]
    local page = inGameMenu ~= nil and inGameMenu.pageSettings or nil
    if page == nil or page.gameSettingsLayout == nil then
        error("settings page not found")
    end
    -- Prefer the Additional Settings tab (FS25_additionalGameSettings exposes its list here)
    local layout = page.additionalSettingsLayout
    local inAdditional = layout ~= nil
    if not inAdditional then
        layout = page.gameSettingsLayout
    end
    HydraulicWheelSettingsUI.layout = layout
    HydraulicWheelSettingsUI.inAdditional = inAdditional
    local binaryTemplate = page.checkWoodHarvesterAutoCutBox
    local multiTemplate = page.multiVolumeVoiceBox
    if binaryTemplate == nil or multiTemplate == nil then
        error("template controls not found")
    end

    -- The focus manager ignores controls whose callback target belongs to another screen
    HydraulicWheelSettingsControls.name = page.name
    HydraulicWheelSettingsUI.byId = {}

    -- Section header
    local header = nil
    for _, elem in ipairs(layout.elements) do
        if elem.name == "sectionHeader" then
            header = elem:clone(layout)
            break
        end
    end
    if header == nil then
        header = TextElement.new()
        header:applyProfile("fs25_settingsSectionHeader", true)
        header.name = "sectionHeader"
        layout:addElement(header)
    end
    header:setText("Hydraulic Autosteer Wheel")
    header.focusId = FocusManager:serveAutoFocusId()
    if not inAdditional then
        -- the General page tracks its rows in controlsList; the Additional tab manages its own
        table.insert(page.controlsList, header)
    end
    HydraulicWheelSettingsUI.CONTROLS.__header = header

    for _, item in ipairs(HydraulicWheelSettingsUI.ITEMS) do
        local template = (#item.values == 2) and binaryTemplate or multiTemplate
        local box = template:clone(layout)
        local id = "hawSetting_" .. item.key
        box.id = id .. "Box"

        local option = box.elements[1]
        option.id = id
        option.target = HydraulicWheelSettingsControls
        option:setCallback("onClickCallback", "onMenuOptionChanged")
        option:setDisabled(false)

        local toolTip = option.elements[1]
        if toolTip ~= nil and toolTip.setText ~= nil then toolTip:setText(item.toolTip) end
        local label = box.elements[2]
        if label ~= nil and label.setText ~= nil then label:setText(item.title) end

        option:setTexts(getTexts(item))
        option:setState(getStateIndex(item))

        updateFocusIds(box)
        -- same as the game's own pattern: binary rows register the box, multi rows the option
        if not inAdditional then
            table.insert(page.controlsList, (#item.values == 2) and box or option)
        end
        HydraulicWheelSettingsUI.byId[id] = item
        HydraulicWheelSettingsUI.CONTROLS[item.key] = option
    end

    layout:invalidateLayout()

    -- Refresh shown values each time the page opens (the XML or console may have changed them)
    InGameMenuSettingsFrame.onFrameOpen = Utils.appendedFunction(InGameMenuSettingsFrame.onFrameOpen, function()
        for _, item in ipairs(HydraulicWheelSettingsUI.ITEMS) do
            local option = HydraulicWheelSettingsUI.CONTROLS[item.key]
            if option ~= nil then
                option:setState(getStateIndex(item))
            end
        end
    end)

    HydraulicWheelSettingsUI.injected = true
    if inAdditional then
        print("[HydraulicWheel] Settings section added to Menu > Settings > Additional Settings")
    else
        print("[HydraulicWheel] Additional Game Settings mod not found; settings section added to Menu > Settings > General")
    end
end

-- Keyboard / controller navigation for the added rows
FocusManager.setGui = Utils.appendedFunction(FocusManager.setGui, function(_, gui)
    if gui ~= "ingameMenuSettings" or not HydraulicWheelSettingsUI.injected then return end
    for _, control in pairs(HydraulicWheelSettingsUI.CONTROLS) do
        if not control.focusId or not FocusManager.currentFocusData.idToElementMapping[control.focusId] then
            FocusManager:loadElementFromCustomValues(control, nil, nil, false, false)
        end
    end
    if HydraulicWheelSettingsUI.layout ~= nil then
        HydraulicWheelSettingsUI.layout:invalidateLayout()
    end
end)
