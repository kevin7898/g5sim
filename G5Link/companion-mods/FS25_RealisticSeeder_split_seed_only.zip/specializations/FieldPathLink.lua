-- ===========================================================================
-- FieldPathLink.lua
-- Shared FieldPath 2 client shim for the agronomy module suite. An identical
-- copy of this file ships inside each module mod; a version guard ensures the
-- newest copy wins regardless of mod load order, and the rest become no-ops.
--
-- The whole point of this file is that agronomy modules NEVER write FieldPath
-- files themselves and NEVER touch FP2 internals. They do exactly this:
--
--   local link = FieldPathLink.connect({ module = "...", version = "...", ... })
--   link:emit("chem.application", record)   -- anytime; safe in any mode
--   link:publish("catalog.json", jsonText)  -- catalogs for the bridge
--   link:update(dt)                         -- pump from the mod's update()
--
-- Three modes, resolved automatically and re-checked on every pump:
--   "registered" : FS25_FieldPath2 with the module registry is installed.
--                  Events ride FP2's event log (and therefore inherit the
--                  savegame-checkpoint commit/rollback semantics); catalogs
--                  are published; the bridge sees the module in modules.json.
--   "degraded"   : an older FS25_FieldPath2 without FP2.registerModule.
--                  Events still go through FP2.emit with module identity
--                  injected; no manifest/catalog publication.
--   "standalone" : no FieldPath at all. The module keeps working; emits are
--                  held in a small ring buffer (so a late-loading FieldPath
--                  still catches recent records) and otherwise dropped.
--                  This is what keeps every module independently loadable.
-- ===========================================================================

local LINK_VERSION = 1

if FieldPathLink == nil or (FieldPathLink._LINK_VERSION or 0) < LINK_VERSION then

    FieldPathLink = { _LINK_VERSION = LINK_VERSION }

    local QUEUE_MAX = 64

    local Link = {}
    Link.__index = Link

    local function tryConnect(self)
        if self.handle ~= nil then return true end
        if FP2 ~= nil and FP2.registerModule ~= nil then
            local ok, handle = pcall(FP2.registerModule, self.manifest)
            if ok and handle ~= nil then
                self.handle = handle
                self.mode = "registered"
                -- replay everything that happened before FieldPath was ready
                for i = 1, #self.queue do
                    local q = self.queue[i]
                    pcall(handle.emit, handle, q.event, q.payload)
                end
                self.queue = {}
                for i = 1, #self.files do
                    local f = self.files[i]
                    pcall(handle.publishFile, handle, f.name, f.text)
                end
                self.files = {}
                print(string.format("[%s] FieldPath 2 link established (registered)",
                    tostring(self.manifest.module)))
                return true
            end
        end
        if FP2 ~= nil and FP2.emit ~= nil then
            if self.mode ~= "degraded" then
                self.mode = "degraded"
                print(string.format("[%s] FieldPath 2 found without module registry - degraded link",
                    tostring(self.manifest.module)))
            end
            return true
        end
        self.mode = "standalone"
        return false
    end

    function Link:emit(event, payload)
        event = tostring(event or "")
        if event == "" then return false end
        tryConnect(self)
        if self.handle ~= nil then
            local ok, sent = pcall(self.handle.emit, self.handle, event, payload)
            return ok and sent == true
        end
        if self.mode == "degraded" and FP2 ~= nil and FP2.emit ~= nil then
            local args = {}
            if type(payload) == "table" then
                for k, v in pairs(payload) do args[k] = v end
            end
            args.module        = tostring(self.manifest.module)
            args.moduleVersion = tostring(self.manifest.version or "0.0.0.0")
            local ok, sent = pcall(FP2.emit, event, args)
            if ok and sent == true then return true end
        end
        -- standalone (or FieldPath not ready): keep a bounded ring buffer
        if #self.queue >= QUEUE_MAX then
            table.remove(self.queue, 1)
            self.dropped = (self.dropped or 0) + 1
        end
        self.queue[#self.queue + 1] = { event = event, payload = payload }
        return false
    end

    function Link:publish(fileName, text)
        tryConnect(self)
        if self.handle ~= nil and self.handle.publishFile ~= nil then
            local ok = pcall(self.handle.publishFile, self.handle, fileName, text)
            return ok
        end
        -- hold for a later connect; catalogs are few and small
        for i = 1, #self.files do
            if self.files[i].name == fileName then
                self.files[i].text = text
                return false
            end
        end
        self.files[#self.files + 1] = { name = fileName, text = text }
        return false
    end

    function Link:isConnected()
        return self.handle ~= nil or self.mode == "degraded"
    end

    function Link:getMode()
        return self.mode
    end

    -- Cheap retry pump; call from the owning mod's update(dt).
    function Link:update(dt)
        if self.handle ~= nil then return end
        self.retryMs = (self.retryMs or 0) + (dt or 0)
        if self.retryMs >= 5000 then
            self.retryMs = 0
            tryConnect(self)
        end
    end

    function FieldPathLink.connect(manifest)
        if type(manifest) ~= "table" or manifest.module == nil then
            print("[FieldPathLink] connect rejected: manifest must be a table with a 'module' field")
            manifest = { module = "unknown", version = "0.0.0.0" }
        end
        local link = setmetatable({
            manifest = manifest,
            handle   = nil,
            mode     = "standalone",
            queue    = {},
            files    = {},
            retryMs  = 0,
        }, Link)
        tryConnect(link)
        return link
    end

end
