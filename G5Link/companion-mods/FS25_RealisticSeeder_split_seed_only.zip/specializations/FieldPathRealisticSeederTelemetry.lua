-- FieldPathRealisticSeederTelemetry.lua
-- FieldPath bridge for RealisticSeeder. It does not alter base-game seed fill
-- types; it only reports the detected crop-specific seed product.
--
-- v2: FieldPath 2 is the primary target. Through FieldPathLink the module
-- registers itself with FP2's module registry, publishes the Phase 3 seed
-- catalogs into modSettings/FS25_FieldPath2/modules/RealisticSeeder/, and
-- emits "seed.seederState" events that ride FP2's event log -- inheriting the
-- savegame-checkpoint commit/rollback semantics, so seeder records always
-- match the world FS25 actually recovered.
--
-- Without FieldPath 2 installed, behaviour falls back to the original v1
-- single-state-file write into modSettings/FS25_FieldPathCommand, so
-- FieldPath 1 / FieldPath Command users see no change.

FieldPathRealisticSeederTelemetry = FieldPathRealisticSeederTelemetry or {}
FieldPathRealisticSeederTelemetry.writeIntervalMs = 1000
FieldPathRealisticSeederTelemetry.elapsedMs = 0
FieldPathRealisticSeederTelemetry.lastSignature = ""
FieldPathRealisticSeederTelemetry.warned = false
FieldPathRealisticSeederTelemetry.link = nil
FieldPathRealisticSeederTelemetry.catalogsPublished = false

FieldPathRealisticSeederTelemetry.MANIFEST = {
    module        = "RealisticSeeder",
    version       = "2.0.3.2-split",
    fieldPathRole = "seedInventoryAndPlantingRecords",
    owns          = { "seedLots", "seedBrands", "seedVarieties", "seedTreatments", "cropSeedFillTypes" },
    doesNotOwn    = { "cropProtection", "tankMixes", "soilFertility", "grainStorage" },
    events        = { "seed.seederState" },
    notes         = "Planting passes are owned by FP2; join seed.seederState to passes by vehicle + time to attach lot/brand/variety metadata.",
}

-- ---------------------------------------------------------------------------
-- Legacy (FieldPath 1) fallback path -- unchanged from v1.
-- ---------------------------------------------------------------------------

local function fpEscapeJson(value)
    value = tostring(value or "")
    value = value:gsub('\\', '\\\\')
    value = value:gsub('"', '\\"')
    value = value:gsub('\n', ' ')
    value = value:gsub('\r', ' ')
    return value
end

local function fpGetLegacyDataDir()
    local base = ""
    if getUserProfileAppPath ~= nil then
        base = getUserProfileAppPath() or ""
    end
    if base == "" then
        return nil
    end
    local sep = "/"
    if base:sub(-1) == "/" or base:sub(-1) == "\\" then
        sep = ""
    end
    return base .. sep .. "modSettings/FS25_FieldPathCommand"
end

local function fpWriteText(path, text)
    local file = io.open(path, "w")
    if file == nil then
        return false
    end
    file:write(text)
    file:close()
    return true
end

local function fpWriteLegacyState(s)
    local payload = string.format('{"source":"FS25_RealisticSeeder","schema":1,"vehicle":"%s","fillUnitIndex":%d,"seedFillType":"%s","seedTitle":"%s","fruitType":"%s","fillLevelLiters":%.3f,"capacityLiters":%.3f,"isTurnedOn":%s}',
        fpEscapeJson(s.vehicle),
        tonumber(s.fillUnitIndex) or 1,
        fpEscapeJson(s.seedFillType),
        fpEscapeJson(s.seedTitle),
        fpEscapeJson(s.fruitType),
        tonumber(s.fillLevelLiters) or 0,
        tonumber(s.capacityLiters) or 0,
        s.isTurnedOn and "true" or "false"
    )
    local dir = fpGetLegacyDataDir()
    if dir == nil then
        return false
    end
    if createFolder ~= nil then
        createFolder(dir)
    end
    return fpWriteText(dir .. "/realisticSeederState.json", payload)
end

-- ---------------------------------------------------------------------------
-- FieldPath 2 path.
-- ---------------------------------------------------------------------------

local function fpEnsureLink()
    local T = FieldPathRealisticSeederTelemetry
    if T.link == nil and FieldPathLink ~= nil then
        T.link = FieldPathLink.connect(T.MANIFEST)
    end
    if T.link ~= nil and T.link.handle ~= nil and not T.catalogsPublished then
        -- Republish the Phase 3 catalogs where the FP2 bridge can read them.
        -- (SeedLots.lua keeps writing the FieldPath 1 copies independently.)
        if RealisticSeederSeedLots ~= nil and RealisticSeederSeedLots.files ~= nil then
            for _, entry in ipairs(RealisticSeederSeedLots.files) do
                T.link:publish(entry.name, entry.json)
            end
        end
        T.catalogsPublished = true
    end
    return T.link
end

local function fpSignature(s)
    return table.concat({
        s.vehicle, s.fillUnitIndex, s.seedFillType, s.fruitType,
        string.format("%.1f", s.fillLevelLiters or 0),
        tostring(s.isTurnedOn),
    }, "|")
end

-- ---------------------------------------------------------------------------
-- Sampling. Same entry point and signature as v1; RealisticSeeder.lua's call
-- site is unchanged.
-- ---------------------------------------------------------------------------

function FieldPathRealisticSeederTelemetry.update(vehicle, specSowingMachine, specFillUnit, specRealisticSeeder, selectedSeedFillType, dt)
    if vehicle == nil or specFillUnit == nil then
        return
    end

    local T = FieldPathRealisticSeederTelemetry
    T.elapsedMs = T.elapsedMs + (dt or 0)
    if T.elapsedMs < T.writeIntervalMs then
        return
    end
    T.elapsedMs = 0

    local link = fpEnsureLink()
    if link ~= nil then
        link:update(T.writeIntervalMs)
    end

    -- Only sample the currently controlled/selected implement to avoid churn.
    if vehicle.getIsActiveForInput ~= nil and not vehicle:getIsActiveForInput() then
        return
    end

    local sample = {
        vehicle        = "Unknown implement",
        fillUnitIndex  = 1,
        seedFillType   = "UNKNOWN",
        seedTitle      = "Unknown",
        fruitType      = "UNKNOWN",
        fillLevelLiters = 0,
        capacityLiters  = 0,
        isTurnedOn      = false,
    }

    if specSowingMachine ~= nil and specSowingMachine.fillUnitIndex ~= nil then
        sample.fillUnitIndex = specSowingMachine.fillUnitIndex
    elseif specRealisticSeeder ~= nil and specRealisticSeeder.currentFillUnitNumber ~= nil then
        sample.fillUnitIndex = specRealisticSeeder.currentFillUnitNumber
    end

    if vehicle.getFillUnitFillLevel ~= nil then
        sample.fillLevelLiters = vehicle:getFillUnitFillLevel(sample.fillUnitIndex) or 0
    end

    if specFillUnit.fillUnits ~= nil and specFillUnit.fillUnits[sample.fillUnitIndex] ~= nil then
        sample.capacityLiters = specFillUnit.fillUnits[sample.fillUnitIndex].capacity or 0
    end

    local fillTypeIndex = selectedSeedFillType
    if fillTypeIndex == nil or fillTypeIndex == FillType.UNKNOWN then
        if vehicle.getFillUnitFillType ~= nil then
            fillTypeIndex = vehicle:getFillUnitFillType(sample.fillUnitIndex)
        end
    end

    local fillTypeDesc = nil
    if fillTypeIndex ~= nil and g_fillTypeManager ~= nil then
        fillTypeDesc = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
    end

    if fillTypeDesc ~= nil then
        sample.seedFillType = fillTypeDesc.name or sample.seedFillType
        sample.seedTitle = fillTypeDesc.title or sample.seedTitle
        if sample.seedFillType:sub(1, 5) == "SEED_" then
            sample.fruitType = sample.seedFillType:sub(6)
        end
    end

    if specSowingMachine ~= nil and specSowingMachine.currentSeed ~= nil and specSowingMachine.seeds ~= nil then
        local seedFruitType = specSowingMachine.seeds[specSowingMachine.currentSeed]
        local fruitTypeDesc = g_fruitTypeManager ~= nil and g_fruitTypeManager:getFruitTypeByIndex(seedFruitType) or nil
        if fruitTypeDesc ~= nil and fruitTypeDesc.name ~= nil then
            sample.fruitType = fruitTypeDesc.name
        end
    end

    if vehicle.getFullName ~= nil then
        sample.vehicle = vehicle:getFullName()
    elseif vehicle.configFileName ~= nil then
        sample.vehicle = vehicle.configFileName
    end

    if vehicle.getIsTurnedOn ~= nil then
        sample.isTurnedOn = vehicle:getIsTurnedOn()
    end

    local signature = fpSignature(sample)
    if signature == T.lastSignature then
        return
    end

    if link ~= nil and link:isConnected() then
        if link:emit("seed.seederState", sample) then
            T.lastSignature = signature
        end
        return
    end

    -- FieldPath 2 not installed: original FieldPath 1 behaviour.
    if fpWriteLegacyState(sample) then
        T.lastSignature = signature
    elseif not T.warned then
        print("Warning: FieldPath Realistic Seeder could not write telemetry state file")
        T.warned = true
    end
end
