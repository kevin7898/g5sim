-- FS25_FarmFinance - G5Link bridge (RTK / GPS correction subscriptions).
--
-- G5Link (FS25_G5Link) bills monthly GPS subscriptions (SF2, SF3, M-RTK,
-- SF-RTK) and one-time purchases (RTK activation, StarFire 7000). Its API
-- (g_currentMission.g5linkAPI, 1.x) lets one mod take the money: setPayer.
-- Farm Finance registers as that payer and books each charge the way the
-- farm chose ("gpsBilling" on the input account record):
--   account : on the input account (like a dealer's multi-use account),
--             then the operating line when the account is full, then cash
--   line    : drawn on the operating line, then cash
--   cash    : left to G5Link (it charges cash under its own finance line)
-- The expense always lands on G5Link's "GPS corrections" statistic.
-- Leased machines that go back to the dealer, and sold machines, have their
-- subscriptions cancelled so G5Link stops billing them.
-- Game calls go through FF.env: getG5LinkAPI, gpsMoneyType, addMoneyType,
-- notify, markDirty.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util

FF.G5Link = {}
local G5 = FF.G5Link

G5.PAYER_NAME = "FS25_FarmFinance"
G5.MODES = {"account", "line", "cash"}
G5.DEFAULT_MODE = "account"
G5.RETRY_MS = 5000

G5.registered = false
G5.otherPayer = nil
G5.timer = nil
G5.monthTotals = {}

local function env()
    return FF.env or {}
end

local function markDirty()
    if env().markDirty ~= nil then
        env().markDirty()
    end
end

local function validMode(mode)
    for _, m in ipairs(G5.MODES) do
        if m == mode then
            return true
        end
    end
    return false
end

-- The G5Link API when it is loaded, ready and version 1.x; else nil.
function G5.getApi()
    local api
    if env().getG5LinkAPI ~= nil then
        api = env().getG5LinkAPI()
    elseif g_currentMission ~= nil then
        api = g_currentMission.g5linkAPI
    end
    if type(api) ~= "table" or type(api.isReady) ~= "function" then
        return nil
    end
    local ok, ready = pcall(api.isReady)
    if not ok or ready ~= true then
        return nil
    end
    if type(api.getVersion) == "function" then
        local okVersion, version = pcall(api.getVersion)
        if okVersion and type(version) == "string" and string.sub(version, 1, 2) ~= "1." then
            return nil
        end
    end
    return api
end

local function call(api, name, ...)
    local fn = api ~= nil and api[name] or nil
    if type(fn) ~= "function" then
        return nil
    end
    local ok, a, b = pcall(fn, ...)
    if ok then
        return a, b
    end
    return nil
end

function G5.isInstalled()
    return G5.getApi() ~= nil
end

-- Settings ---------------------------------------------------------------------------------

function G5.getMode(farmId)
    local farm = FF.Bank.getFarm(farmId, false)
    local mode = farm ~= nil and farm.inputs ~= nil and farm.inputs.gpsBilling or nil
    if validMode(mode) then
        return mode
    end
    return G5.DEFAULT_MODE
end

function G5.setMode(farmId, mode)
    if not validMode(mode) then
        return false, "ff_reason_invalid"
    end
    local farm = FF.Bank.getFarm(farmId)
    FF.Inputs.getAccount(farm).gpsBilling = mode
    markDirty()
    return true
end

-- Registration (server) ---------------------------------------------------------------------

function G5.reset()
    G5.registered = false
    G5.otherPayer = nil
    G5.timer = nil
    G5.monthTotals = {}
end

-- Registers Farm Finance as G5Link's payer. Never takes over from another
-- mod that already pays. Safe to call every frame; it retries every few
-- seconds because G5Link may load its savegame data after Farm Finance.
function G5.update(dt)
    if not FF.isServer() or FF.state == nil then
        return
    end
    G5.timer = (G5.timer or G5.RETRY_MS) + (dt or 0)
    if G5.timer < G5.RETRY_MS then
        return
    end
    G5.timer = 0
    G5.tryRegister()
end

function G5.tryRegister()
    local api = G5.getApi()
    if api == nil then
        G5.registered = false
        return false
    end
    local payer = call(api, "getPayer")
    if FF.blocked ~= nil and FF.blocked.bank then
        if payer == G5.PAYER_NAME then
            call(api, "clearPayer", G5.PAYER_NAME)
        end
        G5.registered = false
        return false
    end
    if payer == G5.PAYER_NAME then
        G5.registered = true
        G5.otherPayer = nil
        return true
    end
    if payer ~= nil then
        if G5.otherPayer ~= payer then
            U.log("G5Link bills through %s; Farm Finance won't take over", tostring(payer))
        end
        G5.otherPayer = payer
        G5.registered = false
        return false
    end
    local ok = call(api, "setPayer", G5.PAYER_NAME, G5.pay)
    G5.registered = ok == true
    if G5.registered then
        call(api, "unsubscribe", "monthBilled", G5)
        call(api, "subscribe", "monthBilled", G5.onMonthBilled, G5)
        U.log("paying G5Link GPS subscriptions")
    end
    return G5.registered
end

-- Payer -------------------------------------------------------------------------------------

local function lineRoom(farmId)
    local line = FF.Line.get(FF.Bank.getFarm(farmId, false))
    if line == nil then
        return 0
    end
    return math.max(line.limit - line.balance, 0)
end

local function bookExpense(farmId, amount)
    if env().addMoneyType ~= nil then
        local moneyType = env().gpsMoneyType ~= nil and env().gpsMoneyType() or nil
        env().addMoneyType(-amount, farmId, moneyType, true)
    end
end

local function record(farmId, amount, method)
    local farm = FF.Bank.getFarm(farmId)
    farm.ledger.gpsPaid = (farm.ledger.gpsPaid or 0) + amount
    if method == "account" then
        farm.ledger.gpsOnAccount = (farm.ledger.gpsOnAccount or 0) + amount
    else
        farm.ledger.gpsOnLine = (farm.ledger.gpsOnLine or 0) + amount
    end
    local totals = G5.monthTotals[farmId] or {account = 0, line = 0}
    totals[method] = totals[method] + amount
    G5.monthTotals[farmId] = totals
    markDirty()
end

-- Called by G5Link on the server: payFn(farmId, amount, info). Returns true
-- when Farm Finance took the money, else G5Link charges cash itself.
-- Also returns the method ("account" | "line") for tests and callers.
function G5.pay(farmId, amount, info)
    if FF.state == nil or not FF.isServer() or (FF.blocked ~= nil and FF.blocked.bank) then
        return false
    end
    amount = tonumber(amount) or 0
    if farmId == nil or farmId <= 0 or amount <= 0 or amount ~= amount then
        return false
    end
    info = info or {}
    local mode = G5.getMode(farmId)
    if mode == "cash" then
        return false
    end
    local description = info.description or U.text("ff_gps_charge")

    if mode == "account" and FF.Inputs.isEnabled() and FF.Inputs.getAvailable(farmId) >= amount then
        bookExpense(farmId, amount)
        if FF.Inputs.chargeAccount(farmId, amount, description) then
            record(farmId, amount, "account")
            return true, "account"
        end
        -- Can't happen after the room check, but never leave the farm charged twice.
        if env().addMoneyType ~= nil then
            env().addMoneyType(amount, farmId, env().gpsMoneyType ~= nil and env().gpsMoneyType() or nil, true)
        end
    end

    local draw = math.ceil(amount)
    if FF.Line.isEnabled() and lineRoom(farmId) >= draw then
        local ok = FF.Line.draw(farmId, draw, true)
        if ok then
            bookExpense(farmId, draw)
            record(farmId, draw, "line")
            return true, "line"
        end
    end
    return false
end

-- G5Link finished a month's billing for a farm: one notice saying where it went.
function G5.onMonthBilled(_, farmId, total, _)
    local totals = G5.monthTotals[farmId]
    G5.monthTotals[farmId] = nil
    if totals == nil or env().notify == nil then
        return
    end
    if totals.account > 0 then
        env().notify(farmId, U.text("ff_msg_gpsOnAccount", U.money(totals.account)), false)
    end
    if totals.line > 0 then
        env().notify(farmId, U.text("ff_msg_gpsOnLine", U.money(totals.line)), false)
    end
end

-- Machines leaving the farm ------------------------------------------------------------------

-- Cancels every G5Link subscription on a machine (lease returned, sold).
-- Returns how many were cancelled.
function G5.cancelVehicle(vehicleUid)
    if vehicleUid == nil or not FF.isServer() then
        return 0
    end
    local api = G5.getApi()
    local gnss = call(api, "getVehicleGnss", tostring(vehicleUid))
    if type(gnss) ~= "table" then
        return 0
    end
    local count = 0
    for _, sub in ipairs(gnss.subscriptions or {}) do
        if call(api, "setSubscription", tostring(vehicleUid), sub, false) == true then
            count = count + 1
        end
    end
    return count
end

-- Reads -------------------------------------------------------------------------------------

-- What Farm Finance knows about a farm's G5Link GPS billing.
-- {installed, connected, payer, billing, monthlyCost, machines, paid, onAccount, onLine}
function G5.getStatus(farmId)
    local api = G5.getApi()
    local farm = farmId ~= nil and FF.Bank.getFarm(farmId, false) or nil
    local ledger = farm ~= nil and farm.ledger or {}
    local status = {
        installed = api ~= nil,
        connected = G5.registered == true,
        payer = api ~= nil and call(api, "getPayer") or nil,
        billing = farmId ~= nil and G5.getMode(farmId) or G5.DEFAULT_MODE,
        monthlyCost = 0,
        machines = 0,
        paid = ledger.gpsPaid or 0,
        onAccount = ledger.gpsOnAccount or 0,
        onLine = ledger.gpsOnLine or 0
    }
    if api ~= nil and farmId ~= nil then
        status.monthlyCost = tonumber(call(api, "getMonthlyCost", farmId)) or 0
        local subs = call(api, "getSubscriptions", farmId)
        status.machines = type(subs) == "table" and #subs or 0
    end
    return status
end
