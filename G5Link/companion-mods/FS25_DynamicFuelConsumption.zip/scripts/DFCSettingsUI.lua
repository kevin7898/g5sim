-- =============================================================
-- Dynamic Fuel Consumption — DFCSettingsUI.lua
-- Injects settings into ESC > General Settings by cloning the
-- native MultiTextOption elements already on that page.
-- =============================================================

DFCSettingsUI = {}
local DFCSettingsUI_mt = Class(DFCSettingsUI)

DFCSettingsUI.realismMultLabels = { "0.7x", "0.85x", "1.0x", "1.15x", "1.3x", "1.5x" }
DFCSettingsUI.idleLabels        = nil   -- filled from l10n at init
DFCSettingsUI.onOffLabels       = nil   -- filled from l10n at init

function DFCSettingsUI.new()
    local self = setmetatable({}, DFCSettingsUI_mt)
    self.settingsElements = {}
    self:init()

    InGameMenuSettingsFrame.updateGameSettings =
        Utils.appendedFunction(InGameMenuSettingsFrame.updateGameSettings, function(settingsPage)
            self:updateGameSettings(settingsPage)
        end)

    return self
end

function DFCSettingsUI:init()
    if g_inGameMenu == nil then return false end
    local settingsPage = g_inGameMenu.pageSettings
    if settingsPage == nil then return false end

    local scrollPanel = settingsPage.gameSettingsLayout
    if scrollPanel == nil then return false end

    local sectionHeader = nil
    local multiTemplate = nil

    for _, element in pairs(scrollPanel.elements) do
        if element.name == "sectionHeader" and sectionHeader == nil then
            sectionHeader = element:clone(scrollPanel)
        end
        if element.typeName == "Bitmap" then
            if element.elements[1] ~= nil and element.elements[1].typeName == "MultiTextOption" then
                if multiTemplate == nil then
                    multiTemplate = element
                end
            end
        end
        if sectionHeader ~= nil and multiTemplate ~= nil then
            break
        end
    end

    if sectionHeader == nil or multiTemplate == nil then
        Logging.warning("[DFC] Could not find a settings template to clone")
        return
    end

    sectionHeader:setText(g_i18n:getText("dfc_section"))

    DFCSettingsUI.idleLabels = {
        g_i18n:getText("dfc_idleLevel_1"),
        g_i18n:getText("dfc_idleLevel_2"),
        g_i18n:getText("dfc_idleLevel_3"),
    }
    DFCSettingsUI.onOffLabels = {
        g_i18n:getText("dfc_toggle_off"),
        g_i18n:getText("dfc_toggle_on"),
    }

    local defs = self:getSettingDefs()

    for _, def in ipairs(defs) do
        local template = multiTemplate:clone(scrollPanel)
        template.id = nil

        local optionElement = template.elements[1]

        template.elements[2]:setText(g_i18n:getText(def.titleKey))
        optionElement.elements[1]:setText(g_i18n:getText(def.tooltipKey))

        optionElement.id = def.id
        optionElement.onClickCallback = def.callback

        optionElement:setTexts(def.labels)
        optionElement:setState(def.getState())

        table.insert(self.settingsElements, optionElement)

        template:setVisible(true)
        template:setDisabled(false)
    end

    scrollPanel:invalidateLayout()
    self.initialized = true
    return true
end

function DFCSettingsUI:getSettingDefs()
    local DFC = DynamicFuelConsumption
    local s   = DFC.settings

    return {
        {
            id = "dfc_realism",
            titleKey   = "dfc_realismMult_short",
            tooltipKey = "dfc_realismMult_long",
            labels     = DFCSettingsUI.realismMultLabels,
            getState   = function() return s.realismMultIdx end,
            callback   = function(_, state)
                s.realismMultIdx = state
                DFC.saveSettings()
            end,
        },
        {
            id = "dfc_idle",
            titleKey   = "dfc_idleLevel_short",
            tooltipKey = "dfc_idleLevel_long",
            labels     = DFCSettingsUI.idleLabels,
            getState   = function() return s.idleLevelIdx end,
            callback   = function(_, state)
                s.idleLevelIdx = state
                DFC.saveSettings()
            end,
        },
        {
            id = "dfc_notif",
            titleKey   = "dfc_notifications_short",
            tooltipKey = "dfc_notifications_long",
            labels     = DFCSettingsUI.onOffLabels,
            getState   = function() return s.notifications and 2 or 1 end,
            callback   = function(_, state)
                s.notifications = (state == 2)
                DFC.saveSettings()
            end,
        },
    }
end

function DFCSettingsUI:updateGameSettings(settingsPage)
    local s = DynamicFuelConsumption.settings

    local states = {
        dfc_realism = s.realismMultIdx,
        dfc_idle    = s.idleLevelIdx,
        dfc_notif   = s.notifications and 2 or 1,
    }

    for _, element in pairs(self.settingsElements) do
        local st = states[element.id]
        if st ~= nil then
            element:setState(st)
        end
    end
end

local function createUI()
    if g_dfcSettingsUI ~= nil and g_dfcSettingsUI.initialized then
        return true
    end
    if g_inGameMenu == nil or g_inGameMenu.pageSettings == nil then
        return false
    end
    if g_dfcSettingsUI == nil then
        g_dfcSettingsUI = DFCSettingsUI.new()
    end
    return g_dfcSettingsUI ~= nil and g_dfcSettingsUI.initialized == true
end

createUI()

if InGameMenuSettingsFrame ~= nil and InGameMenuSettingsFrame.onFrameOpen ~= nil then
    InGameMenuSettingsFrame.onFrameOpen = Utils.appendedFunction(
        InGameMenuSettingsFrame.onFrameOpen,
        function(self)
            createUI()
            if g_dfcSettingsUI ~= nil and g_dfcSettingsUI.initialized then
                g_dfcSettingsUI:updateGameSettings(self)
            end
        end
    )
end

DynamicFuelConsumptionSettingsUI = {
    onSettingsLoaded = function()
        createUI()
        if g_dfcSettingsUI ~= nil and g_dfcSettingsUI.initialized and g_inGameMenu ~= nil then
            g_dfcSettingsUI:updateGameSettings(g_inGameMenu.pageSettings)
        end
    end
}
