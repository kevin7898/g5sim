-- FS25_FarmFinance - farmland buttons on the map page.
-- Adds "Rent land", "Rent out" and "Lease notice" to the farmland context
-- buttons, and hides Buy/Sell on land that is under a Farm Finance lease.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region

FF.MapFrame = FF.MapFrame or {}
local M = FF.MapFrame

local function getSelectedFarmland(frame)
    return frame ~= nil and frame.selectedFarmland or nil
end

local function closeContextBoxes(frame)
    if frame.setMapSelectionItem ~= nil then
        frame:setMapSelectionItem()
    end
    if InGameMenuMapUtil ~= nil and InGameMenuMapUtil.hideContextBox ~= nil then
        InGameMenuMapUtil.hideContextBox(frame.contextBox)
        InGameMenuMapUtil.hideContextBox(frame.contextBoxPlayer)
        InGameMenuMapUtil.hideContextBox(frame.contextBoxFarmland)
    end
end

local function scheduleText()
    local parts = {}
    for _, payment in ipairs(R.get("land.rentPayments", {})) do
        parts[#parts + 1] = string.format("%d%% %s", math.floor((payment.share or 0) * 100 + 0.5), FF.UI.periodName(payment.period))
    end
    return table.concat(parts, ", ")
end

local function percent(share)
    return math.floor((share or 0) * 100 + 0.5)
end

-- The lease types this field can be rented on: cash rent plus the region's
-- crop-share terms.
local function leaseChoices(farmId, farmlandId)
    local choices = {}
    local cash = FF.Land.offerRentIn(farmId, farmlandId, "cash")
    if not cash.ok then
        return choices, cash.reason
    end
    choices[#choices + 1] = {
        offer = cash,
        label = U.text("ff_lease_cash", U.money(cash.annualRent))
    }
    for _, term in ipairs(R.getCropShareTerms()) do
        local offer = FF.Land.offerRentIn(farmId, farmlandId, "share", term.id)
        if offer.ok then
            local label
            if (term.inputShare or 0) > 0 then
                label = U.text("ff_lease_shareInputs", percent(term.landownerShare), percent(term.inputShare))
            else
                label = U.text("ff_lease_share", percent(term.landownerShare))
            end
            choices[#choices + 1] = {offer = offer, label = label}
        end
    end
    return choices
end

local function leaseInfo(offer)
    local deadline = FF.UI.periodName(FF.Land.getDeadlinePeriod())
    if offer.leaseType == "share" then
        local inputs = (offer.inputShare or 0) > 0
            and U.text("ff_share_inputsLine", percent(offer.inputShare)) or U.text("ff_share_noInputsLine")
        return U.text("ff_confirm_rentInShare", percent(offer.landownerShare), U.money(offer.cashEquivalent or 0),
            FF.UI.periodName(R.get("land.cropShare.sellByPeriod", 6)), inputs, deadline)
    end
    return U.text("ff_confirm_rentIn", U.money(offer.annualRent), U.money(offer.upfront), offer.monthsLeft, scheduleText(), deadline)
end

function M.rentIn(frame)
    local farmland = getSelectedFarmland(frame)
    if farmland == nil then
        return true
    end
    local farmId = g_currentMission:getFarmId()
    local choices, reason = leaseChoices(farmId, farmland.id)
    if #choices == 0 then
        InfoDialog.show(U.text(reason or "ff_reason_landUnavailable"))
        return true
    end
    local texts = {}
    for index, choice in ipairs(choices) do
        texts[index] = choice.label
    end
    local farmlandId = farmland.id
    FFOptionsDialog.show({
        title = U.text("ff_dialog_rentInTitle"),
        confirmText = U.text("ff_button_sign"),
        rows = {{label = U.text("ff_label_leaseType"), texts = texts, state = 1}},
        onChange = function(states)
            local choice = choices[states[1]] or choices[1]
            return leaseInfo(choice.offer), true
        end,
        onConfirm = function(states)
            local choice = choices[states[1]] or choices[1]
            FF.requestAction("rentIn", {farmlandId = farmlandId, leaseType = choice.offer.leaseType, termId = choice.offer.termId})
            closeContextBoxes(frame)
        end
    })
    return true
end

function M.rentOut(frame)
    local farmland = getSelectedFarmland(frame)
    if farmland == nil then
        return true
    end
    local farmId = g_currentMission:getFarmId()
    local offer = FF.Land.offerRentOut(farmId, farmland.id)
    if not offer.ok then
        InfoDialog.show(U.text(offer.reason or "ff_reason_landUnavailable"))
        return true
    end
    local text = U.text("ff_confirm_rentOut",
        U.money(offer.annualRent), U.money(offer.upfront), offer.monthsLeft, scheduleText(),
        FF.UI.periodName(FF.Land.getDeadlinePeriod()))
    YesNoDialog.show(function(_, yes)
        if yes then
            FF.requestAction("rentOut", {farmlandId = farmland.id})
            closeContextBoxes(frame)
        end
    end, M, text, U.text("ff_dialog_rentOutTitle"))
    return true
end

function M.notice(frame)
    local farmland = getSelectedFarmland(frame)
    if farmland == nil then
        return true
    end
    local contract = FF.Land.getContractByFarmland(farmland.id)
    if contract ~= nil then
        FF.UI.openNotice(contract)
    end
    return true
end

function M.onLoadMapFinished(self, superFunc, ...)
    local actions = InGameMenuMapFrame.ACTIONS
    if actions ~= nil and actions.FF_RENT_IN == nil then
        local count = 0
        for _ in pairs(actions) do
            count = count + 1
        end
        actions.FF_RENT_IN = count + 1
        actions.FF_RENT_OUT = count + 2
        actions.FF_NOTICE = count + 3
    end
    if self.contextActions ~= nil and actions ~= nil then
        self.contextActions[actions.FF_RENT_IN] = {title = U.text("ff_button_rentIn"), callback = M.rentIn, isActive = false}
        self.contextActions[actions.FF_RENT_OUT] = {title = U.text("ff_button_rentOut"), callback = M.rentOut, isActive = false}
        self.contextActions[actions.FF_NOTICE] = {title = U.text("ff_button_notice"), callback = M.notice, isActive = false}
    end
    return superFunc(self, ...)
end

-- Positional flags of InGameMenuMapFrame:setMapInputContext
M.ARG_BUY_FARMLAND = 7
M.ARG_SELL_FARMLAND = 8

function M.setMapInputContext(self, superFunc, ...)
    local count = select("#", ...)
    local args = {...}
    local actions = InGameMenuMapFrame.ACTIONS
    local context = self.contextActions
    if actions == nil or context == nil or context[actions.FF_RENT_IN] == nil or FF.state == nil then
        return superFunc(self, ...)
    end

    context[actions.FF_RENT_IN].isActive = false
    context[actions.FF_RENT_OUT].isActive = false
    context[actions.FF_NOTICE].isActive = false

    local farmland = getSelectedFarmland(self)
    if farmland ~= nil then
        local farmId = g_currentMission:getFarmId()
        local contract = FF.Land.getContractByFarmland(farmland.id)
        local canManage = FF.canManageFarm()
        if contract ~= nil then
            args[M.ARG_BUY_FARMLAND] = false
            args[M.ARG_SELL_FARMLAND] = false
            if contract.farmId == farmId and canManage then
                context[actions.FF_NOTICE].isActive = true
                context[actions.FF_NOTICE].title = U.text(contract.endCropYear ~= nil and "ff_button_cancelNotice" or "ff_button_notice")
            end
        elseif canManage and farmId ~= nil and farmId > 0 then
            local owner = g_farmlandManager:getFarmlandOwner(farmland.id)
            if owner == FarmlandManager.NO_OWNER_FARM_ID and not FF.blocked.rentIn then
                local offer = FF.Land.offerRentIn(farmId, farmland.id, "cash")
                if offer.ok then
                    context[actions.FF_RENT_IN].isActive = true
                    context[actions.FF_RENT_IN].title = U.text("ff_button_rentInAmount", U.money(offer.annualRent))
                end
            elseif owner == farmId and not FF.blocked.rentOut then
                local offer = FF.Land.offerRentOut(farmId, farmland.id)
                if offer.ok then
                    context[actions.FF_RENT_OUT].isActive = true
                    context[actions.FF_RENT_OUT].title = U.text("ff_button_rentOutAmount", U.money(offer.annualRent))
                end
            end
        end
    end

    return superFunc(self, unpack(args, 1, count))
end
