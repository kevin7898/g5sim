Realistic Seeder 2.6.0.0 - staged technology

Buy upgrades through store/workshop Customize. They are generic kits modeled on
what is sold for real planters and drills, not claims of branded fit, and add no
visible 3D hardware. Prices approximate US list prices and scale with the
machine: per row on planters, per opener or section on drills.

Machine size
Planter rows come from the equipment profile (vehicle.rsPlacement#rowCount),
known base-game models, the model name ("16 Row", "16R30", Horsch "24.50"), the
file name, or else working width / 30 in. Drill openers come from the name's row
spacing ("12.25") or width / 7.5 in; shutoff sections are about 3 m each (2-12).
Settings hold 24 switches: planters over 24 rows switch in 2-row (or larger)
groups. The setup dialog's Equipment help shows the count and where it came from.

Planter                                  Price
Planter monitor + logger                 $6,500
Optical seed sensors                     $150/row
Meter drive / row control
  Hydraulic variable-rate drive          $6,000
  Ground drive + row clutches            $300/row
  Hydraulic VR drive + row clutches      $6,000 + $300/row
  Electric drive on every row            $4,000 + $1,000/row
Automatic GPS row shutoff (unlock)       $1,500
Precision vacuum meters                  $450/row
Downforce: air bags, cab adjust          $4,000 + $100/row
           automatic air bags            $9,000 + $150/row
           hydraulic, automatic per row  $1,100/row
Closing: aftermarket wheels              $150/row
         hydraulic, automatic            $1,000/row
Powered row depth, with depth readout    $700/row
Sensing seed firmers (soil)              $600/row
Belt seed delivery                       $1,100/row
Pneumatic row cleaner control            $2,000 + $350/row (recognized cleaners)

Drill / air seeder                       Price
Seeding monitor + logger                 $4,000
Blockage sensors                         $60/opener
Seed counting sensors                    $250/opener
Variable-rate meter drive                $5,000
VR meter drive + section shutoff         $5,000 + $1,500/section
Automatic GPS section control (unlock)   $1,500
Crop-specific meter rollers              $400
Hydraulic opener pressure, cab adjust    $5,000 + $50/opener
Aftermarket press wheels / seed firmers  $40/opener
Cab hydraulic depth (whole drill)        $6,000

Dependencies
Seed sensors, blockage sensors, soil sensing, automatic downforce or closing,
GPS shutoff and row cleaner control report through the monitor; without it they
stay fitted but inactive (cab adjustment still works). Factory-fitted monitored
hardware counts as having its own display. Automatic depth needs powered depth
AND soil sensing. Belt delivery needs precision meters AND electric row drives,
for corn, soybeans, cotton and sugarbeets. Drills get no automatic downforce,
closing or depth, and no soil sensing: those are not sold for drills.
Incomplete combinations are listed as inactive in the setup dialog.

Older saves
Options sold before 2.6 (depth sensing, sensed and automatic downforce/closing on
any machine, drill soil sensing) stay installed with what they did; they are no
longer offered. A save with a seed monitor, soil sensing or automatic system but
no monitor shows it inactive until a monitor is fitted.

Row and section shutoff
Row clutches switch rows on and off; electric drives also set a rate per row.
Drill sections switch sections. Rows are numbered from the left in the direction
of travel and span every sowing work area of the implement. Switched-off lanes
place and meter no seed. Use Row control in setup (Right Ctrl + ;) to switch
lanes, turn automatic shutoff on, and pick the coverage overlap:
  Minimize skips   - a lane turns off when the ground ahead is ~all planted
  Half covered     - when half the ground ahead is planted
  Minimize overlap - as soon as any ground ahead is planted
Automatic shutoff looks 0.8 s of travel (0.6-4 m) ahead of each lane for ground
the game already marks as sown, so it works at headlands, point rows and
overlaps without a field boundary. It needs the GPS unlock and the monitor, or a
display that controls it: with the G5Link Section Control activation, the G5's
master switch and overlap setting run it and the dialog shows "G5Link".

Manual is the default for depth, downforce and closing. Automatic pressure uses
soil conditions and the operator's pressure as a bias: 50% is neutral. Values
represent simulated effort, not PSI. Automatic depth uses crop range and modeled
seedbed moisture within chosen bounds. Missing feedback holds the manual target.
These are model estimates, not calibrated agronomic prescriptions.

The 1760 profile recognizes selected air-adjust cleaners, gauge and closing
wheels. Kinze 4905 retains its factory logger, seed monitor and cab rate control.
Unknown hardware can be declared in an XML capability profile
(vehicle.rsPlacement#<capability>="true", #rowCount, #kind).

Separate seed carts and water seeders are excluded. Multiplayer and physical
hardware calibration are not certified. Automatic shutoff and machine-size
detection have not been checked in a live FS25 session yet.
