-- Future blend domain model only. No vehicle/storage hooks use this yet.
-- Persistent keys are component IDs, never session-specific engine type indices.
local WV = WheatVarieties
local Batch = {}
WV.GrainBatch = Batch

local function finiteNonnegative(value)
    return type(value) == "number" and value == value and value >= 0 and value < math.huge
end

function Batch.new(components)
    local batch = { schemaVersion = 1, components = {} }
    for id, litres in pairs(components or {}) do
        assert(type(id) == "string" and id ~= "", "Invalid component ID")
        assert(finiteNonnegative(litres), "Invalid grain quantity")
        if litres > 0 then batch.components[id] = litres end
    end
    return batch
end

function Batch.total(batch)
    local total = 0
    for _, id in ipairs(WV.sortedKeys(batch.components)) do total = total + batch.components[id] end
    assert(finiteNonnegative(total), "Batch total overflow")
    return total
end

function Batch.mix(left, right)
    local result = Batch.new(left.components)
    for id, litres in pairs(right.components) do
        assert(finiteNonnegative(litres), "Invalid grain quantity")
        result.components[id] = (result.components[id] or 0) + litres
    end
    Batch.total(result)
    return result
end

function Batch.split(batch, litres)
    local total = Batch.total(batch)
    assert(finiteNonnegative(litres) and litres <= total, "Withdrawal exceeds batch")
    local taken, remainder = {}, {}
    for id, amount in pairs(batch.components) do
        local quantity = total > 0 and amount * (litres / total) or 0
        taken[id], remainder[id] = quantity, amount - quantity
    end
    return Batch.new(taken), Batch.new(remainder)
end
