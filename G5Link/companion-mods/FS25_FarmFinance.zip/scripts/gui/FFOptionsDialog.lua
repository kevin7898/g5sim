-- FS25_FarmFinance - generic options dialog.
--
-- FFOptionsDialog.show({
--     title = "...",
--     rows = { {label = "...", texts = {...}, state = 1}, ... },  -- up to 3
--     confirmText = "...",
--     onChange = function(states) return infoText, canConfirm end,
--     onConfirm = function(states) end
-- })

FFOptionsDialog = {}
local FFOptionsDialog_mt = Class(FFOptionsDialog, MessageDialog)

FFOptionsDialog.NAME = "FFOptionsDialog"
FFOptionsDialog.MAX_ROWS = 3

FFOptionsDialog.CONTROLS = {
    "titleText", "infoText", "confirmButton", "cancelButton",
    "label1", "option1", "label2", "option2", "label3", "option3"
}

function FFOptionsDialog.new(target, customMt)
    local self = MessageDialog.new(target, customMt or FFOptionsDialog_mt)
    self.config = nil
    return self
end

function FFOptionsDialog:onLoad()
    FFOptionsDialog:superClass().onLoad(self)
    self:registerControls(FFOptionsDialog.CONTROLS)
end

function FFOptionsDialog.register(modDirectory)
    if g_gui.guis[FFOptionsDialog.NAME] ~= nil then
        return
    end
    local dialog = FFOptionsDialog.new()
    g_gui:loadGui(modDirectory .. "gui/FFOptionsDialog.xml", FFOptionsDialog.NAME, dialog)
end

function FFOptionsDialog.show(config)
    local gui = g_gui.guis[FFOptionsDialog.NAME]
    if gui == nil or gui.target == nil then
        FarmFinance.Util.warn("options dialog is not loaded")
        return
    end
    gui.target.pendingConfig = config
    g_gui:showDialog(FFOptionsDialog.NAME)
end

function FFOptionsDialog:onOpen()
    FFOptionsDialog:superClass().onOpen(self)
    self.config = self.pendingConfig or {}
    self.pendingConfig = nil
    local config = self.config

    if self.titleText ~= nil then
        self.titleText:setText(config.title or "")
    end
    if self.confirmButton ~= nil then
        self.confirmButton:setText(config.confirmText or FarmFinance.Util.text("ff_button_confirm"))
    end

    local rows = config.rows or {}
    for index = 1, FFOptionsDialog.MAX_ROWS do
        local label = self["label" .. index]
        local option = self["option" .. index]
        local row = rows[index]
        if label ~= nil and option ~= nil then
            if row ~= nil then
                label:setText(row.label or "")
                label:setVisible(true)
                option:setTexts(row.texts or {""})
                option:setState(math.max(1, math.min(row.state or 1, #(row.texts or {""}))), true)
                option:setVisible(true)
                option:setDisabled(row.disabled == true)
            else
                label:setVisible(false)
                option:setVisible(false)
            end
        end
    end
    self:refreshInfo()
end

function FFOptionsDialog:getStates()
    local states = {}
    local rows = (self.config or {}).rows or {}
    for index = 1, #rows do
        local option = self["option" .. index]
        states[index] = option ~= nil and option:getState() or 1
    end
    return states
end

function FFOptionsDialog:refreshInfo()
    local config = self.config or {}
    local infoText, canConfirm = "", true
    if config.onChange ~= nil then
        local ok, text, allowed = pcall(config.onChange, self:getStates())
        if ok then
            infoText = text or ""
            canConfirm = allowed ~= false
        else
            infoText = tostring(text)
            canConfirm = false
        end
    end
    if self.infoText ~= nil then
        self.infoText:setText(infoText)
    end
    if self.confirmButton ~= nil then
        self.confirmButton:setDisabled(not canConfirm)
    end
end

function FFOptionsDialog:onOptionChanged()
    self:refreshInfo()
end

function FFOptionsDialog:onClickConfirm()
    local config = self.config or {}
    local states = self:getStates()
    self:close()
    if config.onConfirm ~= nil then
        config.onConfirm(states)
    end
end

function FFOptionsDialog:onClickCancel()
    self:close()
end

function FFOptionsDialog:onClose()
    FFOptionsDialog:superClass().onClose(self)
end
