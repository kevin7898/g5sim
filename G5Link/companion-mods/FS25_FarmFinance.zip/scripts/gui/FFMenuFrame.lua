-- FS25_FarmFinance - in-game menu page and the dialogs it opens.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region
local LM = FF.LoanMath

FF.UI = FF.UI or {}
local UI = FF.UI

UI.PRODUCTS = {"realEstate", "equipment", "operating"}

local function farmId()
    if g_currentMission ~= nil then
        return g_currentMission:getFarmId()
    end
    return 0
end

local function isValidFarm(id)
    return id ~= nil and id > 0 and (FarmManager == nil or id ~= FarmManager.SPECTATOR_FARM_ID)
end

function UI.periodName(period)
    return U.text("ff_period_" .. tostring(U.clamp(period or 1, 1, 12)))
end

local function reasonText(reason)
    if reason == nil or reason == "" then
        return ""
    end
    return U.text(reason)
end

-- Loan application ------------------------------------------------------------

local function buildAmountSteps(limit)
    local minAmount = R.get("loans.minAmount", 5000)
    local steps = {}
    local seen = {}
    local fractions = {0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00}
    for _, fraction in ipairs(fractions) do
        local amount = math.floor(limit * fraction / 1000) * 1000
        if fraction == 1.00 then
            amount = math.floor(limit / 100) * 100
        end
        if amount >= minAmount and not seen[amount] then
            seen[amount] = true
            steps[#steps + 1] = amount
        end
    end
    return steps
end

function UI.openLoanForProduct(productId)
    local id = farmId()
    local terms = R.getProductTerms(productId)
    local defaultTerm = R.get("loans.product." .. productId .. ".defaultTermYears", terms[1])

    local maxLimit = 0
    for _, term in ipairs(terms) do
        local quote = FF.Bank.quote(id, productId, term, nil)
        maxLimit = math.max(maxLimit, quote.limit or 0)
    end
    local amounts = buildAmountSteps(maxLimit)
    if #amounts == 0 then
        local quote = FF.Bank.quote(id, productId, defaultTerm, nil)
        InfoDialog.show(U.text("ff_msg_noLoanAvailable", U.text("ff_product_" .. productId), reasonText(quote.reason or "ff_reason_noRoom")))
        return
    end

    local termTexts, defaultTermState = {}, 1
    for index, term in ipairs(terms) do
        termTexts[index] = U.text(term == 1 and "ff_term_year" or "ff_term_years", term)
        if term == defaultTerm then
            defaultTermState = index
        end
    end
    local amountTexts = {}
    for index, amount in ipairs(amounts) do
        amountTexts[index] = U.money(amount)
    end

    FFOptionsDialog.show({
        title = U.text("ff_dialog_loanTitle", U.text("ff_product_" .. productId)),
        confirmText = U.text("ff_button_apply"),
        rows = {
            {label = U.text("ff_label_term"), texts = termTexts, state = defaultTermState},
            {label = U.text("ff_label_amount"), texts = amountTexts, state = math.max(1, math.floor(#amounts / 2))}
        },
        onChange = function(states)
            local term = terms[states[1]] or defaultTerm
            local amount = amounts[states[2]] or amounts[1]
            local quote = FF.Bank.quote(id, productId, term, amount)
            local lines = {
                U.text("ff_quote_rate", U.percent(quote.rate), quote.grade, quote.score),
                U.text("ff_quote_payment", U.money(quote.payment or 0), quote.months),
                U.text("ff_quote_totalInterest", U.money(math.max((quote.payment or 0) * quote.months - amount, 0))),
                U.text("ff_quote_limit", U.money(quote.limit))
            }
            if quote.capacity == nil then
                lines[#lines + 1] = U.text("ff_quote_newFarm")
            end
            if not quote.approved then
                lines[#lines + 1] = U.text("ff_quote_declined", reasonText(quote.reason))
            end
            return table.concat(lines, "\n"), quote.approved
        end,
        onConfirm = function(states)
            local term = terms[states[1]] or defaultTerm
            local amount = amounts[states[2]] or amounts[1]
            FF.requestAction("takeLoan", {productId = productId, termYears = term, amount = amount})
        end
    })
end

function UI.openNewLoan()
    local id = farmId()
    if not isValidFarm(id) then
        return
    end
    if FF.blocked.bank then
        InfoDialog.show(U.text("ff_msg_bankBlocked", FF.getConflictText("bank")))
        return
    end
    local products, texts = {}, {}
    for _, productId in ipairs(UI.PRODUCTS) do
        if R.isProductEnabled(productId) then
            products[#products + 1] = productId
            texts[#texts + 1] = U.text("ff_product_" .. productId)
        end
    end
    if FF.Line.isEnabled() then
        products[#products + 1] = "line"
        texts[#texts + 1] = U.text("ff_product_line")
    end
    FFOptionsDialog.show({
        title = U.text("ff_dialog_newLoanTitle"),
        confirmText = U.text("ff_button_next"),
        rows = {{label = U.text("ff_label_product"), texts = texts, state = 1}},
        onChange = function(states)
            local productId = products[states[1]]
            return U.text("ff_product_desc_" .. productId), true
        end,
        onConfirm = function(states)
            local productId = products[states[1]]
            if productId == "line" then
                UI.openLineOffer()
            elseif productId ~= nil then
                UI.openLoanForProduct(productId)
            end
        end
    })
end

-- Operating line ------------------------------------------------------------------

function UI.openLineOffer()
    local id = farmId()
    local farm = FF.Bank.getFarm(id)
    if FF.Line.get(farm) ~= nil then
        InfoDialog.show(U.text("ff_reason_lineOpen"))
        return
    end
    local limit, quote = FF.Line.quoteLimit(id)
    if quote.score < R.get("credit.minScore", 580) or limit < R.get("loans.minAmount", 5000) then
        InfoDialog.show(U.text("ff_msg_noLoanAvailable", U.text("ff_product_line"), reasonText(quote.reason or "ff_reason_noRoom")))
        return
    end
    YesNoDialog.show(function(_, yes)
        if yes then
            FF.requestAction("openLine", {})
        end
    end, UI, U.text("ff_confirm_openLine", U.money(limit), U.percent(quote.rate), UI.periodName(R.get("line.cleanUpPeriod", 10)),
        R.get("line.carryoverYears", 3)), U.text("ff_product_line"))
end

local function fractionOptions(total, fractions, minimum)
    local options, seen = {}, {}
    for _, fraction in ipairs(fractions) do
        local amount = math.floor(total * fraction / 100) * 100
        if fraction == 1 then
            amount = math.floor(total + 0.5)
        end
        if amount >= (minimum or 1) and not seen[amount] then
            seen[amount] = true
            options[#options + 1] = amount
        end
    end
    return options
end

function UI.openLine(line)
    local id = farmId()
    local farm = FF.Bank.getFarm(id)
    local available = math.max(line.limit - line.balance, 0)
    local actions = {}
    for _, amount in ipairs(fractionOptions(available, {0.10, 0.25, 0.50, 1}, 1000)) do
        actions[#actions + 1] = {action = "lineDraw", amount = amount, text = U.text("ff_line_draw", U.money(amount))}
    end
    for _, amount in ipairs(fractionOptions(line.balance, {0.25, 0.50, 1}, 1)) do
        actions[#actions + 1] = {action = "lineRepay", amount = amount, text = U.text("ff_line_repay", U.money(amount))}
    end
    if line.balance <= 0 then
        actions[#actions + 1] = {action = "closeLine", text = U.text("ff_line_close")}
    end
    if #actions == 0 then
        return
    end
    local texts = {}
    for index, item in ipairs(actions) do
        texts[index] = item.text
    end
    FFOptionsDialog.show({
        title = U.text("ff_product_line"),
        rows = {{label = U.text("ff_label_action"), texts = texts, state = 1}},
        onChange = function(states)
            local item = actions[states[1]]
            local lines = {
                U.text("ff_line_info", U.money(line.balance), U.money(line.limit), U.percent(FF.Line.getRate(farm))),
                U.text(line.cleanedThisYear and "ff_line_cleaned" or "ff_line_mustClean", UI.periodName(R.get("line.cleanUpPeriod", 10)))
            }
            if item.action == "lineRepay" and FF.FarmData.getCash(id) < item.amount then
                lines[#lines + 1] = U.text("ff_reason_noCash")
                return table.concat(lines, "\n"), false
            end
            return table.concat(lines, "\n"), true
        end,
        onConfirm = function(states)
            local item = actions[states[1]]
            FF.requestAction(item.action, {amount = item.amount})
        end
    })
end

-- Shop: Finance / Lease ------------------------------------------------------------

local function percentText(value)
    return string.format("%d%%", math.floor(value * 100 + 0.5))
end

-- Asks for the approval and remembers the shop screen, so the purchase can
-- be completed (the shop's own Buy pressed) as soon as the approval lands.
local function sendPreApprove(args, screen)
    FF.pendingShopScreen = {screen = screen, time = g_currentMission ~= nil and g_currentMission.time or 0}
    FF.requestAction("preApprove", args)
end

local function openShopLoan(base, usePromo)
    local id = farmId()
    local promo = usePromo and FF.Equipment.getPromo(base.brand) or nil
    local terms = R.getProductTerms("equipment")
    local downs = {}
    local minDown = R.get("equipment.loan.minDownPayment", 0.10)
    for _, share in ipairs({0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50}) do
        if share + 1e-9 >= minDown then
            downs[#downs + 1] = share
        end
    end
    local downTexts = {}
    for index, share in ipairs(downs) do
        downTexts[index] = U.text("ff_down_option", percentText(share), U.money(base.price * share))
    end
    local rows = {}
    local termTexts = {}
    if not usePromo then
        for index, term in ipairs(terms) do
            termTexts[index] = U.text(term == 1 and "ff_term_year" or "ff_term_years", term)
        end
        rows[#rows + 1] = {label = U.text("ff_label_term"), texts = termTexts, state = math.max(1, math.min(3, #terms))}
    end
    rows[#rows + 1] = {label = U.text("ff_label_down"), texts = downTexts, state = 1}

    local function readStates(states)
        if usePromo then
            return nil, downs[states[1]] or downs[1]
        end
        return terms[states[1]] or terms[1], downs[states[2]] or downs[1]
    end

    FFOptionsDialog.show({
        title = usePromo and U.text("ff_dialog_promoTitle", base.brand or "?") or U.text("ff_dialog_shopLoanTitle", base.storeName),
        confirmText = U.text("ff_button_financeBuy"),
        rows = rows,
        onChange = function(states)
            local term, down = readStates(states)
            local quote = FF.Equipment.quoteLoan(id, {
                price = base.price, downShare = down, termYears = term,
                usePromo = usePromo, brand = base.brand, isSale = base.isSale
            })
            local lines = {
                U.text("ff_shop_price", U.money(base.price), U.money(quote.down), U.money(quote.financed)),
                U.text("ff_quote_rate", U.percent(quote.rate), quote.grade, quote.score),
                U.text("ff_quote_payment", U.money(quote.payment or 0), quote.months)
            }
            if usePromo and promo ~= nil then
                lines[#lines + 1] = U.text("ff_shop_promoNote", percentText(promo.rebate), U.money(base.price * promo.rebate))
            end
            if base.isSale then
                lines[#lines + 1] = U.text("ff_shop_usedNote")
            end
            lines[#lines + 1] = U.text("ff_shop_collateralNote")
            if not quote.approved then
                lines[#lines + 1] = U.text("ff_quote_declined", reasonText(quote.reason))
            end
            return table.concat(lines, "\n"), quote.approved == true
        end,
        onConfirm = function(states)
            local term, down = readStates(states)
            sendPreApprove({
                kind = usePromo and "promo" or "loan", price = base.price, storeXml = base.storeXml,
                storeName = base.storeName, isSale = base.isSale, downShare = down, termYears = term
            }, base.screen)
        end
    })
end

local function openShopLease(base)
    local id = farmId()
    local terms = R.get("equipment.lease.termYears", {2, 3, 4, 5})
    local hours = R.get("equipment.lease.hoursPerYear", {400, 600, 800})
    local termTexts, hourTexts = {}, {}
    for index, term in ipairs(terms) do
        termTexts[index] = U.text("ff_term_years", term)
    end
    for index, value in ipairs(hours) do
        hourTexts[index] = U.text("ff_hours_option", value)
    end
    FFOptionsDialog.show({
        title = U.text("ff_dialog_leaseTitle", base.storeName),
        confirmText = U.text("ff_button_leaseBuy"),
        rows = {
            {label = U.text("ff_label_term"), texts = termTexts, state = math.min(2, #terms)},
            {label = U.text("ff_label_hours"), texts = hourTexts, state = math.min(2, #hours)}
        },
        onChange = function(states)
            local quote = FF.Equipment.quoteLease(id, {
                price = base.price, storeXml = base.storeXml,
                termYears = terms[states[1]] or terms[1], hoursPerYear = hours[states[2]] or hours[1]
            })
            local lines = {
                U.text("ff_lease_payment", U.money(quote.payment), quote.months, U.percent(quote.rate)),
                U.text("ff_lease_upfront", U.money(quote.upfront), U.money(quote.deposit)),
                U.text("ff_lease_residual", U.money(quote.residual)),
                U.text("ff_lease_excess", U.money(base.price * R.get("equipment.lease.excessHourShare", 0.0002))),
                U.text("ff_lease_end")
            }
            if not quote.approved then
                lines[#lines + 1] = U.text("ff_quote_declined", reasonText(quote.reason))
            end
            return table.concat(lines, "\n"), quote.approved == true
        end,
        onConfirm = function(states)
            sendPreApprove({
                kind = "lease", price = base.price, storeXml = base.storeXml, storeName = base.storeName,
                isSale = base.isSale, termYears = terms[states[1]] or terms[1], hoursPerYear = hours[states[2]] or hours[1]
            }, base.screen)
        end
    })
end

function UI.openShopFinance(screen, storeItem)
    local base = {
        screen = screen,
        price = screen.totalPrice or storeItem.price or 0,
        storeXml = storeItem.xmlFilename,
        storeName = storeItem.name,
        brand = FF.getBrandName(storeItem),
        isSale = screen.saleItem ~= nil
    }
    local choices = {{kind = "loan", text = U.text("ff_shop_choiceLoan")}}
    local promo = not base.isSale and FF.Equipment.getPromo(base.brand) or nil
    if promo ~= nil then
        choices[#choices + 1] = {kind = "promo", text = U.text("ff_shop_choicePromo", promo.months, base.brand)}
    end
    if R.get("equipment.lease.enabled", true) ~= false and not base.isSale then
        choices[#choices + 1] = {kind = "lease", text = U.text("ff_shop_choiceLease")}
    end
    local texts = {}
    for index, choice in ipairs(choices) do
        texts[index] = choice.text
    end
    FFOptionsDialog.show({
        title = U.text("ff_dialog_shopTitle", base.storeName, U.money(base.price)),
        confirmText = U.text("ff_button_next"),
        rows = {{label = U.text("ff_label_how"), texts = texts, state = 1}},
        onChange = function(states)
            local choice = choices[states[1]]
            return U.text("ff_shop_desc_" .. choice.kind), true
        end,
        onConfirm = function(states)
            local choice = choices[states[1]]
            if choice.kind == "lease" then
                openShopLease(base)
            else
                openShopLoan(base, choice.kind == "promo")
            end
        end
    })
end

-- Machine leases ----------------------------------------------------------------------

function UI.openLease(lease)
    local vehicle = FF.env.equipment ~= nil and FF.env.equipment.findVehicle ~= nil and lease.vehicleUid ~= nil
        and FF.env.equipment.findVehicle(lease.vehicleUid) or nil
    local settlement = FF.Equipment.getLeaseSettlement(lease, vehicle)
    local actions = {}
    if vehicle ~= nil then
        actions[#actions + 1] = {action = "leaseReturn", text = U.text("ff_lease_returnOption", U.money(math.max(settlement.returnCost, 0)))}
    end
    actions[#actions + 1] = {action = "leaseBuyout", text = U.text("ff_lease_buyoutOption", U.money(settlement.buyout))}
    if (lease.monthsLeft or 0) <= 0 then
        actions[#actions + 1] = {action = "leaseExtend", text = U.text("ff_lease_extendOption")}
    end
    local texts = {}
    for index, item in ipairs(actions) do
        texts[index] = item.text
    end
    FFOptionsDialog.show({
        title = lease.name or U.text("ff_type_lease"),
        rows = {{label = U.text("ff_label_action"), texts = texts, state = 1}},
        onChange = function(states)
            local item = actions[states[1]]
            local lines = {U.text("ff_lease_info", U.money(lease.payment), lease.monthsLeft or 0, U.money(lease.residual))}
            if settlement.hours ~= nil then
                lines[#lines + 1] = U.text("ff_lease_hours", math.floor(settlement.hours + 0.5), math.floor(settlement.excessHours + 0.5), U.money(settlement.excessCharge))
                lines[#lines + 1] = U.text("ff_lease_wear", U.money(settlement.wear))
            elseif lease.vehicleUid == nil then
                lines[#lines + 1] = U.text("ff_lease_noVehicle")
            end
            if settlement.earlyPayments > 0 then
                lines[#lines + 1] = U.text("ff_lease_early", U.money(settlement.earlyPayments))
            end
            lines[#lines + 1] = U.text("ff_lease_depositBack", U.money(settlement.deposit))
            if item.action == "leaseBuyout" and FF.FarmData.getCash(farmId()) < settlement.buyout - settlement.deposit then
                lines[#lines + 1] = U.text("ff_reason_noCash")
                return table.concat(lines, "\n"), false
            end
            return table.concat(lines, "\n"), true
        end,
        onConfirm = function(states)
            local item = actions[states[1]]
            FF.requestAction(item.action, {leaseId = lease.id})
        end
    })
end

-- Input account ---------------------------------------------------------------------

function UI.accountName()
    return R.get("inputs.account.name", U.text("ff_type_inputAccount"))
end

function UI.openInputAccount()
    local id = farmId()
    local farm = FF.Bank.getFarm(id)
    local account = FF.Inputs.getAccount(farm)
    local balance, pastDue = FF.Inputs.getBalance(farm)
    local available, limit = FF.Inputs.getAvailable(id)
    local actions = {}
    if balance > 0 then
        actions[#actions + 1] = {action = "payInputs", text = U.text("ff_account_payAll", U.money(balance))}
        if balance >= 2000 then
            local half = math.floor(balance / 200) * 100
            actions[#actions + 1] = {action = "payInputs", amount = half, text = U.text("ff_account_payPart", U.money(half))}
        end
    end
    actions[#actions + 1] = {
        action = "setAutoCharge",
        enabled = not account.autoCharge,
        text = U.text(account.autoCharge and "ff_account_autoOff" or "ff_account_autoOn")
    }
    local texts = {}
    for index, item in ipairs(actions) do
        texts[index] = item.text
    end
    FFOptionsDialog.show({
        title = UI.accountName(),
        rows = {{label = U.text("ff_label_action"), texts = texts, state = 1}},
        onChange = function(states)
            local item = actions[states[1]]
            local lines = {
                U.text("ff_account_info", U.money(balance), U.money(limit), U.money(available)),
                U.text("ff_account_terms", UI.periodName(R.get("inputs.account.dueDatePeriod", 10)), U.percent(FF.Inputs.getPastDueRate())),
                U.text("ff_account_discount", U.percent(FF.Inputs.getEarlyPayDiscount(), 0), U.money(account.discounts or 0)),
                U.text(account.autoCharge and "ff_account_autoIsOn" or "ff_account_autoIsOff")
            }
            if pastDue > 0 then
                lines[#lines + 1] = U.text("ff_account_pastDue", U.money(pastDue))
            end
            if item.action == "payInputs" and FF.FarmData.getCash(id) < (item.amount or balance) then
                lines[#lines + 1] = U.text("ff_reason_noCash")
                return table.concat(lines, "\n"), false
            end
            return table.concat(lines, "\n"), true
        end,
        onConfirm = function(states)
            local item = actions[states[1]]
            FF.requestAction(item.action, {amount = item.amount, enabled = item.enabled})
        end
    })
end

-- Extra payment -------------------------------------------------------------------

function UI.openPayment(loan)
    local options = {
        {fraction = 0.10}, {fraction = 0.25}, {fraction = 0.50}, {fraction = 1.00, payOff = true}
    }
    local texts = {}
    for index, option in ipairs(options) do
        option.amount = math.ceil(loan.balance * option.fraction)
        if option.payOff then
            texts[index] = U.text("ff_pay_off", U.money(loan.balance))
        else
            texts[index] = U.text("ff_pay_part", U.money(option.amount))
        end
    end
    FFOptionsDialog.show({
        title = U.text("ff_dialog_payTitle", loan.label or U.text("ff_product_" .. (loan.productId or "imported"))),
        confirmText = U.text("ff_button_pay"),
        rows = {{label = U.text("ff_label_amount"), texts = texts, state = 1}},
        onChange = function(states)
            local option = options[states[1]]
            local cash = FF.FarmData.getCash(loan.farmId)
            local lines = {U.text("ff_pay_balance", U.money(loan.balance), loan.monthsLeft)}
            if cash < option.amount then
                lines[#lines + 1] = U.text("ff_reason_noCash")
                return table.concat(lines, "\n"), false
            end
            return table.concat(lines, "\n"), true
        end,
        onConfirm = function(states)
            local option = options[states[1]]
            if option.payOff then
                FF.requestAction("payOff", {loanId = loan.id})
            else
                FF.requestAction("payExtra", {loanId = loan.id, amount = option.amount})
            end
        end
    })
end

-- Land notice -----------------------------------------------------------------------

function UI.openNotice(contract)
    local deadline = FF.Land.getDeadlinePeriod()
    if contract.endCropYear ~= nil then
        if contract.noticeBy ~= "farm" then
            InfoDialog.show(U.text("ff_msg_otherSideNotice", contract.name))
            return
        end
        -- YesNoDialog calls back as callback(target, yes)
        YesNoDialog.show(function(_, yes)
            if yes then
                FF.requestAction("cancelNotice", {contractId = contract.id})
            end
        end, UI, U.text("ff_confirm_cancelNotice", contract.name), U.text("ff_dialog_noticeTitle"))
        return
    end
    local endYear = FF.Land.getEndYearForNoticeNow()
    local whenKey = endYear == FF.state.cropYear and "ff_notice_thisYear" or "ff_notice_nextYear"
    YesNoDialog.show(function(_, yes)
        if yes then
            FF.requestAction("notice", {contractId = contract.id})
        end
    end, UI, U.text("ff_confirm_notice", contract.name, U.text(whenKey), UI.periodName(deadline)), U.text("ff_dialog_noticeTitle"))
end

-- Credit report -------------------------------------------------------------------

function UI.buildCreditReport(id)
    local evaluation = FF.Bank.evaluate(id)
    local ratios = evaluation.ratios
    local farm = FF.Bank.getFarm(id)
    local history = farm.history
    local lines = {}
    lines[#lines + 1] = U.text("ff_report_score", evaluation.score, evaluation.grade)
    lines[#lines + 1] = U.text("ff_report_parts",
        math.floor(evaluation.parts.payment * 100 + 0.5),
        math.floor(evaluation.parts.solvency * 100 + 0.5),
        math.floor(evaluation.parts.liquidity * 100 + 0.5),
        math.floor(evaluation.parts.repayment * 100 + 0.5),
        math.floor(evaluation.parts.length * 100 + 0.5))
    lines[#lines + 1] = U.text("ff_report_history", history.onTime or 0, history.late or 0, history.missed or 0, history.streak or 0)
    lines[#lines + 1] = U.text("ff_report_assets", U.money(ratios.totalAssets), U.money(ratios.totalDebt), U.money(ratios.netWorth))
    lines[#lines + 1] = U.text("ff_report_da", U.percent(ratios.debtToAsset, 0))
    if ratios.currentRatio ~= nil then
        lines[#lines + 1] = U.text("ff_report_cr", string.format("%.2f", ratios.currentRatio))
    end
    if ratios.termDebtCoverage ~= nil then
        lines[#lines + 1] = U.text("ff_report_tdc", string.format("%.2f", ratios.termDebtCoverage))
    elseif not ratios.hasIncomeHistory then
        lines[#lines + 1] = U.text("ff_report_noHistory", R.get("credit.minHistoryMonths", 6))
    end
    lines[#lines + 1] = U.text("ff_report_income", U.money(evaluation.snapshot.income12 or 0), U.money(evaluation.snapshot.opex12 or 0), evaluation.snapshot.historyMonths or 0)
    for _, productId in ipairs(UI.PRODUCTS) do
        if R.isProductEnabled(productId) then
            local term = R.get("loans.product." .. productId .. ".defaultTermYears", 1)
            local quote = FF.Bank.quote(id, productId, term, nil)
            lines[#lines + 1] = U.text("ff_report_limit", U.text("ff_product_" .. productId), U.money(quote.limit), U.percent(quote.rate))
        end
    end
    if farm.review ~= nil then
        lines[#lines + 1] = U.text("ff_report_review", farm.review.cropYear or 0, farm.review.score or 0, farm.review.grade or "?")
    end
    if FF.Inputs.isEnabled() then
        local available, limit, balance = FF.Inputs.getAvailable(id)
        lines[#lines + 1] = U.text("ff_report_account", UI.accountName(), U.money(balance), U.money(limit))
    end
    local line = FF.Line.get(farm)
    if line ~= nil then
        lines[#lines + 1] = U.text("ff_report_line", U.money(line.balance), U.money(line.limit), U.percent(FF.Line.getRate(farm)))
    end
    local share = farm.cropShare
    if share ~= nil and #(share.stats or {}) > 0 then
        lines[#lines + 1] = ""
        lines[#lines + 1] = U.text("ff_report_shareHeader")
        for _, row in ipairs(share.stats) do
            if row.cropYear == FF.state.cropYear or row.cropYear == FF.state.cropYear - 1 then
                lines[#lines + 1] = U.text("ff_report_shareRow", row.name or "?", row.cropYear or 0, UI.fillTypeTitle(row.fillType),
                    UI.volume(row.harvested or 0), UI.volume(row.landowner or 0), UI.volume(row.delivered or 0),
                    UI.volume(row.settled or 0), U.money((row.deliveredValue or 0) + (row.settledValue or 0)))
            end
        end
        for _, row in ipairs(share.inputs or {}) do
            if row.cropYear == FF.state.cropYear then
                lines[#lines + 1] = U.text("ff_report_shareInputs", U.money(row.cost or 0), U.money(row.credit or 0))
            end
        end
    end
    if #(FF.state.importReport or {}) > 0 then
        lines[#lines + 1] = ""
        lines[#lines + 1] = U.text("ff_report_importHeader")
        for _, line in ipairs(FF.state.importReport) do
            lines[#lines + 1] = "- " .. line
        end
    end
    return table.concat(lines, "\n")
end

function UI.openCreditReport()
    local id = farmId()
    if not isValidFarm(id) then
        return
    end
    InfoDialog.show(UI.buildCreditReport(id))
    if FF.state ~= nil then
        FF.state.importReportSeen = true
        FF.refreshUi()
    end
end

-- Region ---------------------------------------------------------------------------

function UI.openRegion()
    local regions = R.listSelectable()
    if #regions == 0 then
        return
    end
    local texts, state = {}, 1
    for index, regionId in ipairs(regions) do
        texts[index] = R.getName(regionId)
        if regionId == R.getActiveId() then
            state = index
        end
    end
    FFOptionsDialog.show({
        title = U.text("ff_dialog_regionTitle"),
        rows = {{label = U.text("ff_label_region"), texts = texts, state = state}},
        onChange = function(states)
            local region = R.regions[regions[states[1]]]
            local sources = region ~= nil and region.values.sources or ""
            return U.text("ff_region_info", sources or ""), true
        end,
        onConfirm = function(states)
            FF.requestAction("setRegion", {regionId = regions[states[1]]})
        end
    })
end

-- The menu page ------------------------------------------------------------------

FFMenuFrame = {}
FFMenuFrame._mt = Class(FFMenuFrame, TabbedMenuFrameElement)

FFMenuFrame.CONTROLS = {
    "scoreText", "ratioText", "marketText", "totalsText", "warningText", "contractList", "emptyText"
}

function FFMenuFrame.new()
    local self = FFMenuFrame:superClass().new(nil, FFMenuFrame._mt)
    self.name = "ffMenuFrame"
    self.rows = {}
    self.selectedIndex = -1

    self.btnBack = {inputAction = InputAction.MENU_BACK}
    self.btnNewLoan = {
        text = U.text("ff_button_newLoan"),
        inputAction = InputAction.MENU_EXTRA_1,
        callback = function()
            UI.openNewLoan()
        end
    }
    self.btnAction = {
        text = U.text("ff_button_pay"),
        inputAction = InputAction.MENU_ACTIVATE,
        disabled = true,
        callback = function()
            self:onActionSelected()
        end
    }
    self.btnReport = {
        text = U.text("ff_button_report"),
        inputAction = InputAction.MENU_EXTRA_2,
        callback = function()
            UI.openCreditReport()
        end
    }
    self.btnRegion = {
        text = U.text("ff_button_region"),
        inputAction = InputAction.MENU_CANCEL,
        callback = function()
            UI.openRegion()
        end
    }
    self:setMenuButtonInfo({self.btnBack, self.btnNewLoan, self.btnAction, self.btnReport, self.btnRegion})
    return self
end

function FFMenuFrame:copyAttributes(src)
    FFMenuFrame:superClass().copyAttributes(self, src)
end

function FFMenuFrame:onGuiSetupFinished()
    FFMenuFrame:superClass().onGuiSetupFinished(self)
    if self.contractList ~= nil then
        self.contractList:setDataSource(self)
        self.contractList:setDelegate(self)
    end
end

function FFMenuFrame:onFrameOpen()
    FFMenuFrame:superClass().onFrameOpen(self)
    FF.openFrame = self
    self:updateContent()
end

function FFMenuFrame:onFrameClose()
    FFMenuFrame:superClass().onFrameClose(self)
    if FF.openFrame == self then
        FF.openFrame = nil
    end
end

local function loanStatus(loan)
    if loan.status == "default" then
        return U.text("ff_status_default")
    end
    if (loan.lateMonths or 0) > 0 then
        return U.text("ff_status_late", loan.lateMonths)
    end
    return U.text("ff_status_monthsLeft", loan.monthsLeft or 0)
end

local function landStatus(contract)
    if contract.endCropYear ~= nil then
        local key = "ff_status_ending_" .. (contract.noticeBy or "farm")
        local whenKey = contract.endCropYear <= FF.state.cropYear and "ff_notice_thisYear" or "ff_notice_nextYear"
        return U.text(key, U.text(whenKey))
    end
    return U.text("ff_status_renews")
end

function FFMenuFrame:buildRows(id)
    local rows = {}
    local farm = FF.state ~= nil and FF.Bank.getFarm(id, false) or nil
    if farm == nil then
        return rows
    end
    for _, loanId in ipairs(U.sortedKeys(farm.loans)) do
        local loan = farm.loans[loanId]
        rows[#rows + 1] = {
            kind = "loan",
            ref = loan,
            type = U.text("ff_product_" .. (loan.productId or "imported")),
            item = loan.label or U.text("ff_source_" .. (loan.source or "ff")),
            amount = U.money(loan.balance),
            rate = U.percent(loan.rate),
            payment = U.text("ff_perMonth", U.money(loan.payment)),
            status = loanStatus(loan)
        }
    end
    for _, contractId in ipairs(U.sortedKeys(farm.land)) do
        local contract = farm.land[contractId]
        local row = {
            kind = "land",
            ref = contract,
            type = U.text(contract.kind == "in" and "ff_type_rentIn" or "ff_type_rentOut"),
            item = contract.name or tostring(contract.farmlandId),
            amount = U.text("ff_perYear", U.money(contract.annualRent)),
            rate = "",
            payment = "",
            status = landStatus(contract)
        }
        if contract.leaseType == "share" then
            row.type = U.text("ff_type_shareIn")
            row.amount = U.text("ff_amount_share", math.floor((contract.landownerShare or 0) * 100 + 0.5))
            if (contract.inputShare or 0) > 0 then
                row.payment = U.text("ff_amount_inputs", math.floor(contract.inputShare * 100 + 0.5))
            end
        end
        rows[#rows + 1] = row
    end
    for _, leaseId in ipairs(U.sortedKeys(farm.leases or {})) do
        local lease = farm.leases[leaseId]
        if lease.status == "active" or lease.status == "awaitingVehicle" then
            rows[#rows + 1] = {
                kind = "lease",
                ref = lease,
                type = U.text("ff_type_lease"),
                item = lease.name or "?",
                amount = U.text("ff_lease_residualShort", U.money(lease.residual)),
                rate = U.percent(lease.rate),
                payment = U.text("ff_perMonth", U.money(lease.payment)),
                status = (lease.monthsLeft or 0) > 0 and U.text("ff_status_monthsLeft", lease.monthsLeft) or U.text("ff_status_leaseEnded")
            }
        end
    end
    local line = FF.Line.get(farm)
    if line ~= nil then
        rows[#rows + 1] = {
            kind = "line",
            ref = line,
            type = U.text("ff_product_line"),
            item = U.text("ff_line_limit", U.money(line.limit)),
            amount = U.money(line.balance),
            rate = U.percent(FF.Line.getRate(farm)),
            payment = line.balance > 0 and U.text("ff_perMonth", U.money(line.balance * FF.Line.getRate(farm) / 12)) or "",
            status = U.text(line.cleanedThisYear and "ff_status_lineClean" or "ff_status_lineMustClean", UI.periodName(R.get("line.cleanUpPeriod", 10)))
        }
    end
    if FF.Inputs.isEnabled() and not FF.blocked.bank then
        local account = FF.Inputs.getAccount(farm)
        local balance, pastDue = FF.Inputs.getBalance(farm)
        local status
        if pastDue > 0 then
            status = U.text("ff_status_accountPastDue")
        else
            status = U.text(account.autoCharge and "ff_status_accountAuto" or "ff_status_accountManual",
                UI.periodName(R.get("inputs.account.dueDatePeriod", 10)))
        end
        rows[#rows + 1] = {
            kind = "account",
            ref = account,
            type = U.text("ff_type_inputAccount"),
            item = UI.accountName(),
            amount = U.money(balance),
            rate = pastDue > 0 and U.percent(FF.Inputs.getPastDueRate()) or "0%",
            payment = "",
            status = status
        }
    end
    local held = FF.CropShare.getHeld(id)
    local sellBy = UI.periodName(R.get("land.cropShare.sellByPeriod", 6))
    for _, fillType in ipairs(U.sortedKeys(held)) do
        local entry = held[fillType]
        rows[#rows + 1] = {
            kind = "grain",
            ref = {fillType = fillType, liters = entry.liters, value = entry.value},
            type = U.text("ff_type_landownerGrain"),
            item = UI.fillTypeTitle(fillType),
            amount = UI.volume(entry.liters),
            rate = "",
            payment = U.money(entry.value),
            status = U.text("ff_status_sellBy", sellBy)
        }
    end
    return rows
end

function UI.fillTypeTitle(fillTypeName)
    local fillType = g_fillTypeManager ~= nil and g_fillTypeManager:getFillTypeByName(fillTypeName) or nil
    if fillType ~= nil and fillType.title ~= nil then
        return fillType.title
    end
    return tostring(fillTypeName)
end

function UI.volume(liters)
    if g_i18n ~= nil and g_i18n.formatVolume ~= nil then
        local ok, text = pcall(g_i18n.formatVolume, g_i18n, liters, 0)
        if ok and text ~= nil then
            return text
        end
    end
    return string.format("%d l", math.floor((liters or 0) + 0.5))
end

function UI.openSettleShare(grain)
    YesNoDialog.show(function(_, yes)
        if yes then
            FF.requestAction("settleShare", {fillType = grain.fillType})
        end
    end, UI, U.text("ff_confirm_settleShare", UI.volume(grain.liters), UI.fillTypeTitle(grain.fillType), U.money(grain.value)),
        U.text("ff_dialog_settleTitle"))
end

function FFMenuFrame:updateContent()
    local id = farmId()
    if FF.state == nil or not isValidFarm(id) then
        self.rows = {}
        if self.scoreText ~= nil then
            self.scoreText:setText(U.text("ff_msg_noFarm"))
        end
        if self.contractList ~= nil then
            self.contractList:reloadData()
        end
        return
    end

    local evaluation = FF.Bank.evaluate(id)
    local ratios = evaluation.ratios
    local snapshot = evaluation.snapshot

    if self.scoreText ~= nil then
        self.scoreText:setText(U.text("ff_header_score", R.get("credit.label", "Credit score"), evaluation.score, evaluation.grade))
    end
    if self.ratioText ~= nil then
        local tdc = ratios.termDebtCoverage ~= nil and string.format("%.2f", ratios.termDebtCoverage) or "-"
        local cr = ratios.currentRatio ~= nil and string.format("%.2f", ratios.currentRatio) or "-"
        self.ratioText:setText(U.text("ff_header_ratios", U.percent(ratios.debtToAsset, 0), cr, tdc))
    end
    if self.marketText ~= nil then
        local trendKey = "ff_trend_" .. tostring(FF.state.rateTrend or 0)
        local market = U.text("ff_header_market", U.percent(FF.state.baseRate or 0), U.text(trendKey), R.getName(R.getActiveId()))
        local promos = {}
        for _, brand in ipairs(U.sortedKeys(FF.state.promos or {})) do
            local promo = FF.Equipment.getPromo(brand)
            if promo ~= nil then
                promos[#promos + 1] = U.text("ff_promo_item", brand, promo.months)
            end
        end
        if #promos > 0 then
            market = market .. U.text("ff_header_promos", table.concat(promos, ", "))
        end
        self.marketText:setText(market)
    end
    if self.totalsText ~= nil then
        local totals = U.text("ff_header_totals", U.money(ratios.totalDebt), U.money(snapshot.monthlyPayments or 0), U.money(snapshot.yearlyRent or 0))
        local heldValue = FF.CropShare.getHeldValue(id)
        if heldValue > 0 then
            totals = totals .. U.text("ff_header_held", U.money(heldValue))
        end
        self.totalsText:setText(totals)
    end
    if self.warningText ~= nil then
        local warning = ""
        if FF.anyBlocked() then
            warning = U.text("ff_warning_conflicts", FF.getConflictText("bank", "rentIn", "rentOut"))
        elseif #(FF.state.importReport or {}) > 0 and not FF.state.importReportSeen then
            warning = U.text("ff_warning_imported")
        end
        self.warningText:setText(warning)
    end

    self.rows = self:buildRows(id)
    if self.emptyText ~= nil then
        self.emptyText:setVisible(#self.rows == 0)
    end
    if self.contractList ~= nil then
        self.contractList:reloadData()
    end
    self:updateButtons()
end

function FFMenuFrame:updateButtons()
    local row = self.rows[self.selectedIndex]
    if row == nil then
        self.btnAction.disabled = true
        self.btnAction.text = U.text("ff_button_pay")
    elseif row.kind == "loan" then
        self.btnAction.disabled = FF.blocked.bank
        self.btnAction.text = U.text("ff_button_pay")
    elseif row.kind == "grain" then
        self.btnAction.disabled = false
        self.btnAction.text = U.text("ff_button_settleShare")
    elseif row.kind == "line" or row.kind == "account" or row.kind == "lease" then
        self.btnAction.disabled = false
        self.btnAction.text = U.text("ff_button_manage")
    else
        -- Notice on an existing Farm Finance lease always works
        self.btnAction.disabled = false
        self.btnAction.text = U.text(row.ref.endCropYear ~= nil and "ff_button_cancelNotice" or "ff_button_notice")
    end
    self.btnNewLoan.disabled = FF.blocked.bank
    self.btnRegion.disabled = not FF.canChangeRegion()
    self:setMenuButtonInfoDirty()
end

function FFMenuFrame:onActionSelected()
    local row = self.rows[self.selectedIndex]
    if row == nil then
        return
    end
    if row.kind == "loan" then
        UI.openPayment(row.ref)
    elseif row.kind == "grain" then
        UI.openSettleShare(row.ref)
    elseif row.kind == "line" then
        UI.openLine(row.ref)
    elseif row.kind == "lease" then
        UI.openLease(row.ref)
    elseif row.kind == "account" then
        UI.openInputAccount()
    else
        UI.openNotice(row.ref)
    end
end

function FFMenuFrame:getNumberOfSections()
    return 1
end

function FFMenuFrame:getNumberOfItemsInSection(list, section)
    return #self.rows
end

function FFMenuFrame:getTitleForSectionHeader(list, section)
    return ""
end

function FFMenuFrame:populateCellForItemInSection(list, section, index, cell)
    local row = self.rows[index]
    if row == nil then
        return
    end
    cell:getAttribute("type"):setText(row.type)
    cell:getAttribute("item"):setText(row.item)
    cell:getAttribute("amount"):setText(row.amount)
    cell:getAttribute("rate"):setText(row.rate)
    cell:getAttribute("payment"):setText(row.payment)
    cell:getAttribute("status"):setText(row.status)
end

function FFMenuFrame:onListSelectionChanged(list, section, index)
    self.selectedIndex = index
    self:updateButtons()
end
