-- Public snapshot and validated settings interface, exposed through mission.
-- Snapshot tables never alias internal state. Consumers own long-term history.
RSPlacementAPI = {version=2,modVersion="2.5.0.1",listeners={},nextToken=0}
local A=RSPlacementAPI
function A.ensureIdentity(vehicle)
    local s=vehicle.spec_rsPlacement
    if vehicle.uniqueId and s.id~=vehicle.uniqueId then
        s.id=vehicle.uniqueId
        for _,row in ipairs(s.records) do row.vehicleId=s.id end
    end
end
function A.copy(v)
    if type(v)~="table" then return v end
    local out={};for k,x in pairs(v) do out[k]=A.copy(x) end;return out
end
function A.getCapabilities(vehicle)
    local s=vehicle and vehicle.spec_rsPlacement
    if not s or not s.enabled then return nil,"unsupportedVehicle" end
    A.ensureIdentity(vehicle)
    return A.copy(s.profile)
end
function A.getAcceptedWorkAreas(vehicle,area)
    local s=vehicle and vehicle.spec_rsPlacement
    if not s or not s.profile.rowDrive or s.acceptedWorkArea~=area or s.acceptedTimeMs~=(g_time or 0) then return nil end
    return A.copy(s.acceptedRows or {})
end
function A.getSnapshot(vehicle)
    local s=vehicle and vehicle.spec_rsPlacement
    if not s or not s.enabled then return nil,"unsupportedVehicle" end
    A.ensureIdentity(vehicle)
    local sow=vehicle.spec_sowingMachine
    local fruit=sow and g_fruitTypeManager:getFruitTypeByIndex(sow.seeds[sow.currentSeed])
    local out={schemaVersion=1,vehicleId=s.id,vehicleName=vehicle:getFullName(),
        configuration=vehicle.configFileName,revision=s.revision,kind=s.profile.kind,
        capabilities=A.copy(s.profile),crop=fruit and fruit.name,
        settingsSource="operatorEntered",settings=A.copy(s.settings),
        loggingAvailable=s.profile.settingsLogging==true,measurements={},authoritative=vehicle.isServer==true,
        counters=A.copy(s.counters)}
    local calibration=RSPlacement.getCalibration(vehicle)
    out.application=A.copy(calibration)
    local last=s.lastSample
    local fresh=last and last.settingsRevision==s.revision and (g_time or 0)-(last.timeMs or -1e12)>=0 and (g_time or 0)-(last.timeMs or -1e12)<=2000
    local _,controls=RSControlModel.resolve(s.profile,s.settings,fruit and fruit.name,nil)
    out.controls=A.copy(fresh and last.controls or controls)
    out.controls.sampleFresh=fresh==true
    out.controls.adjustable={}
    for name in pairs(RSPlacementModel.limits) do out.controls.adjustable[name]=RSControlModel.access(s.profile,name) end
    if fresh and s.profile.soilSensor then out.soilMeasurements=A.copy(last.soil);out.soilMeasurements.source='simulatedSoilSensor' end
    if fresh and last.rows and s.profile.rowDrive then
        out.rows=A.copy(last.rows)
        if not s.profile.seedMonitor then for _,row in ipairs(out.rows) do row.skipsPercent=nil;row.doublesPercent=nil;row.actualRatePerAcre=nil end end
    end
    if calibration.kgPerLiter then out.nominalLitersPerHa=RSSeedRate.litersForArea(10000,calibration.ratePerAcre,calibration.unit,calibration.seedsPerPound,calibration.kgPerLiter) end
    local src,index=RealisticSeederUtil.getSeedSource(vehicle,sow,RealisticSeederUtil.getSpecByName(vehicle,"realisticSeeder"))
    if src and index then
        local fill=g_fillTypeManager:getFillTypeByIndex(src:getFillUnitFillType(index))
        out.seed={fillType=fill and fill.name,liters=src:getFillUnitFillLevel(index),sourceVehicle=src:getFullName(),sourceVehicleId=src.uniqueId,fillUnitIndex=index}
    end
    if s.profile.seedMonitor and s.lastSample then
        local m=s.lastSample
        out.measurements={skipsPercent=m.skipsPercent,doublesPercent=s.profile.kind=="planter" and m.doublesPercent or nil,
            distributionCvPercent=s.profile.kind=="drill" and m.distributionCvPercent or nil,
            speedKmh=m.speedKmh,source="simulatedSeedMonitor",timeMs=m.timeMs,settingsRevision=m.settingsRevision}
    end
    -- Mechanical target depth is never presented as sensor-measured depth.
    if s.profile.depthSensor and s.lastSample then out.measurements.depthMm=s.lastSample.actualDepthMm end
    -- Model output is separate from hardware-gated sensor measurements.
    if s.lastSample and s.lastSample.population then
        out.estimates={source="placementPopulationModel",timeMs=s.lastSample.timeMs,
            settingsRevision=s.lastSample.settingsRevision,soil=A.copy(s.lastSample.soil),
            population=A.copy(s.lastSample.population),sidewallRiskPercent=s.lastSample.sidewallRiskPercent,
            geometryFallback=s.lastSample.geometryFallback==true}
    end
    if fresh and s.profile.seedMonitor and last.deliveryScale then out.measurements.actualRatePerAcre=calibration.ratePerAcre*last.deliveryScale end
    out.presets=A.getPresets(vehicle)
    out.inspection=A.getInspection(vehicle)
    return out
end
function A.getPresets(vehicle)
    local s=vehicle and vehicle.spec_rsPlacement
    if not s or not s.enabled then return {} end
    local result={};local names={}
    for name in pairs(RSPlacement.seedCalibrations) do names[#names+1]=name end;table.sort(names)
    for _,name in ipairs(names) do
        local crop=g_fruitTypeManager and type(g_fruitTypeManager.getFruitTypeByName)=='function' and g_fruitTypeManager:getFruitTypeByName(name)
        if crop then
            local rate=RSPlacement.seedCalibrations[name];local depth=RSPlacementModel.crops[name]
            result[#result+1]={crop=name,label=crop.title or name,settings={depthMm=depth and (depth[1]+depth[2])/2 or 40,
                ratePerAcre=s.profile.kind=='planter' and rate[2] or rate[1],pressurePercent=50,closingPercent=50}}
        end
    end
    return result
end
function A.getInspection(vehicle)
    local s=vehicle and vehicle.spec_rsPlacement
    if not s or not s.enabled then return {available=false,reason='Unsupported implement'} end
    local sample=s.lastSample
    if not sample then return {available=s.inspection~=nil and s.inspection~='',text=s.inspection,source='savedManualInspection'} end
    return {available=true,source='simulatedManualInspection',text=s.inspection,
        crop=sample.crop,ageSeconds=math.max(0,((g_time or 0)-(sample.timeMs or 0))/1000),
        depthMm=sample.actualDepthMm,skipsPercent=sample.skipsPercent,doublesPercent=sample.doublesPercent,
        seedContactPercent=sample.seedContactPercent,distributionCvPercent=sample.distributionCvPercent}
end
-- A single server turn validates every edit before any value changes. These four
-- settings have no external actuator failure path. Seed identity is never changed.
function A.applySettings(vehicle,revision,changes)
    local s=vehicle and vehicle.spec_rsPlacement
    if not s or not s.enabled or not vehicle.isServer then return false,'Authoritative supported implement required' end
    if revision~=s.revision then return false,'Settings changed; refresh before applying' end
    if type(changes)~='table' then return false,'Invalid settings request' end
    local keys={};local supported={ratePerAcre=true,depthMm=true,pressurePercent=true,closingPercent=true}
    for name,value in pairs(changes) do
        if not supported[name] or not RSPlacementModel.finite(value) then return false,'Unsupported setting' end
        local limit=RSPlacementModel.limits[name]
        if value<limit[1] or value>limit[2] or (name=='ratePerAcre' and (value<=0 or (s.profile.kind=='drill' and value>1000))) then return false,'Setting outside allowed range' end
        local allowed,reason=RSControlModel.allowed(s.profile,name,value)
        if not allowed then return false,reason end
        if not RSControlModel.cabAllowed(s.profile,name) and (vehicle:getLastSpeed()>0.5 or vehicle:getIsTurnedOn()) then return false,'Stop and switch off before adjusting mechanical settings' end
        keys[#keys+1]=name
    end
    if #keys==0 then return false,'No changes requested' end
    table.sort(keys)
    for _,name in ipairs(keys) do RSPlacement.setSetting(vehicle,name,changes[name]) end
    return true,'Applied',s.revision
end
function A.getRecords(vehicle,afterSequence)
    local s=vehicle and vehicle.spec_rsPlacement
    if not s or not s.enabled then return nil,"unsupportedVehicle" end
    A.ensureIdentity(vehicle)
    if not s.profile.settingsLogging then return nil,"loggingNotEquipped" end
    if afterSequence~=nil and (not RSPlacementModel.finite(afterSequence) or afterSequence<0 or afterSequence%1~=0) then return nil,"invalidCursor" end
    local rows={};for _,row in ipairs(s.records) do if row.sequence>(afterSequence or 0) then rows[#rows+1]=A.copy(row) end end
    return {schemaVersion=1,vehicleId=s.id,records=rows,oldestSequence=s.records[1] and s.records[1].sequence or s.sequence+1,
        latestSequence=s.sequence,resetRequired=afterSequence~=nil and afterSequence>s.sequence,
        truncated=afterSequence~=nil and #s.records>0 and afterSequence<s.records[1].sequence-1}
end
function A.subscribe(callback)
    if type(callback)~="function" then return nil,"callbackRequired" end
    A.nextToken=A.nextToken+1;A.listeners[A.nextToken]=callback;return A.nextToken
end
function A.unsubscribe(token) A.listeners[token]=nil end
function A.publish(vehicle,event,record)
    local s=vehicle.spec_rsPlacement
    if not s.profile.settingsLogging then return end
    local tokens={};for token in pairs(A.listeners) do tokens[#tokens+1]=token end
    for _,token in ipairs(tokens) do
        local callback=A.listeners[token]
        if callback then local ok,err=pcall(callback,event,A.copy(record),vehicle)
            if not ok then Logging.warning("RealisticSeeder API listener failed: %s",tostring(err)) end
        end
    end
    if FieldPathLink then
        if not A.link then A.link=FieldPathLink.connect({module="RealisticSeederPlacement",version=A.modVersion,events={"seed.settings","seed.placement"}}) end
        A.link:emit(event,A.copy(record))
    end
end
