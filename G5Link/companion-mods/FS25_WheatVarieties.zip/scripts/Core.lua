-- All globals in this namespace live in this mod's sandbox.
WheatVarieties = {
    VERSION = "0.1.0.3",
    directory = g_currentModDirectory or "",
    modName = g_currentModName or "FS25_WheatVarieties",
    hooks = {},
    definitions = {},
    state = { phase = "notLoaded", errors = {}, fruits = {}, fills = {} }
}
local WV = WheatVarieties

function WV.log(formatString, ...)
    print("[WheatVarieties] " .. string.format(formatString, ...))
end

function WV.fail(message)
    WV.state.errors[#WV.state.errors + 1] = tostring(message)
    WV.state.phase = "failed"
    WV.log("ERROR: %s", tostring(message))
end

function WV.copy(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, item in pairs(value) do result[key] = WV.copy(item) end
    return result
end

function WV.contains(array, value)
    for _, item in ipairs(array or {}) do
        if item == value then return true end
    end
    return false
end

function WV.sortedKeys(values)
    local keys = {}
    for key in pairs(values) do keys[#keys + 1] = key end
    table.sort(keys)
    return keys
end

function WV.pack(...)
    return { n = select("#", ...), ... }
end

-- A wrapper stays inert when a later mod wraps it, so cleanup never removes
-- somebody else's hook. Reinstallation cannot accumulate active callbacks.
function WV.hook(target, method, callback, required)
    if target == nil or type(target[method]) ~= "function" then
        if required then error("Required engine method missing: " .. method) end
        WV.log("Optional adapter unavailable: %s", method)
        return
    end
    local entry = { target = target, method = method, original = target[method], active = true }
    entry.wrapper = function(object, ...)
        if entry.active then return callback(object, entry.original, ...) end
        return entry.original(object, ...)
    end
    target[method] = entry.wrapper
    WV.hooks[#WV.hooks + 1] = entry
end

function WV.unhookAll()
    for index = #WV.hooks, 1, -1 do
        local hook = WV.hooks[index]
        hook.active = false
        if hook.target[hook.method] == hook.wrapper then
            hook.target[hook.method] = hook.original
        end
    end
    WV.hooks = {}
end

function WV.try(callback, ...)
    local ok, result = pcall(callback, ...)
    if not ok then WV.fail(result) end
    return ok, result
end
