local WV = WheatVarieties
local DC = {}
WV.DoubleCrop = DC

local function stateIndex(fruit, name)
    local index = fruit:getGrowthStateByName(name)
    assert(type(index) == "number" and index > 0, "SOYBEAN state unavailable: " .. name)
    return index
end

-- Period updates take effect in the following month. Follow the map's own
-- June cohort first, including custom harvest states and their yield scales.
function DC.trace(fruit, periods)
    local state = stateIndex(fruit, "invisible")
    for period = 4, 8 do
        state = periods[period].growthMapping[state] or state
        if fruit:getIsHarvestReady(state) then return period + 1, state end
    end
end

function DC.plan(fruit)
    assert(fruit and fruit.growthDataSeasonal, "SOYBEAN seasonal data unavailable")
    local original = fruit.growthDataSeasonal.periods
    for period = 1, 12 do
        assert(original and original[period] and type(original[period].growthMapping) == "table",
            "SOYBEAN seasonal period unavailable: " .. period)
    end
    local periods = WV.copy(original)
    local harvestPeriod, harvestState = DC.trace(fruit, periods)
    local mode = "map calendar"
    if not harvestPeriod then
        -- Minimal June-to-November route for the standard soybean state names.
        -- Resolve indices from the loaded map; never assume dead/cut/ready IDs.
        local names = {"invisible", "greenSmall", "greenMiddle2", "greenBig", "greenBig2"}
        local indices = {}
        for i, name in ipairs(names) do indices[i] = stateIndex(fruit, name) end
        local ready = fruit:getGrowthStateByName("harvestReadyDC")
        if not ready or ready <= 0 or not fruit:getIsHarvestReady(ready) then
            ready = stateIndex(fruit, "harvestReady")
        end
        assert(fruit:getIsHarvestReady(ready), "SOYBEAN harvest state is not harvestable")
        indices[6] = ready
        for period = 4, 8 do
            periods[period].growthMapping[indices[period - 3]] = indices[period - 2]
        end
        harvestPeriod, harvestState = DC.trace(fruit, periods)
        assert(harvestPeriod == 9, "SOYBEAN June cohort cannot mature by November")
        mode = "June growth extension"
    end
    periods[4].plantingAllowed = true
    periods[harvestPeriod].isHarvestable = true
    return periods, mode, harvestPeriod, harvestState
end

function DC.apply()
    if WV.state.doubleCrop then return end
    local fruit = g_fruitTypeManager and g_fruitTypeManager:getFruitTypeByName("SOYBEAN")
    -- Validate a complete plan before touching live data. Unsupported layouts
    -- leave the original soybean calendar intact and do not disable the wheat.
    local ok, plan, mode, harvestPeriod, harvestState = pcall(DC.plan, fruit)
    if not ok then
        WV.state.doubleCrop = {ready = false, reason = tostring(plan)}
        WV.log("Soybean double cropping unavailable: %s", tostring(plan))
        return
    end
    for period = 1, 12 do
        local live = fruit.growthDataSeasonal.periods[period]
        for state, target in pairs(plan[period].growthMapping) do live.growthMapping[state] = target end
        live.plantingAllowed = plan[period].plantingAllowed
        live.isHarvestable = plan[period].isHarvestable
    end
    WV.state.doubleCrop = {ready = true, mode = mode, harvestPeriod = harvestPeriod, harvestState = harvestState}
    WV.log("Soybean double cropping ready: June planting; %s; first harvest period=%d state=%s. Map yields retained.",
        mode, harvestPeriod, fruit:getGrowthStateName(harvestState))
end
