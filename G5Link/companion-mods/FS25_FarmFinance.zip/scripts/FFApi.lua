-- FS25_FarmFinance - public API for other mods (see API.md in this mod).
--
-- Find it from another mod with:
--     local api = g_currentMission ~= nil and g_currentMission.farmFinanceAPI or nil
-- (also reachable as FarmFinanceAPI in the global table, when the game allows it).
-- Check api ~= nil and api.isReady() before use. Calls that move money or
-- change state work on the server only and return false, "notServer" on
-- clients. Read calls work everywhere (clients see the synced state).

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util

FarmFinanceAPI = FarmFinanceAPI or {}
local API = FarmFinanceAPI

API.VERSION = "1.0.0"
API.listeners = API.listeners or {}

local function isReady()
    return FF.state ~= nil
end

local function toFillTypeName(fillType)
    if type(fillType) == "number" then
        if g_fillTypeManager ~= nil then
            return g_fillTypeManager:getFillTypeNameByIndex(fillType)
        end
        return nil
    end
    if type(fillType) == "string" then
        return string.upper(fillType)
    end
    return nil
end

local function copy(value)
    return U.deepCopy(value)
end

-- General --------------------------------------------------------------------------

-- Returns API version and mod version.
function API.getVersion()
    return API.VERSION, FF.VERSION
end

-- True once Farm Finance has loaded the savegame (server) or received the
-- server's state (client).
function API.isReady()
    if not isReady() then
        return false
    end
    if FF.isServer() then
        return FF.loaded == true
    end
    return true
end

function API.isServer()
    return FF.isServer()
end

-- True when a conflicting finance mod switched the bank features off.
function API.isBankActive()
    return FF.blocked == nil or not FF.blocked.bank
end

-- Credit -------------------------------------------------------------------------------

-- score (300-850), grade ("A".."E")
function API.getCreditScore(farmId)
    if not isReady() then
        return nil, nil
    end
    local evaluation = FF.Bank.evaluate(farmId)
    return evaluation.score, evaluation.grade
end

-- Input purchases --------------------------------------------------------------------

function API.isInputFillType(fillType)
    return FF.Inputs.isInputFillType(toFillTypeName(fillType))
end

-- Adds a fill type (name) that counts as a farm input for this session.
function API.registerInputFillType(fillTypeName)
    return FF.Inputs.registerFillType(fillTypeName)
end

-- Cash discount for inputs bought right now (0..1), from the region's
-- early-pay schedule.
function API.getEarlyPayDiscount()
    if not isReady() then
        return 0
    end
    return FF.Inputs.getEarlyPayDiscount()
end

-- Snapshot of a farm's input account:
-- {enabled, autoCharge, limit, balance, available, pastDue, dueCropYear,
--  dueDatePeriod, pastDueRate, earlyPayDiscount}
function API.getInputAccount(farmId)
    if not isReady() then
        return nil
    end
    local farm = FF.Bank.getFarm(farmId)
    local account = FF.Inputs.getAccount(farm)
    local balance, pastDue = FF.Inputs.getBalance(farm)
    local available, limit = FF.Inputs.getAvailable(farmId)
    return {
        enabled = FF.Inputs.isEnabled() and API.isBankActive(),
        autoCharge = account.autoCharge,
        limit = limit,
        balance = balance,
        available = available,
        pastDue = pastDue,
        dueCropYear = FF.Inputs.getDueCropYear(),
        dueDatePeriod = FF.Region.get("inputs.account.dueDatePeriod", 10),
        pastDueRate = FF.Inputs.getPastDueRate(),
        earlyPayDiscount = FF.Inputs.getEarlyPayDiscount()
    }
end

-- Charge an input sale your mod makes to a farm (seed at your co-op, a
-- liquid fertilizer fill station, chemicals from your silo yard...).
-- Do NOT take the money yourself: Farm Finance books the expense and
-- decides how it is paid.
--   amount : total price (game money)
--   info (optional table):
--     fillType       : fill type name or index (for the expense category)
--     liters         : quantity, for the record
--     description    : text shown on the account, e.g. "Seed - Miller Co-op"
--     moneyType      : a MoneyType to book the expense under
--                      (default PURCHASE_SEEDS for SEEDS, else PURCHASE_FERTILIZER)
--     allowAccount   : false = never put it on the account (default true)
--     applyDiscount  : false = no early-pay discount when paid cash (default true)
-- Returns ok, method ("account" | "cash"), value (amount booked on the
-- account, or the discount refunded for cash), reason (when not ok).
-- When Farm Finance's bank is off, the farm is simply charged cash.
function API.payForInputs(farmId, amount, info)
    if not isReady() then
        return false, nil, 0, "notReady"
    end
    if not FF.isServer() then
        return false, nil, 0, "notServer"
    end
    amount = tonumber(amount) or 0
    if amount <= 0 or farmId == nil or farmId <= 0 then
        return false, nil, 0, "invalid"
    end
    info = info or {}
    local fillTypeName = toFillTypeName(info.fillType)
    local moneyType = info.moneyType
    if moneyType == nil and FF.env ~= nil and FF.env.inputMoneyType ~= nil then
        moneyType = FF.env.inputMoneyType(fillTypeName)
    end

    -- Book the expense (this is the purchase itself).
    FF.Inputs.suppressPurchaseHook = true
    local ok, err = pcall(function()
        if FF.env ~= nil and FF.env.addMoneyType ~= nil then
            FF.env.addMoneyType(-amount, farmId, moneyType)
        end
    end)
    FF.Inputs.suppressPurchaseHook = false
    if not ok then
        return false, nil, 0, tostring(err)
    end

    if not API.isBankActive() then
        return true, "cash", 0
    end
    local method, value = FF.Inputs.onInputPurchase(farmId, amount, {
        description = info.description,
        allowAccount = info.allowAccount,
        applyDiscount = info.applyDiscount
    })
    API.fire("inputPurchased", farmId, amount, method, value, fillTypeName, info.liters)
    return true, method or "cash", value or 0
end

-- Crop share ---------------------------------------------------------------------------

-- Is this field on a crop-share lease for this farm? Returns bool and the
-- landowner's share (0..1).
function API.isCropShareField(farmId, farmlandId)
    if not isReady() then
        return false, 0
    end
    local contract = FF.CropShare.getShareContract(farmId, farmlandId)
    if contract == nil then
        return false, 0
    end
    return true, contract.landownerShare or 0
end

-- Report a harvest that didn't go through a combine (custom harvesters,
-- yield mods). Returns the landowner's liters.
function API.reportHarvest(farmId, farmlandId, fillType, liters)
    if not isReady() or not FF.isServer() then
        return 0
    end
    return FF.CropShare.onHarvest(farmId, farmlandId, toFillTypeName(fillType), tonumber(liters) or 0)
end

-- Report a grain sale that didn't go through a SellingStation (virtual
-- hauls, contracts, your own sell point). Farm Finance pays the landowner
-- their share of it. Returns landowner liters and value.
function API.reportGrainSale(farmId, fillType, liters, pricePerLiter)
    if not isReady() or not FF.isServer() then
        return 0, 0
    end
    local name = toFillTypeName(fillType)
    local taken, value = FF.CropShare.onSale(farmId, name, tonumber(liters) or 0, tonumber(pricePerLiter))
    if value > 0 and FF.env ~= nil and FF.env.addMoney ~= nil then
        FF.env.addMoney(-value, farmId, "cropShareLandowner")
        API.fire("landownerPaid", farmId, name, taken, value)
    end
    return taken, value
end

-- Report seed, fertilizer or spray used on a field (when your machine
-- doesn't use the base-game seeder or sprayer). Returns the landowner's
-- credit to the farm.
function API.reportInputUse(farmId, farmlandId, cost)
    if not isReady() or not FF.isServer() then
        return 0
    end
    return FF.CropShare.onInputUse(farmId, farmlandId, tonumber(cost) or 0)
end

-- {FILLTYPENAME = {liters, value, oldestCropYear}} of grain the farm holds
-- for landowners.
function API.getLandownerGrain(farmId)
    if not isReady() then
        return {}
    end
    return copy(FF.CropShare.getHeld(farmId))
end

-- Land ----------------------------------------------------------------------------------

-- The Farm Finance lease on a farmland, or nil:
-- {kind = "in"|"out", leaseType = "cash"|"share", farmId, annualRent,
--  landownerShare, inputShare, endCropYear}
function API.getLandContract(farmlandId)
    if not isReady() then
        return nil
    end
    local contract = FF.Land.getContractByFarmland(farmlandId)
    if contract == nil then
        return nil
    end
    return {
        kind = contract.kind,
        leaseType = contract.leaseType or "cash",
        farmId = contract.farmId,
        annualRent = contract.annualRent,
        landownerShare = contract.landownerShare,
        inputShare = contract.inputShare,
        endCropYear = contract.endCropYear
    }
end

-- Region ----------------------------------------------------------------------------------

function API.getRegionId()
    return FF.Region.getActiveId()
end

-- Any region value by key, e.g. "land.rentToValue" (see regions/_base.xml).
function API.getRegionValue(key, default)
    return copy(FF.Region.get(key, default))
end

-- Events ------------------------------------------------------------------------------------
-- "inputPurchased"  (farmId, amount, method, value, fillTypeName, liters)
-- "landownerPaid"   (farmId, fillTypeName, liters, value)
-- "monthProcessed"  (period)

function API.subscribe(eventName, callback, target)
    if type(callback) ~= "function" then
        return false
    end
    API.listeners[eventName] = API.listeners[eventName] or {}
    table.insert(API.listeners[eventName], {callback = callback, target = target})
    return true
end

function API.unsubscribe(eventName, target)
    local list = API.listeners[eventName]
    if list == nil then
        return
    end
    for index = #list, 1, -1 do
        if list[index].target == target then
            table.remove(list, index)
        end
    end
end

function API.fire(eventName, ...)
    for _, listener in ipairs(API.listeners[eventName] or {}) do
        local ok, err
        if listener.target ~= nil then
            ok, err = pcall(listener.callback, listener.target, ...)
        else
            ok, err = pcall(listener.callback, ...)
        end
        if not ok then
            U.warn("API listener for %s failed: %s", tostring(eventName), tostring(err))
        end
    end
end

return API
