REALISTIC SEEDER 2.4.0.0 -- PLACEMENT SETUP

Select the drill or planter, then press RIGHT CTRL + ; (semicolon) to open placement setup.
The binding is named "Seed placement setup / inspection" and can be reassigned
in FS25 controls. Edit settings directly on the main panel and choose Apply changes.
Crop presets load draft starting values without changing the seed in the machine.
Discard / close cancels unapplied edits; save the farm to persist applied changes.

Settings:
  Depth: 5-100 mm.
  Planter application rate: seeds per acre, entered as a number.
  Drill application rate: pounds per acre, entered as a number.
  Seed size: seeds per pound from the bag tag (needed for count-to-volume).
  Opener pressure and closing/packing: 0-100 percent, neutral starting value 50.
  Meter/feed adjustment: 50-150 percent, nominal 100.
  Pressure/delivery percentages are first-version controls, not vacuum or
  hydraulic pressure units. Starting rates and seed sizes are labeled defaults;
  enter the desired rate and actual bag-tag seed size before count-based planting.

Mechanical changes require the machine stopped and switched off. Changes during
work require the matching installed actuator. See README_TECHNOLOGY.txt for staged
cab controls, soil-responsive automation, row controls and their prerequisites.
No rate prescription or GPS automatic row shutoff controller is enabled.

Buy the crop-specific seed you want to plant. Winter wheat seed plants winter
wheat until you empty the machine and load another product. The attached seed
cart remains the seed source for air drills. Native crop calendars still apply.

Drills model distribution/delivery misses. Planters model skips and doubles.
Speed above the implement's rated working speed, wear, depth, pressure and
closing setup affect modeled placement. Inspect the last pass sample through
the setup menu. Inspect last pass includes soil input sources, modeled pressure
targets, sidewall risk, estimated population and placement/population yield potential.

Poor placement and population response produce representative gaps in the crop.
The mask uses one-metre cells clipped to the work area. Existing crop is never
cleared by this module. Correct the setup and sow missed areas again to repair
them where the normal crop calendar/ground rules permit. Rate and doubles affect
real seed consumption. High rates cannot add foliage above native full density.
This is not an individual seed or emergence model.

SEED PER ACRE -- SAME ON EVERY MAP SIZE
The meter uses the implement's sweep in WORLD METRES, then divides by exactly
4046.8564224 square metres per acre. Map size and foliage resolution do not enter
the quantity calculation. Seed weight uses 0.45359237 kg/lb and the actual loaded
fill type's in-game mass per litre. Count-based rates also use entered seeds/lb.
At an identical application rate/calibration/delivery setting, 600 metered acres
use the same amount of seed on a 1x or 16x map. Poor depth/closing does not refund
seed. Mechanical misses/doubles affect actual delivery; weather emergence does not.
Meter-on overlaps consume seed again. "Metered acres" therefore differs from
unique FieldPath coverage. Stationary repeated frames do not keep charging seed.
There is no automatic section shutoff in this first release. Metering off-field
while the lowered implement remains active can waste seed without creating crop.
Sharp turns use the hull of successive work-area positions; unsupported/custom
work-area layouts still require equipment-specific validation.

Settings, metered acres/litres, last inspection and the recent equipped-machine record buffer
save with the vehicle. No new foliage layers or Courtland map edits are needed.

FIELDPATH
Public API v1: g_currentMission.realisticSeederAPI
See docs/PLACEMENT_API_V1.txt and docs/FieldPathPlacementConsumer.lua.
The base-game Kinze 4905 Blue Drive has logging and a seed-monitor profile.
Unknown machines and the SDX30 default to manual equipment without automatic
logging. Equipment authors can explicitly declare fitted capabilities in XML.
Commanded depth and automatic applied depth are separate from sensor readings.

The API and example consumer are included. Compatible FieldPath builds can
display planting records. This ZIP does not replace the companion executable
or change its saved coverage/history. FieldPath adjustment is not yet supported.

SOIL AND POPULATION RESPONSE (2.3)
Read-only optional integrations: Seasonal Crop Stress positional moisture and
Soil Fertilizer positional compaction. Missing, invalid or unavailable inputs
use neutral assumptions, explicitly identified in Inspect last pass. No rain
scalar is presented as measured soil moisture. The sample is taken at the work
area centre; this version does not resolve soil differences across individual rows.
Firm/dry soils need more opener effort to reach target depth and more closing
effort for contact. Wet soils need less; excess opener/closing effort raises
sidewall/packing risk. These are modeled mechanical effects, not modifications
to another mod's soil maps or duplicate seasonal drought/fertility multipliers.
Pressure defaults to manual; fitted automatic systems can use modeled soil
feedback. Presets start at 50/50 and do not enable automation by themselves.

Population = delivered seeds/acre times modeled establishment survival. Drill
delivered seeds start from lb/acre times seeds/lb; planter counts start directly
from seeds/acre. Each known crop has a separate interpolated response curve:
soybean branches to compensate for thin stands; wheat/barley/oat tiller; maize
compensates less. Winter and spring wheat differ. Excess population causes crop-
specific competition/lodging-like loss; dry seedbeds strengthen crowding loss.
Uneven skips/doubles/distribution add a small spacing penalty. These are explicit
gameplay calibrations, not fitted agronomic predictions or an optimal-rate adviser.
Unknown crop names retain a linear low-population fallback without a crowding curve.

Yield potential is encoded ONCE as native crop coverage, not a separate harvest
multiplier. Consequently visible gaps represent yield-equivalent area, NOT a
literal plant count. Foliage remains native and persists in ordinary save files.
No new map layers are allocated. Existing planted fields are not recalculated.
Soil/season/weather/harvest mods continue to affect the surviving crop normally.
This model cannot exceed native full-density yield. Correctly replanting bare
patches can repair coverage; repeated passes are not cumulative population.
Unsupported skewed/oversized work primitives fall back to native full coverage.
No separate plant-by-plant emergence, hybrid, row-spacing, sowing-date, root,
ear/pod count, seasonal competition or nutrient-demand model exists yet.

Sources informing qualitative behavior (coefficients are our own calibration):
https://cropwatch.unl.edu/2019/avoiding-sidewall-compaction-planting/
https://farmdoc.illinois.edu/field-crop-production/optimizing-corn-and-soybean-seeding-rates.html
https://extension.umn.edu/agriculture/crop-production/small-grains/seeding-rate-for-small-grains

FIRST-VERSION BOUNDARIES
Placement calibration is provisional. Temperature and live seed-lot vigor are
later work. Weather emergence remains the responsibility of the other soil mods.
Independent aftermarket modules are described in README_TECHNOLOGY.txt. Soil & Fertilizer retains
ownership of its weather/soil establishment failures. Water-seeding machines
are excluded. Multiplayer event checks exist; real multiplayer play is unverified.
