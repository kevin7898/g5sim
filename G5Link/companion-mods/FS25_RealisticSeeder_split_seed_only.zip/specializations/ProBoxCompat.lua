-- FieldPath RealisticSeeder ProBox soft compatibility status writer.
-- The actual optional store-item loader lives in ProBoxAutoStoreItems.lua.

RealisticSeederProBoxCompat = RealisticSeederProBoxCompat or {}

local function fpRsHasMod(modName)
    if g_modIsLoaded ~= nil and g_modIsLoaded[modName] ~= nil then
        return g_modIsLoaded[modName] == true
    end
    if g_modManager ~= nil and g_modManager.getModByName ~= nil then
        return g_modManager:getModByName(modName) ~= nil
    end
    return false
end

function RealisticSeederProBoxCompat:loadMap()
    local realisticOriginal = fpRsHasMod("FS25_LAC_SeedProBoxPackRealisticPricing")
    local standardOriginal = fpRsHasMod("FS25_LAC_SeedProBoxPackStandardPricing")
    local crossplayOriginal = fpRsHasMod("FS25_SeedProBox_Crossplay")

    local mode = "none"
    if realisticOriginal and standardOriginal then
        mode = "both_original_probox_packs_present_fieldpath_selects"
    elseif realisticOriginal then
        mode = "realistic_original_probox_present"
    elseif standardOriginal then
        mode = "standard_original_probox_present"
    elseif crossplayOriginal then
        mode = "crossplay_probox_present_status_only"
    end

    print(string.format("[RealisticSeeder] ProBox compatibility status: realisticOriginal=%s standardOriginal=%s crossplayOriginal=%s mode=%s", tostring(realisticOriginal), tostring(standardOriginal), tostring(crossplayOriginal), mode))
end

addModEventListener(RealisticSeederProBoxCompat)
