-- =============================================================
-- Dynamic Fuel Consumption — DFCEngineModel.lua
-- Pure physics model. No hooks, no globals mutation, no vehicle
-- state — just math, so it can be unit-tested / tuned in isolation.
--
-- Model:
--   totalLPerH = idleLPerH + (powerOutKW * BSFC(loadFrac)) / density
--
-- powerOutKW should be the REAL net drivetrain power for this tick:
--     motor:getMotorRotSpeed() * (motor:getMotorAvailableTorque()
--                                  - motor:getMotorExternalTorque())
-- (rotSpeed in rad/s, torque in kN*m -> product is kW directly)
--
-- loadFrac should be vehicle:getMotorLoadPercentage() (0..1).
--
-- BSFC (brake-specific fuel consumption, g/kWh) curves below are a
-- generic, simplified single-variable (load-only) approximation of
-- real diesel/gas-engine efficiency maps: worst at very low load,
-- best around 60-70% load, degrading again toward rated power.
-- They are NOT pulled from a specific engine's dyno sheet — treat
-- as a tunable starting point, not ground truth for any one engine.
-- =============================================================

DFCEngineModel = {}

-- Load fraction -> BSFC (g/kWh)
DFCEngineModel.BSFC_DIESEL = {
    { 0.00, 300 }, { 0.10, 255 }, { 0.20, 225 }, { 0.30, 208 }, { 0.40, 197 },
    { 0.50, 190 }, { 0.60, 187 }, { 0.70, 187 }, { 0.80, 191 }, { 0.90, 198 },
    { 1.00, 208 },
}

-- Spark-ignition / dual-fuel methane tends to run flatter and less
-- efficient than diesel across the board.
DFCEngineModel.BSFC_METHANE = {
    { 0.00, 340 }, { 0.10, 290 }, { 0.20, 260 }, { 0.30, 245 }, { 0.40, 235 },
    { 0.50, 228 }, { 0.60, 225 }, { 0.70, 226 }, { 0.80, 232 }, { 0.90, 242 },
    { 1.00, 255 },
}

-- Fuel density, grams per liter, used to go from g/h (mass rate,
-- what BSFC gives you) to L/h (what FS25 fill units track).
DFCEngineModel.DENSITY_G_PER_L = {
    DIESEL  = 840,  -- typical ag/road diesel, ~830-850 g/L
    METHANE = 425,  -- approximation for FS25's liquefied-methane liter accounting
}

-- Idle burn, liters/hour per 100 (metric) hp of rated engine power.
-- This is deliberately NOT derived from the BSFC curve: near-idle,
-- power output is ~0 so BSFC*power collapses to ~0 too, which is
-- physically wrong (a running diesel burns fuel just to idle). This
-- term covers that floor independently.
DFCEngineModel.IDLE_LPERH_PER_100HP = {
    LOW    = 0.4,
    MEDIUM = 0.6,
    HIGH   = 0.9,
}

local function lerp(a, b, t)
    return a + (b - a) * t
end

-- Linear-interpolate a {loadFrac, value} curve at an arbitrary load.
function DFCEngineModel.sampleCurve(curve, loadFrac)
    loadFrac = math.min(math.max(loadFrac or 0.0, 0.0), 1.0)
    local n = #curve

    for i = 1, n - 1 do
        local x0, y0 = curve[i][1], curve[i][2]
        local x1, y1 = curve[i + 1][1], curve[i + 1][2]
        if loadFrac >= x0 and loadFrac <= x1 then
            local t = (x1 > x0) and ((loadFrac - x0) / (x1 - x0)) or 0.0
            return lerp(y0, y1, t)
        end
    end

    return curve[n][2]
end

-- kW -> metric hp (PS). 1 PS = 735.5 W.
function DFCEngineModel.kwToHp(kw)
    return (kw or 0.0) * 1.35962
end

-- Main entry point. Returns target liters/hour for this vehicle's
-- current instantaneous state.
--
--   powerOutKW    : net drivetrain power this tick, kW (see header)
--   loadFrac      : engine load 0..1
--   peakPowerKW   : motor.peakMotorPower (rated power, kW)
--   fuelKind      : "DIESEL" or "METHANE"
--   idleLevelKey  : "LOW" | "MEDIUM" | "HIGH"
function DFCEngineModel.computeTargetLPerH(powerOutKW, loadFrac, peakPowerKW, fuelKind, idleLevelKey)
    local curve   = (fuelKind == "METHANE") and DFCEngineModel.BSFC_METHANE or DFCEngineModel.BSFC_DIESEL
    local density = DFCEngineModel.DENSITY_G_PER_L[fuelKind] or DFCEngineModel.DENSITY_G_PER_L.DIESEL
    local idlePer100Hp = DFCEngineModel.IDLE_LPERH_PER_100HP[idleLevelKey or "MEDIUM"]
                          or DFCEngineModel.IDLE_LPERH_PER_100HP.MEDIUM

    local peakHp    = DFCEngineModel.kwToHp(math.max(peakPowerKW or 0.0, 0.0))
    local idleLPerH = (peakHp / 100.0) * idlePer100Hp

    local powerOut = math.max(powerOutKW or 0.0, 0.0)   -- clamp out engine-braking/negative torque
    local bsfc     = DFCEngineModel.sampleCurve(curve, loadFrac)

    -- kW * g/kWh = g/h ; divide by g/L to get L/h
    local combustionLPerH = (powerOut * bsfc) / density

    return idleLPerH + combustionLPerH
end
