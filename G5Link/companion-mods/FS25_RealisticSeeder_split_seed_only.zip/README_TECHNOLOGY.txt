Realistic Seeder 2.4.0.0 - staged technology

Purchase independent options through store/workshop Customize. Existing equipment
keeps its selected hardware. Factory capabilities are checked before offering kits.
These are generic simulation kits, not claims of branded physical fit. Prices are
gameplay values. No new visible 3D hardware meshes are added.

Module                                  Planter       Drill / air seeder
FieldPath logger                         1,500         1,500
Seed monitoring                          3,000         2,000
Depth sensing                            3,000         2,500
Powered metering                         5,000         4,000
Individual row drive + cab rate         12,000         not offered
Precision meter / feed                   4,500         2,500
Downforce cab/sensed/automatic            3,500/6,000/14,000   4,000/6,500/12,000
Closing improved/sensed/automatic        3,000/5,000/10,000   2,500/4,500/9,000
Powered depth adjustment                 9,000         7,000
Seed-zone soil sensing                   4,500         3,500
Controlled seed delivery                 8,500         not offered
Row cleaner display interface            1,800         recognized planters only

The native shop handles purchases and configuration persistence. Monitoring does
not grant actuators. Automatic depth needs powered depth AND soil sensing.
Controlled delivery needs precision metering AND powered metering, and applies
to corn, soybean, cotton and sugarbeet. Incomplete combinations are labeled inactive.

Right Ctrl + ; (semicolon) opens setup with the implement selected. Edit the main settings,
then use Controls for manual/automatic modes and depth bounds, or Row control for
individual on/off and rate percentages. All pages share a draft; Apply changes
validates it. Save the farm to retain settings. Presets never buy equipment or
change loaded seed. Mechanical adjustments require stopped, switched-off work;
matching cab actuators permit the relevant changes while operating.

Manual is the default. Automatic pressure uses soil conditions and the operator's
pressure as a bias: 50% is neutral. Values represent simulated effort, not PSI.
Automatic depth uses crop range and modeled seedbed moisture within chosen bounds,
not a measured vertical moisture profile. Missing feedback holds the manual target.
These are model estimates, not calibrated agronomic prescriptions. Hardware reduces
specific placement losses; it cannot remove all effects of poor setup or conditions.

Row drive supports the recognized 12-row JD 1760, or author-declared rowCount of
1-24 with exactly one sowing work area. Row order follows that work area, not a
guaranteed left-to-right view. Shutoffs are operator controlled, not automatic GPS
overlap shutoffs. Disabled rows leave physical gaps. Row rates change physical
seed inventory usage. Area/usage remain independent of map size: planters use
seeds/acre, drills lb/acre. Verify seeds/lb from the seed tag.

The 1760 profile recognizes selected air-adjust cleaners, gauge and closing wheels.
Its row cleaners use their existing hydraulic-axis animation, not hopper covers.
The display interface operates that animation; it does not add calibrated pneumatic
pressure or residue physics. Kinze 4905 retains factory logger, seed monitor and
cab rate control. Unknown hardware needs an explicit XML capability profile.

FieldPath 0.8.2.2 records accepted row footprints and applied control targets with
the existing compatible format; its companion does not need replacement. Old
coverage, history and missing sensor readings are not rewritten. The API includes
capability gates, commanded/applied settings and current modeled rows. It and the
FieldPath display remain read-only; remote tablet adjustment is future work.
Row details are modeled, not independently measured per-row sensor readings.

Separate seed carts and water seeders are excluded. Multiplayer and physical
hardware calibration are not certified by single-player Courtland checks.
