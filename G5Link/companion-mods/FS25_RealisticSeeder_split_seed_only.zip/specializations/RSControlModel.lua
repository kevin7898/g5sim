-- Capability-gated control targets. Soil-adaptive depth is a gameplay model:
-- FS25 integrations provide a seedbed value, not a measured vertical moisture profile.
RSControlModel={}
local C=RSControlModel
local M=RSPlacementModel
C.keys={'depthMode','downforceMode','closingMode','depthMinMm','depthMaxMm','rowOffMask','rowCleanerPosition'}
local extra={depthMode={0,0,1},downforceMode={0,0,1},closingMode={0,0,1},depthMinMm={5,5,100},depthMaxMm={100,5,100},rowOffMask={0,0,16777215},rowCleanerPosition={0,0,100}}
for key,a in pairs(extra) do M.defaults[key]=a[1];M.limits[key]={a[2],a[3]} end
for i=1,24 do local key='rowRate'..i;C.keys[#C.keys+1]=key;M.defaults[key]=100;M.limits[key]={50,200} end
C.modeCaps={depthMode='automaticDepth',downforceMode='automaticDownforce',closingMode='automaticClosing'}
C.cabCaps={depthMm='cabDepthControl',depthMinMm='cabDepthControl',depthMaxMm='cabDepthControl',pressurePercent='cabDownforceControl',closingPercent='cabClosingControl',ratePerAcre='cabRateControl',ratePercent='cabRateControl',rowCleanerPosition='rowCleanerDisplayControl',rowOffMask='rowDrive'}
function C.allowed(profile,name,value)
 local mode=C.modeCaps[name]
 if mode then
  if value~=0 and value~=1 then return false,'Choose manual or automatic mode' end
  if value==1 and not profile[mode] then return false,'Required automatic control hardware is not fitted' end
 end
 if name=='rowOffMask' then
  if value~=math.floor(value) then return false,'Invalid row selection' end
  if value~=0 and (not profile.rowDrive or value>=2^(profile.rowCount or 0)) then return false,'Individual row drive and supported row layout required' end
 end
 local row=tonumber(name:match('^rowRate(%d+)$'))
 if row and value~=100 and (not profile.rowDrive or row>(profile.rowCount or 0)) then return false,'Individual row drive is not fitted for this row' end
 if name=='rowCleanerPosition' and not profile.rowCleanerDisplayControl then return false,'Recognized row cleaners and display interface required' end
 return true
end
function C.cleanerTool(v)
 for _,tool in ipairs(v.spec_cylindered and v.spec_cylindered.movingTools or {}) do if tool.animName=='rowcleaners' then return tool end end
end
function C.applyCleaner(v,value)
 local tool=C.cleanerTool(v)
 if not tool or not Cylindered or not v.getAnimationTime then return false,'Row cleaner actuator is unavailable on this equipment' end
 Cylindered.setToolAnimation(v,tool,value/100-v:getAnimationTime(tool.animName),1)
 Cylindered.setDirty(v,tool)
 return true
end
function C.cabAllowed(profile,name)
 local cap=C.cabCaps[name] or C.modeCaps[name]
 if name:match('^rowRate%d+$') then cap='rowDrive' end
 return cap and profile[cap]==true or false
end
function C.access(profile,name)
 local cap=C.modeCaps[name]
 if cap and not profile[cap] then return 'unavailable' end
 local row=tonumber(name:match('^rowRate(%d+)$'))
 if (row or name=='rowOffMask') and (not profile.rowDrive or row and row>(profile.rowCount or 0)) then return 'unavailable' end
 if name=='rowCleanerPosition' and not profile.rowCleanerDisplayControl then return 'unavailable' end
 return C.cabAllowed(profile,name) and 'cab' or 'stoppedManual'
end
function C.resolve(profile,settings,crop,soil)
 local s=M.settings(settings);local conditions=M.soilResponse(soil)
 local known=soil and (M.finite(soil.moisture) or M.finite(soil.compaction))
 local status={depth='manual',downforce='manual',closing='manual'}
 local function auto(key,cap,field,target,label)
  if s[key]==1 and profile[cap] then
   status[label]=known and 'automatic' or 'waitingForSoil'
   if known then s[field]=M.clamp(target,0,100) end
  elseif profile[C.cabCaps[field]] then status[label]='cab' end
 end
 auto('downforceMode','automaticDownforce','pressurePercent',conditions.pressureTarget+s.pressurePercent-50,'downforce')
 auto('closingMode','automaticClosing','closingPercent',conditions.closingTarget+s.closingPercent-50,'closing')
 if s.depthMode==1 and profile.automaticDepth then
  status.depth=soil and M.finite(soil.moisture) and 'automatic' or 'waitingForSoil'
  local range=M.crops[crop]
  if status.depth=='automatic' and range then
   local lo=math.min(s.depthMinMm,s.depthMaxMm);local hi=math.max(s.depthMinMm,s.depthMaxMm)
   s.depthMm=M.clamp((range[1]+range[2])/2+conditions.dry*12-conditions.wet*6,lo,hi)
  elseif not range then status.depth='unsupportedCrop' end
 elseif profile.cabDepthControl then status.depth='cab' end
 return s,{modes=status,applied={depthMm=s.depthMm,pressurePercent=s.pressurePercent,closingPercent=s.closingPercent},source='simulatedControl',depthBasis='seedbedMoistureModel'}
end
function C.rowEnabled(settings,row)
 return math.floor((settings.rowOffMask or 0)/2^(row-1))%2==0
end
C.deliveryCrops={MAIZE=true,SOYBEAN=true,COTTON=true,SUGARBEET=true}
local evaluate=M.evaluate
function M.evaluate(profile,settings,crop,speed,damage,soil)
 local effective,controls=C.resolve(profile,settings,crop,soil)
 local r=evaluate(profile,effective,crop,speed,damage,soil)
 local excess=math.max(0,(speed or 0)-(profile.workingSpeedKmh or 12))
 local precision=profile.precisionMeter and 0.65 or 1
 local delivery=profile.controlledDelivery and C.deliveryCrops[crop] and 0.35 or 1
 local speedFactor=precision*delivery
 local loss=math.max(0,(100-effective.meterPercent)/100)
 r.skipsPercent=M.clamp(loss+excess*(profile.kind=='planter' and .018 or .009)*speedFactor+M.clamp(damage or 0,0,1)*.025,0,.7)*100
 r.doublesPercent=profile.kind=='planter' and M.clamp(math.max(0,effective.meterPercent-100)/100+excess*.004*speedFactor,0,.5)*100 or 0
 if profile.kind=='drill' then r.distributionCvPercent=(excess*.012*precision+math.abs(effective.meterPercent-100)/250+(damage or 0)*.08)*100 end
 r.deliveryScale=(1-r.skipsPercent/100+r.doublesPercent/100)*(profile.kind=='drill' and math.max(1,effective.meterPercent/100) or 1)
 if profile.improvedClosing then
  local closeUnder=math.max(0,r.soil.closingTarget-effective.closingPercent)/100
  local closeOver=math.max(0,effective.closingPercent-r.soil.closingTarget)/100
  local contact=M.clamp(r.contactPercent/100+(closeUnder*.65+closeOver*(.12+.35*r.soil.wet))*.25,.1,1)
  r.placementLossPercent=(1-(1-r.placementLossPercent/100)*contact/(r.contactPercent/100))*100
  r.contactPercent=contact*100
 end
 r.controls=controls;r.controlledDeliveryActive=delivery<1
 return r
end
