-- FS25_FarmFinance - reads the farm's books from the game.
--
--   * snapshot(farmId): assets, debts and income for credit decisions
--   * income tracking: every Farm.changeBalance call is sorted into
--     operating income, operating expense, or ignored (asset sales,
--     purchases, financing), then rolled into monthly buckets.
-- Server only.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util

FF.FarmData = {}
local D = FF.FarmData

D.MONTHS_KEPT = 12

-- Recurring operating income (FS statistic names)
D.INCOME_STATS = {
    harvestIncome = true,
    soldProducts = true,
    soldWood = true,
    soldAnimals = true,
    soldMilk = true,
    soldWool = true,
    soldBales = true,
    propertyIncome = true,
    incomeBga = true,
    missionIncome = true,
    ffRentIncome = true,
    -- landowner's input share and storage fees offset operating costs
    ffCropShareInputs = true,
    ffCropShareStorage = true,
    ffInputDiscount = true
}

-- Never operating: asset purchases and sales, financing flows.
D.IGNORED_STATS = {
    newVehiclesCost = true,
    soldVehicles = true,
    newAnimalsCost = true,
    constructionCost = true,
    soldBuildings = true,
    fieldPurchase = true,
    fieldSelling = true,
    loanInterest = true,
    other = true,
    ffLoanProceeds = true,
    ffLoanPrincipal = true,
    ffLoanInterest = true,
    ffInputAccountDraw = true,
    ffInputAccountPayment = true,
    ffInputAccountInterest = true,
    ffLineDraw = true,
    ffLineRepay = true,
    ffLeaseFunding = true,
    ffLeaseDeposit = true,
    ffLeaseBuyout = true,
    ffDealerRebate = true
}

function D.classify(statistic, amount)
    if statistic == nil or amount == 0 then
        return nil
    end
    if D.IGNORED_STATS[statistic] then
        return nil
    end
    if amount > 0 then
        if D.INCOME_STATS[statistic] then
            return "income"
        end
        return nil
    end
    return "opex"
end

function D.record(farm, statistic, amount)
    local kind = D.classify(statistic, amount)
    if kind == nil then
        return
    end
    farm.income = farm.income or {}
    farm.income.current = farm.income.current or {income = 0, opex = 0}
    if kind == "income" then
        farm.income.current.income = farm.income.current.income + amount
    else
        farm.income.current.opex = farm.income.current.opex - amount
    end
end

-- Called once per month by the bank after billing.
function D.closeMonth(farm)
    farm.income = farm.income or {}
    local current = farm.income.current or {income = 0, opex = 0}
    farm.income.months = farm.income.months or {}
    table.insert(farm.income.months, {income = current.income, opex = current.opex})
    while #farm.income.months > D.MONTHS_KEPT do
        table.remove(farm.income.months, 1)
    end
    farm.income.current = {income = 0, opex = 0}
end

function D.getTrailing(farm)
    local income, opex = 0, 0
    local months = 0
    for _, month in ipairs((farm.income or {}).months or {}) do
        income = income + (month.income or 0)
        opex = opex + (month.opex or 0)
        months = months + 1
    end
    return income, opex, months
end

-- Money hook ------------------------------------------------------------------

function D.onChangeBalance(gameFarm, amount, moneyType)
    if FF.state == nil or gameFarm == nil or not FF.isServer() then
        return
    end
    local farmId = gameFarm.farmId
    if farmId == nil or farmId <= 0 or farmId == FarmManager.SPECTATOR_FARM_ID then
        return
    end
    local statistic = type(moneyType) == "table" and moneyType.statistic or nil
    local farm = FF.Bank.getFarm(farmId)
    D.record(farm, statistic, amount or 0)
end

-- Asset values ----------------------------------------------------------------

local function safeCall(fn, ...)
    local ok, result = pcall(fn, ...)
    if ok then
        return result
    end
    return nil
end

function D.getLandValue(farmId)
    local total = 0
    if g_farmlandManager == nil then
        return 0
    end
    for _, farmland in pairs(g_farmlandManager:getFarmlands() or {}) do
        local owner = g_farmlandManager:getFarmlandOwner(farmland.id)
        if owner == farmId and not FF.Land.isRentedIn(farmland.id) then
            total = total + (farmland.price or 0)
        end
    end
    -- Land rented out to a neighbour is still ours.
    local farm = FF.Bank.getFarm(farmId, false)
    if farm ~= nil then
        for _, contract in pairs(farm.land) do
            if contract.kind == "out" then
                local farmland = g_farmlandManager:getFarmlandById(contract.farmlandId)
                if farmland ~= nil then
                    total = total + (farmland.price or 0)
                end
            end
        end
    end
    return total
end

function D.getMachineryValue(farmId)
    local total = 0
    local vehicleSystem = g_currentMission ~= nil and g_currentMission.vehicleSystem or nil
    if vehicleSystem == nil or vehicleSystem.vehicles == nil then
        return 0
    end
    local equipmentEnv = FF.env ~= nil and FF.env.equipment or nil
    for _, vehicle in pairs(vehicleSystem.vehicles) do
        local leased = false
        if FF.Equipment ~= nil and equipmentEnv ~= nil and equipmentEnv.getUniqueId ~= nil then
            leased = FF.Equipment.isLeased(equipmentEnv.getUniqueId(vehicle))
        end
        -- Leased machines are the lessor's, not the farm's.
        if not leased and vehicle.getOwnerFarmId ~= nil and vehicle:getOwnerFarmId() == farmId
                and vehicle.propertyState == VehiclePropertyState.OWNED
                and vehicle.getSellPrice ~= nil then
            local price = safeCall(vehicle.getSellPrice, vehicle)
            if U.isFiniteNumber(price) and price > 0 then
                total = total + price
            end
        end
    end
    return total
end

function D.getBuildingValue(farmId)
    local total = 0
    local placeableSystem = g_currentMission ~= nil and g_currentMission.placeableSystem or nil
    if placeableSystem == nil or placeableSystem.placeables == nil then
        return 0
    end
    for _, placeable in pairs(placeableSystem.placeables) do
        if placeable.getOwnerFarmId ~= nil and placeable:getOwnerFarmId() == farmId and placeable.getSellPrice ~= nil then
            local price = safeCall(placeable.getSellPrice, placeable)
            if U.isFiniteNumber(price) and price > 0 then
                total = total + price
            end
        end
    end
    return total
end

function D.getInventoryValue(farmId)
    local total = 0
    local placeableSystem = g_currentMission ~= nil and g_currentMission.placeableSystem or nil
    if placeableSystem == nil or placeableSystem.placeables == nil or g_fillTypeManager == nil then
        return 0
    end
    for _, placeable in pairs(placeableSystem.placeables) do
        local storages = {}
        if placeable.spec_silo ~= nil and placeable.spec_silo.storages ~= nil then
            for _, storage in ipairs(placeable.spec_silo.storages) do
                storages[#storages + 1] = storage
            end
        end
        for _, storage in ipairs(storages) do
            if storage.getOwnerFarmId ~= nil and storage:getOwnerFarmId() == farmId and storage.getFillLevels ~= nil then
                for fillTypeIndex, fillLevel in pairs(storage:getFillLevels() or {}) do
                    if fillLevel > 0 then
                        local fillType = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
                        if fillType ~= nil and U.isFiniteNumber(fillType.pricePerLiter) and fillType.pricePerLiter > 0 then
                            total = total + fillLevel * fillType.pricePerLiter
                        end
                    end
                end
            end
        end
    end
    return total
end

function D.getCash(farmId)
    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil
    if farm == nil then
        return 0
    end
    return farm.money or 0
end

function D.snapshot(farmId)
    local cash = D.getCash(farmId)
    local landValue = safeCall(D.getLandValue, farmId) or 0
    local machineryValue = safeCall(D.getMachineryValue, farmId) or 0
    local buildingValue = safeCall(D.getBuildingValue, farmId) or 0
    local inventoryValue = safeCall(D.getInventoryValue, farmId) or 0
    -- Grain held for crop-share landowners sits in the bins but isn't ours.
    if FF.CropShare ~= nil then
        inventoryValue = math.max(inventoryValue - FF.CropShare.getHeldValue(farmId), 0)
    end

    local summary = FF.Bank.getDebtSummary(farmId)
    local rentPaid = FF.Land.getYearlyRent(farmId)
    local overdraft = cash < 0 and -cash or 0

    local farm = FF.Bank.getFarm(farmId)
    local income12, opex12, months = D.getTrailing(farm)

    local snapshot = {
        cash = cash,
        landValue = landValue,
        machineryValue = machineryValue,
        buildingValue = buildingValue,
        inventoryValue = inventoryValue,
        totalAssets = math.max(cash, 0) + landValue + machineryValue + buildingValue + inventoryValue,
        debts = summary.debts,
        totalDebt = summary.total + overdraft,
        currentAssets = math.max(cash, 0) + inventoryValue,
        currentLiabilities = summary.principal12 + summary.interest12 + rentPaid + overdraft + (summary.lease12 or 0),
        debtService12 = summary.debtService12,
        monthlyPayments = summary.monthlyPayments,
        yearlyRent = rentPaid,
        income12 = income12,
        opex12 = opex12,
        historyMonths = months
    }
    return snapshot
end

return D
