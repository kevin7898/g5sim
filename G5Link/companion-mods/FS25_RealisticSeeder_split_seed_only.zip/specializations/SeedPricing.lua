-- SeedPricing.lua
-- Writes average crop-specific seed pricing defaults for FieldPath Command.
-- FieldPath can adjust globalMultiplier and cropMultipliers in realisticSeederSeedPricingSettings.json.

RealisticSeederSeedPricing = RealisticSeederSeedPricing or {}
RealisticSeederSeedPricing.schema = 1
RealisticSeederSeedPricing.defaultMode = "realisticAverage"
RealisticSeederSeedPricing.defaultJson = [====[
{
  "schema": 1,
  "source": "FS25_RealisticSeeder",
  "pricingMode": "realisticAverage",
  "currency": "USD",
  "unit": "perAcre",
  "gamePriceScale": 10,
  "globalMultiplier": 1.0,
  "allowFieldPathOverride": true,
  "notes": [
    "FieldPath should calculate finalSeedCostPerAcre = avgUsdPerAcre * globalMultiplier * cropMultiplier.",
    "Store XML prices are static startup prices; FieldPath multipliers are intended for accounting and future generated-price workflows.",
    "Numbers are average/gameplay-safe seed cost defaults, not a quote from one retailer or one farm."
  ],
  "crops": {
    "SEED_MAIZE": {
      "crop": "Corn / Maize",
      "avgUsdPerAcre": 122.0,
      "sourceNote": "farmdoc 2025 corn seed budget average",
      "basePalletPrice": 1220,
      "baseProBoxPrice": 1843,
      "defaultMultiplier": 1.0
    },
    "SEED_SOYBEAN": {
      "crop": "Soybean",
      "avgUsdPerAcre": 76.0,
      "sourceNote": "farmdoc/MSU soybean seed cost range average",
      "basePalletPrice": 760,
      "baseProBoxPrice": 1148,
      "defaultMultiplier": 1.0
    },
    "SEED_WHEAT": {
      "crop": "Wheat",
      "avgUsdPerAcre": 53.0,
      "sourceNote": "farmdoc 2025 wheat seed budget",
      "basePalletPrice": 530,
      "baseProBoxPrice": 801,
      "defaultMultiplier": 1.0
    },
    "SEED_BARLEY": {
      "crop": "Barley",
      "avgUsdPerAcre": 45.0,
      "sourceNote": "Saskatchewan/Ontario 2025 crop planning normalized average",
      "basePalletPrice": 450,
      "baseProBoxPrice": 680,
      "defaultMultiplier": 1.0
    },
    "SEED_OAT": {
      "crop": "Oat",
      "avgUsdPerAcre": 40.0,
      "sourceNote": "Saskatchewan/Ontario 2025 crop planning normalized average",
      "basePalletPrice": 400,
      "baseProBoxPrice": 604,
      "defaultMultiplier": 1.0
    },
    "SEED_CANOLA": {
      "crop": "Canola",
      "avgUsdPerAcre": 96.0,
      "sourceNote": "Saskatchewan 2025 canola seed plus treatment average",
      "basePalletPrice": 960,
      "baseProBoxPrice": 1450,
      "defaultMultiplier": 1.0
    },
    "SEED_SORGHUM": {
      "crop": "Sorghum",
      "avgUsdPerAcre": 45.0,
      "sourceNote": "Extension grain sorghum planning budget normalized average",
      "basePalletPrice": 450,
      "baseProBoxPrice": 680,
      "defaultMultiplier": 1.0
    },
    "SEED_SUNFLOWER": {
      "crop": "Sunflower",
      "avgUsdPerAcre": 65.0,
      "sourceNote": "Prairie crop planning normalized average",
      "basePalletPrice": 650,
      "baseProBoxPrice": 982,
      "defaultMultiplier": 1.0
    },
    "SEED_COTTON": {
      "crop": "Cotton",
      "avgUsdPerAcre": 115.0,
      "sourceNote": "Southern/Arizona field crop budget normalized average",
      "basePalletPrice": 1150,
      "baseProBoxPrice": 1737,
      "defaultMultiplier": 1.0
    },
    "SEED_POTATO": {
      "crop": "Potato",
      "avgUsdPerAcre": 240.0,
      "sourceNote": "high-value root crop gameplay average",
      "basePalletPrice": 2400,
      "baseProBoxPrice": 3625,
      "defaultMultiplier": 1.0
    },
    "SEED_SUGARBEET": {
      "crop": "Sugar beet",
      "avgUsdPerAcre": 260.0,
      "sourceNote": "high-value beet crop gameplay average",
      "basePalletPrice": 2600,
      "baseProBoxPrice": 3927,
      "defaultMultiplier": 1.0
    },
    "SEED_BEETROOT": {
      "crop": "Beetroot",
      "avgUsdPerAcre": 220.0,
      "sourceNote": "high-value vegetable crop gameplay average",
      "basePalletPrice": 2200,
      "baseProBoxPrice": 3323,
      "defaultMultiplier": 1.0
    },
    "SEED_CARROT": {
      "crop": "Carrot",
      "avgUsdPerAcre": 220.0,
      "sourceNote": "high-value vegetable crop gameplay average",
      "basePalletPrice": 2200,
      "baseProBoxPrice": 3323,
      "defaultMultiplier": 1.0
    },
    "SEED_ONION": {
      "crop": "Onion",
      "avgUsdPerAcre": 230.0,
      "sourceNote": "high-value vegetable crop gameplay average",
      "basePalletPrice": 2300,
      "baseProBoxPrice": 3474,
      "defaultMultiplier": 1.0
    },
    "SEED_PARSNIP": {
      "crop": "Parsnip",
      "avgUsdPerAcre": 210.0,
      "sourceNote": "high-value vegetable crop gameplay average",
      "basePalletPrice": 2100,
      "baseProBoxPrice": 3172,
      "defaultMultiplier": 1.0
    },
    "SEED_GRASS": {
      "crop": "Grass",
      "avgUsdPerAcre": 35.0,
      "sourceNote": "forage/cover seed gameplay average",
      "basePalletPrice": 350,
      "baseProBoxPrice": 529,
      "defaultMultiplier": 1.0
    },
    "SEED_ALFALFA": {
      "crop": "Alfalfa",
      "avgUsdPerAcre": 85.0,
      "sourceNote": "forage seed crop budget normalized average",
      "basePalletPrice": 850,
      "baseProBoxPrice": 1284,
      "defaultMultiplier": 1.0
    },
    "SEED_CLOVER": {
      "crop": "Clover",
      "avgUsdPerAcre": 65.0,
      "sourceNote": "forage/cover seed gameplay average",
      "basePalletPrice": 650,
      "baseProBoxPrice": 982,
      "defaultMultiplier": 1.0
    },
    "SEED_OILSEEDRADISH": {
      "crop": "Oilseed radish",
      "avgUsdPerAcre": 35.0,
      "sourceNote": "cover crop seed gameplay average",
      "basePalletPrice": 350,
      "baseProBoxPrice": 529,
      "defaultMultiplier": 1.0
    }
  }
}
]====]
RealisticSeederSeedPricing.settingsExampleJson = [====[
{
  "schema": 1,
  "source": "FieldPath Command",
  "pricingMode": "realisticAverage",
  "globalMultiplier": 1.0,
  "cropMultipliers": {
    "SEED_MAIZE": 1.0,
    "SEED_SOYBEAN": 1.0,
    "SEED_WHEAT": 1.0,
    "SEED_BARLEY": 1.0,
    "SEED_OAT": 1.0,
    "SEED_CANOLA": 1.0,
    "SEED_SORGHUM": 1.0,
    "SEED_SUNFLOWER": 1.0,
    "SEED_COTTON": 1.0,
    "SEED_POTATO": 1.0,
    "SEED_SUGARBEET": 1.0,
    "SEED_BEETROOT": 1.0,
    "SEED_CARROT": 1.0,
    "SEED_ONION": 1.0,
    "SEED_PARSNIP": 1.0,
    "SEED_GRASS": 1.0,
    "SEED_ALFALFA": 1.0,
    "SEED_CLOVER": 1.0,
    "SEED_OILSEEDRADISH": 1.0
  },
  "lastUpdatedBy": "user"
}
]====]

local function rsPricingDataDir()
    if getUserProfileAppPath == nil then
        return nil
    end
    local base = getUserProfileAppPath() or ""
    if base == "" then
        return nil
    end
    return base .. "modSettings/FS25_FieldPathCommand"
end

local function rsPricingWriteIfMissing(path, text)
    local file = io.open(path, "w")
    if file == nil then
        return false
    end
    file:write(text)
    file:close()
    return true
end

function RealisticSeederSeedPricing:loadMap()
    local dir = rsPricingDataDir()
    if dir == nil then
        return
    end
    if createFolder ~= nil then
        createFolder(dir)
    end
    rsPricingWriteIfMissing(dir .. "/realisticSeederSeedPricingDefaults.json", self.defaultJson)
    rsPricingWriteIfMissing(dir .. "/realisticSeederSeedPricingSettings.json", self.settingsExampleJson)
    print("[RealisticSeeder] Seed pricing defaults available for FieldPath: realisticAverage, globalMultiplier, per-crop multipliers")
end

addModEventListener(RealisticSeederSeedPricing)
