# Farm Finance API for mod authors

Farm Finance (FS25_FarmFinance) runs the farm's bank, input account, land leases and crop-share leases. This API lets your mod plug into them without depending on its internals.

API version: **1.0.0**. Breaking changes will bump the major version; check `api.getVersion()`.

## Getting the API

Mods load in alphabetical order, so look the API up when you need it, not when your script is sourced:

```lua
local function getFarmFinance()
    local api = g_currentMission ~= nil and g_currentMission.farmFinanceAPI or nil
    if api ~= nil and api.isReady() then
        return api
    end
    return nil
end
```

Calls that move money or change state run on the **server** only. On a client they return `false, "notServer"`, or zero. Read-only calls work everywhere, because clients get the server's state.

## Selling inputs: `payForInputs`

Use this when your mod sells seed, fertilizer, chemicals or other inputs to a farm: a co-op silo, a liquid-fertilizer fill station, a seed tender, a chemical shed.

**Don't take the money yourself.** Call `payForInputs`. Farm Finance books the expense, then puts the purchase on the farm's input account (pay after harvest) if the farm has that switched on and has room. Otherwise it charges cash, with the early-pay discount when one applies.

```lua
-- on the server, where your station would normally do g_currentMission:addMoney(-price, ...)
local api = getFarmFinance()
if api ~= nil then
    local ok, method, value = api.payForInputs(farmId, price, {
        fillType = fillTypeIndex,          -- or "LIQUIDFERTILIZER"
        liters = liters,
        description = "Liquid fertilizer - Miller Co-op",
    })
    -- method: "account" (value = amount booked) or "cash" (value = discount refunded)
else
    g_currentMission:addMoney(-price, farmId, MoneyType.PURCHASE_FERTILIZER, true, true)
end
```

`info` fields, all optional:

| Field | Meaning |
|---|---|
| `fillType` | Fill type index or name. Sets the expense category: `PURCHASE_SEEDS` for seed and saplings, otherwise `PURCHASE_FERTILIZER`. |
| `liters` | Quantity, for the record and events. |
| `description` | Text kept with the account charge. |
| `moneyType` | Book the expense under this `MoneyType` instead. |
| `allowAccount` | `false` never puts the purchase on the account. |
| `applyDiscount` | `false` gives no early-pay discount when paid in cash. |

Returns `ok, method, value, reason`. When Farm Finance's bank is switched off because another finance mod is active, the farm is simply charged in cash, and `ok` is still `true`.

Related calls:

- `api.getInputAccount(farmId)` returns `{enabled, autoCharge, limit, balance, available, pastDue, dueCropYear, dueDatePeriod, pastDueRate, earlyPayDiscount}`. Use it to show "on account" or "cash" in your own UI.
- `api.getEarlyPayDiscount()` returns the current cash discount as a fraction from 0 to 1.
- `api.isInputFillType(fillType)` and `api.registerInputFillType("MY_FERTILIZER")` declare your own fill types as inputs, so shop purchases and AI helper purchases of them use the account too.

## Grain sales outside a selling station: `reportGrainSale`

On a crop-share lease the landowner owns a share of the crop. Farm Finance pays them from sales that go through `SellingStation.sellFillType`. If your mod sells grain another way (virtual hauls, direct contracts, your own sell point), report it so the landowner gets their share:

```lua
local landownerLiters, landownerValue = api.reportGrainSale(farmId, fillTypeIndex, liters, pricePerLiter)
```

Farm Finance charges the farm `landownerValue` itself. Don't take it yourself.

## Harvest and input use from custom machines

- `api.reportHarvest(farmId, farmlandId, fillType, liters)` reports a harvest that didn't come through a base-game combine (`Combine:addCutterArea`). It returns the landowner's liters.
- `api.reportInputUse(farmId, farmlandId, cost)` reports seed or spray used on a field by a machine that isn't a base-game seeder or sprayer. On a crop-share field it returns the landowner's share, which the farm is credited at month end.
- `api.isCropShareField(farmId, farmlandId)` returns `true, landownerShare` or `false, 0`.
- `api.getLandownerGrain(farmId)` returns `{FILLTYPE = {liters, value, oldestCropYear}}` for grain the farm holds for landowners.

## Other reads

- `api.getCreditScore(farmId)` returns `score, grade`: 300–850 and A–E.
- `api.getLandContract(farmlandId)` returns `nil` or `{kind = "in"|"out", leaseType = "cash"|"share", farmId, annualRent, landownerShare, inputShare, endCropYear}`.
- `api.getRegionId()` and `api.getRegionValue(key, default)` read region data, for example `api.getRegionValue("land.rentToValue")`. The keys are listed in `regions/_base.xml`.
- `api.isBankActive()` returns `false` when a conflicting finance mod is running.

## Reading everything

Every read call returns a copy, so changing it changes nothing in Farm Finance. On clients these calls read the state the server last sent.

| Call | Returns |
|---|---|
| `api.getFarmSummary(farmId)` | Everything for one farm in one table: credit, loans, leases, land, crop share, operating line, input account and charges, ledger, debt totals. |
| `api.getFarmIds()` | Farm ids that have Farm Finance records. |
| `api.getCreditReport(farmId)` | Score, grade, the five score parts (0 to 1), all ratios, the asset and income snapshot, payment history, last yearly review, and today's limit and rate per loan type. |
| `api.getLoans(farmId, includeClosed)` | Each loan's balance, rate, payment, months left, status, and the machine it's secured by (`collateralUid`). |
| `api.getLeases(farmId)` | Machine leases with payment, residual, deposit, months left, hour allowance and the machine's `vehicleUid`. |
| `api.getVehicleFinance(vehicleUid)` | Whether a machine is leased, or is collateral for a loan. |
| `api.getLandContracts(farmId)` | Every land lease in and out, cash or crop share, with notice status. |
| `api.getCropShareReport(farmId)` | Per field and crop year: harvested, the landowner's share, sold, cashed out and paid, plus inputs shared and grain still held. |
| `api.getOperatingLine(farmId)` | Limit, balance, current rate, and whether the yearly clean-up is done (`nil` when there's no line). |
| `api.getInputCharges(farmId)` | Each input-account charge with its due crop year and past-due flag. |
| `api.getLedger(farmId)` | Lifetime interest, principal and rent paid and received, plus 12-month operating income and costs. |
| `api.getMarket()` | Market rate, its trend, rate history, the current dealer promos, and the game month, crop year and period. |
| `api.getRegion()` / `api.listRegions()` | The region in effect with every value, and all installed regions. |
| `api.getConflicts()` | Mods that switched Farm Finance features off. |
| `api.getImportReport()` | What the importer brought over from older mods. |

## Events

```lua
api.subscribe("inputPurchased", function(self, farmId, amount, method, value, fillTypeName, liters) end, self)
api.subscribe("landownerPaid", function(self, farmId, fillTypeName, liters, value) end, self)
api.subscribe("monthProcessed", function(self, period) end, self)
api.unsubscribe("inputPurchased", self)
```

Listeners run on the server, inside `pcall`. With a target, the callback is called as `callback(target, ...)`.

## Adding a region

Regions are data, not code. To add one, ship `farmFinance/regions.xml` in your mod (a map mod can do this too). It's an index in the same format as Farm Finance's `regions/index.xml`, pointing at your region files and, optionally, a `mapRegions` file. Each region file names a `parent` and overrides only what differs. See `regions/_base.xml` for every key. Players can do the same in `modSettings/FS25_FarmFinance/regions/index.xml`.
