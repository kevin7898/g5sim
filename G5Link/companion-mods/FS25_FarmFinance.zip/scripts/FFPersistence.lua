-- FS25_FarmFinance - savegame file farmFinance.xml.
-- Numbers are written as text with full precision (XML floats are 32-bit,
-- which would round large balances).

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util

FF.Persistence = {}
local P = FF.Persistence

P.FILENAME = "farmFinance.xml"
P.ROOT = "farmFinance"

local LOAN_FIELDS = {
    {"id", "string"}, {"productId", "string"}, {"label", "string"}, {"source", "string"},
    {"principal", "number"}, {"balance", "number"}, {"rate", "number"}, {"payment", "number"},
    {"monthsTotal", "int"}, {"monthsLeft", "int"}, {"startMonth", "int"}, {"lateMonths", "int"},
    {"status", "string"}, {"wasDefault", "bool"}, {"closedMonth", "int"},
    {"collateralUid", "string"}, {"pendingPurchase", "bool"}, {"awaitingVehicle", "bool"}
}

local LEASE_FIELDS = {
    {"id", "string"}, {"storeXml", "string"}, {"name", "string"}, {"price", "number"},
    {"payment", "number"}, {"residual", "number"}, {"deposit", "number"}, {"rate", "number"},
    {"months", "int"}, {"monthsLeft", "int"}, {"hoursPerYear", "number"}, {"startMonth", "int"},
    {"status", "string"}, {"vehicleUid", "string"}, {"endNotified", "bool"}
}

local PROMO_FIELDS = {
    {"brand", "string"}, {"months", "int"}, {"rebate", "number"}, {"startMonth", "int"}, {"endMonth", "int"}
}

local LAND_FIELDS = {
    {"id", "string"}, {"kind", "string"}, {"farmlandId", "int"}, {"name", "string"},
    {"annualRent", "number"}, {"signedMonth", "int"}, {"signedCropYear", "int"},
    {"billingFromCropYear", "int"}, {"lastRenegotiatedCropYear", "int"}, {"endCropYear", "int"},
    {"noticeBy", "string"}, {"status", "string"}, {"source", "string"},
    {"leaseType", "string"}, {"shareTermId", "string"}, {"landownerShare", "number"}, {"inputShare", "number"}
}

local LOT_FIELDS = {
    {"contractId", "string"}, {"farmlandId", "int"}, {"name", "string"}, {"cropYear", "int"},
    {"fillType", "string"}, {"liters", "number"}
}

local SHARE_STAT_FIELDS = {
    {"contractId", "string"}, {"farmlandId", "int"}, {"name", "string"}, {"cropYear", "int"},
    {"fillType", "string"}, {"harvested", "number"}, {"landowner", "number"}, {"delivered", "number"},
    {"deliveredValue", "number"}, {"settled", "number"}, {"settledValue", "number"}
}

local SHARE_INPUT_FIELDS = {
    {"contractId", "string"}, {"cropYear", "int"}, {"cost", "number"}, {"credit", "number"}
}

local CHARGE_FIELDS = {
    {"id", "string"}, {"amount", "number"}, {"remaining", "number"}, {"dueCropYear", "int"},
    {"month", "int"}, {"description", "string"}, {"missedDue", "bool"}
}

local LINE_FIELDS = {
    {"open", "bool"}, {"limit", "number"}, {"balance", "number"}, {"cleanedThisYear", "bool"}, {"openedMonth", "int"}
}

local HISTORY_FIELDS = {
    {"onTime", "int"}, {"late", "int"}, {"missed", "int"}, {"streak", "int"},
    {"defaults", "int"}, {"monthsOnRecord", "int"}
}

local LEDGER_FIELDS = {
    {"interestPaid", "number"}, {"principalPaid", "number"}, {"rentPaid", "number"}, {"rentIncome", "number"},
    {"gpsPaid", "number"}, {"gpsOnAccount", "number"}, {"gpsOnLine", "number"}
}

local REVIEW_FIELDS = {
    {"month", "int"}, {"cropYear", "int"}, {"score", "int"}, {"grade", "string"},
    {"debtToAsset", "number"}, {"currentRatio", "number"}, {"termDebtCoverage", "number"}
}

local function setField(xmlFile, key, valueType, value)
    if value == nil then
        return
    end
    if valueType == "number" then
        xmlFile:setString(key, string.format("%.15g", value))
    elseif valueType == "int" then
        xmlFile:setInt(key, math.floor(value))
    elseif valueType == "bool" then
        xmlFile:setBool(key, value == true)
    else
        xmlFile:setString(key, tostring(value))
    end
end

local function getField(xmlFile, key, valueType)
    if valueType == "number" then
        return U.toNumber(xmlFile:getString(key), nil)
    elseif valueType == "int" then
        return xmlFile:getInt(key)
    elseif valueType == "bool" then
        return xmlFile:getBool(key)
    end
    return xmlFile:getString(key)
end

local function writeRecord(xmlFile, key, record, fields)
    for _, field in ipairs(fields) do
        setField(xmlFile, key .. "#" .. field[1], field[2], record[field[1]])
    end
end

local function readRecord(xmlFile, key, fields)
    local record = {}
    for _, field in ipairs(fields) do
        record[field[1]] = getField(xmlFile, key .. "#" .. field[1], field[2])
    end
    return record
end

function P.getSavegameDirectory()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    if missionInfo == nil then
        return nil
    end
    local directory = missionInfo.savegameDirectory
    if directory == nil and missionInfo.savegameIndex ~= nil and getUserProfileAppPath ~= nil then
        directory = string.format("%ssavegame%d", getUserProfileAppPath(), missionInfo.savegameIndex)
    end
    return directory
end

function P.save()
    if FF.state == nil or not FF.isServer() then
        return
    end
    local directory = P.getSavegameDirectory()
    if directory == nil then
        return
    end
    local filename = directory .. "/" .. P.FILENAME
    local xmlFile = XMLFile.create("ffSave", filename, P.ROOT)
    if xmlFile == nil then
        U.warn("could not create %s", filename)
        return
    end

    local s = FF.state
    local root = P.ROOT
    xmlFile:setInt(root .. "#version", FF.STATE_VERSION)
    xmlFile:setString(root .. "#modVersion", FF.VERSION)
    setField(xmlFile, root .. "#regionId", "string", s.regionId)
    setField(xmlFile, root .. "#nextId", "int", s.nextId)
    setField(xmlFile, root .. "#monthIndex", "int", s.monthIndex)
    setField(xmlFile, root .. "#cropYear", "int", s.cropYear)
    setField(xmlFile, root .. "#period", "int", s.period)
    setField(xmlFile, root .. "#baseRate", "number", s.baseRate)
    setField(xmlFile, root .. "#rateTrend", "int", s.rateTrend)
    setField(xmlFile, root .. "#rateTrendMonths", "int", s.rateTrendMonths)
    setField(xmlFile, root .. "#importReportSeen", "bool", s.importReportSeen)

    for source, done in pairs(s.imported or {}) do
        xmlFile:setBool(root .. ".imported#" .. source, done == true)
    end
    for index, line in ipairs(s.importReport or {}) do
        xmlFile:setString(string.format("%s.importReport.line(%d)#text", root, index - 1), line)
    end
    for index, entry in ipairs(s.rateHistory or {}) do
        local key = string.format("%s.rateHistory.r(%d)", root, index - 1)
        setField(xmlFile, key .. "#month", "int", entry.month)
        setField(xmlFile, key .. "#rate", "number", entry.rate)
    end
    local promoIndex = 0
    for _, brand in ipairs(U.sortedKeys(s.promos or {})) do
        local promo = U.deepCopy(s.promos[brand])
        promo.brand = brand
        writeRecord(xmlFile, string.format("%s.promos.promo(%d)", root, promoIndex), promo, PROMO_FIELDS)
        promoIndex = promoIndex + 1
    end
    local touchedIndex = 0
    for farmlandKey in pairs(s.touchedFarmlands or {}) do
        xmlFile:setString(string.format("%s.touched.f(%d)#id", root, touchedIndex), farmlandKey)
        touchedIndex = touchedIndex + 1
    end

    local farmIndex = 0
    for _, farmKey in ipairs(U.sortedKeys(s.farms)) do
        local farm = s.farms[farmKey]
        local key = string.format("%s.farm(%d)", root, farmIndex)
        farmIndex = farmIndex + 1
        xmlFile:setInt(key .. "#farmId", farm.farmId)
        setField(xmlFile, key .. "#lastScore", "int", farm.lastScore)

        writeRecord(xmlFile, key .. ".history", farm.history, HISTORY_FIELDS)
        local recent = {}
        for _, month in ipairs(farm.history.recentLate or {}) do
            recent[#recent + 1] = tostring(month)
        end
        xmlFile:setString(key .. ".history#recentLate", table.concat(recent, ","))
        writeRecord(xmlFile, key .. ".ledger", farm.ledger, LEDGER_FIELDS)
        if farm.review ~= nil then
            writeRecord(xmlFile, key .. ".review", farm.review, REVIEW_FIELDS)
        end

        local current = (farm.income or {}).current or {income = 0, opex = 0}
        setField(xmlFile, key .. ".income#currentIncome", "number", current.income)
        setField(xmlFile, key .. ".income#currentOpex", "number", current.opex)
        for index, month in ipairs((farm.income or {}).months or {}) do
            local monthKey = string.format("%s.income.m(%d)", key, index - 1)
            setField(xmlFile, monthKey .. "#income", "number", month.income)
            setField(xmlFile, monthKey .. "#opex", "number", month.opex)
        end

        local loanIndex = 0
        for _, loanId in ipairs(U.sortedKeys(farm.loans)) do
            writeRecord(xmlFile, string.format("%s.loan(%d)", key, loanIndex), farm.loans[loanId], LOAN_FIELDS)
            loanIndex = loanIndex + 1
        end
        for index, loan in ipairs(farm.closed or {}) do
            writeRecord(xmlFile, string.format("%s.closed(%d)", key, index - 1), loan, LOAN_FIELDS)
        end
        local landIndex = 0
        for _, contractId in ipairs(U.sortedKeys(farm.land)) do
            writeRecord(xmlFile, string.format("%s.land(%d)", key, landIndex), farm.land[contractId], LAND_FIELDS)
            landIndex = landIndex + 1
        end

        local share = farm.cropShare
        if share ~= nil then
            setField(xmlFile, key .. ".cropShare#pendingInputCredit", "number", share.pendingInputCredit or 0)
            for index, lot in ipairs(share.lots or {}) do
                writeRecord(xmlFile, string.format("%s.cropShare.lot(%d)", key, index - 1), lot, LOT_FIELDS)
            end
            local priceIndex = 0
            for _, fillType in ipairs(U.sortedKeys(share.lastPrice or {})) do
                local priceKey = string.format("%s.cropShare.price(%d)", key, priceIndex)
                xmlFile:setString(priceKey .. "#fillType", fillType)
                setField(xmlFile, priceKey .. "#value", "number", share.lastPrice[fillType])
                priceIndex = priceIndex + 1
            end
            for index, row in ipairs(share.stats or {}) do
                writeRecord(xmlFile, string.format("%s.cropShare.stat(%d)", key, index - 1), row, SHARE_STAT_FIELDS)
            end
            for index, row in ipairs(share.inputs or {}) do
                writeRecord(xmlFile, string.format("%s.cropShare.input(%d)", key, index - 1), row, SHARE_INPUT_FIELDS)
            end
        end

        local account = farm.inputs
        if account ~= nil then
            xmlFile:setBool(key .. ".inputs#autoCharge", account.autoCharge ~= false)
            if account.gpsBilling ~= nil then
                xmlFile:setString(key .. ".inputs#gpsBilling", account.gpsBilling)
            end
            setField(xmlFile, key .. ".inputs#discounts", "number", account.discounts or 0)
            setField(xmlFile, key .. ".inputs#interestPaid", "number", account.interestPaid or 0)
            for index, charge in ipairs(account.charges or {}) do
                writeRecord(xmlFile, string.format("%s.inputs.charge(%d)", key, index - 1), charge, CHARGE_FIELDS)
            end
        end
        if farm.line ~= nil and farm.line.open then
            writeRecord(xmlFile, key .. ".line", farm.line, LINE_FIELDS)
        end
        local leaseIndex = 0
        for _, leaseId in ipairs(U.sortedKeys(farm.leases or {})) do
            writeRecord(xmlFile, string.format("%s.lease(%d)", key, leaseIndex), farm.leases[leaseId], LEASE_FIELDS)
            leaseIndex = leaseIndex + 1
        end
    end

    xmlFile:save()
    xmlFile:delete()
end

-- Returns a state table, or nil when the save has no Farm Finance file.
function P.load()
    local directory = P.getSavegameDirectory()
    if directory == nil then
        return nil
    end
    local filename = directory .. "/" .. P.FILENAME
    if not fileExists(filename) then
        return nil
    end
    local xmlFile = XMLFile.load("ffSave", filename)
    if xmlFile == nil then
        U.warn("could not read %s", filename)
        return nil
    end

    local root = P.ROOT
    local s = FF.Bank.newState()
    s.version = xmlFile:getInt(root .. "#version") or 1
    s.regionId = xmlFile:getString(root .. "#regionId")
    s.nextId = xmlFile:getInt(root .. "#nextId") or 1
    s.monthIndex = xmlFile:getInt(root .. "#monthIndex") or 0
    s.cropYear = xmlFile:getInt(root .. "#cropYear") or 1
    s.period = xmlFile:getInt(root .. "#period")
    s.baseRate = getField(xmlFile, root .. "#baseRate", "number")
    s.rateTrend = xmlFile:getInt(root .. "#rateTrend") or 0
    s.rateTrendMonths = xmlFile:getInt(root .. "#rateTrendMonths") or 0
    s.importReportSeen = xmlFile:getBool(root .. "#importReportSeen") == true

    for _, source in ipairs({"usedPlus", "els", "vanilla", "fieldLeasing", "rentYourField"}) do
        if xmlFile:getBool(root .. ".imported#" .. source) == true then
            s.imported[source] = true
        end
    end
    xmlFile:iterate(root .. ".importReport.line", function(_, key)
        local text = xmlFile:getString(key .. "#text")
        if text ~= nil then
            table.insert(s.importReport, text)
        end
    end)
    xmlFile:iterate(root .. ".rateHistory.r", function(_, key)
        table.insert(s.rateHistory, {
            month = xmlFile:getInt(key .. "#month") or 0,
            rate = getField(xmlFile, key .. "#rate", "number") or 0
        })
    end)
    s.promos = {}
    xmlFile:iterate(root .. ".promos.promo", function(_, key)
        local promo = readRecord(xmlFile, key, PROMO_FIELDS)
        if promo.brand ~= nil and promo.endMonth ~= nil then
            s.promos[promo.brand] = promo
            promo.brand = nil
        end
    end)
    s.touchedFarmlands = {}
    xmlFile:iterate(root .. ".touched.f", function(_, key)
        local id = xmlFile:getString(key .. "#id")
        if id ~= nil then
            s.touchedFarmlands[id] = true
        end
    end)

    xmlFile:iterate(root .. ".farm", function(_, key)
        local farmId = xmlFile:getInt(key .. "#farmId")
        if farmId == nil then
            return
        end
        local farm = {
            farmId = farmId,
            lastScore = xmlFile:getInt(key .. "#lastScore"),
            history = FF.Credit.newHistory(),
            ledger = {interestPaid = 0, principalPaid = 0, rentPaid = 0, rentIncome = 0},
            loans = {},
            closed = {},
            land = {},
            income = {months = {}, current = {income = 0, opex = 0}}
        }
        local history = readRecord(xmlFile, key .. ".history", HISTORY_FIELDS)
        for name, value in pairs(history) do
            farm.history[name] = value
        end
        farm.history.recentLate = U.numberList(xmlFile:getString(key .. ".history#recentLate") or "")
        local ledger = readRecord(xmlFile, key .. ".ledger", LEDGER_FIELDS)
        for name, value in pairs(ledger) do
            farm.ledger[name] = value
        end
        if xmlFile:hasProperty(key .. ".review") then
            farm.review = readRecord(xmlFile, key .. ".review", REVIEW_FIELDS)
        end
        farm.income.current.income = getField(xmlFile, key .. ".income#currentIncome", "number") or 0
        farm.income.current.opex = getField(xmlFile, key .. ".income#currentOpex", "number") or 0
        xmlFile:iterate(key .. ".income.m", function(_, monthKey)
            table.insert(farm.income.months, {
                income = getField(xmlFile, monthKey .. "#income", "number") or 0,
                opex = getField(xmlFile, monthKey .. "#opex", "number") or 0
            })
        end)
        xmlFile:iterate(key .. ".loan", function(_, loanKey)
            local loan = readRecord(xmlFile, loanKey, LOAN_FIELDS)
            if loan.id ~= nil and loan.balance ~= nil then
                loan.farmId = farmId
                loan.lateMonths = loan.lateMonths or 0
                loan.monthsLeft = loan.monthsLeft or 1
                loan.rate = loan.rate or 0
                loan.payment = loan.payment or 0
                loan.status = loan.status or "active"
                farm.loans[loan.id] = loan
            end
        end)
        xmlFile:iterate(key .. ".closed", function(_, loanKey)
            local loan = readRecord(xmlFile, loanKey, LOAN_FIELDS)
            if loan.id ~= nil then
                loan.farmId = farmId
                table.insert(farm.closed, loan)
            end
        end)
        xmlFile:iterate(key .. ".land", function(_, landKey)
            local contract = readRecord(xmlFile, landKey, LAND_FIELDS)
            if contract.id ~= nil and contract.farmlandId ~= nil and contract.annualRent ~= nil then
                contract.farmId = farmId
                contract.leaseType = contract.leaseType or "cash"
                farm.land[contract.id] = contract
            end
        end)

        if xmlFile:hasProperty(key .. ".cropShare") then
            local share = {
                lots = {},
                lastPrice = {},
                stats = {},
                inputs = {},
                pendingInputCredit = getField(xmlFile, key .. ".cropShare#pendingInputCredit", "number") or 0
            }
            xmlFile:iterate(key .. ".cropShare.lot", function(_, lotKey)
                local lot = readRecord(xmlFile, lotKey, LOT_FIELDS)
                if lot.fillType ~= nil and (lot.liters or 0) > 0 then
                    table.insert(share.lots, lot)
                end
            end)
            xmlFile:iterate(key .. ".cropShare.price", function(_, priceKey)
                local fillType = xmlFile:getString(priceKey .. "#fillType")
                local value = getField(xmlFile, priceKey .. "#value", "number")
                if fillType ~= nil and value ~= nil then
                    share.lastPrice[fillType] = value
                end
            end)
            xmlFile:iterate(key .. ".cropShare.stat", function(_, statKey)
                table.insert(share.stats, readRecord(xmlFile, statKey, SHARE_STAT_FIELDS))
            end)
            xmlFile:iterate(key .. ".cropShare.input", function(_, inputKey)
                table.insert(share.inputs, readRecord(xmlFile, inputKey, SHARE_INPUT_FIELDS))
            end)
            farm.cropShare = share
        end

        if xmlFile:hasProperty(key .. ".inputs") then
            local account = {
                autoCharge = xmlFile:getBool(key .. ".inputs#autoCharge") ~= false,
                gpsBilling = xmlFile:getString(key .. ".inputs#gpsBilling"),
                discounts = getField(xmlFile, key .. ".inputs#discounts", "number") or 0,
                interestPaid = getField(xmlFile, key .. ".inputs#interestPaid", "number") or 0,
                charges = {}
            }
            xmlFile:iterate(key .. ".inputs.charge", function(_, chargeKey)
                local charge = readRecord(xmlFile, chargeKey, CHARGE_FIELDS)
                if charge.remaining ~= nil and charge.remaining > 0 and charge.dueCropYear ~= nil then
                    charge.missedDue = charge.missedDue == true
                    table.insert(account.charges, charge)
                end
            end)
            farm.inputs = account
        end
        farm.leases = {}
        xmlFile:iterate(key .. ".lease", function(_, leaseKey)
            local lease = readRecord(xmlFile, leaseKey, LEASE_FIELDS)
            if lease.id ~= nil and lease.payment ~= nil then
                lease.farmId = farmId
                lease.monthsLeft = lease.monthsLeft or 0
                lease.status = lease.status or "active"
                farm.leases[lease.id] = lease
            end
        end)
        if xmlFile:hasProperty(key .. ".line") then
            local line = readRecord(xmlFile, key .. ".line", LINE_FIELDS)
            if line.open then
                line.limit = line.limit or 0
                line.balance = line.balance or 0
                line.cleanedThisYear = line.cleanedThisYear == true
                farm.line = line
            end
        end
        s.farms[tostring(farmId)] = farm
    end)

    xmlFile:delete()
    return s
end

return P
