-- FS25_FarmFinance - equipment finance, dealer promos and term leases (pure rules).
--
-- Financing at purchase
--   The shop's Finance / Lease button asks for a pre-approval. On approval the
--   money is paid into the farm account at once and the player presses the
--   shop's normal Buy. When the matching purchase charge arrives the deal is
--   bound to that purchase; if none arrives within PENDING_MS it is reversed.
--   The bought machine is the loan's collateral: selling it pays the loan off.
-- Dealer promos
--   Each month a few brands run 0% financing on new machines; buying those
--   brands for cash earns a rebate instead (the cash discount given up for 0%).
-- Term leases
--   Payment = drop from price to residual, plus interest (machinery rate +
--   spread). The machine is the farm's to use (OWNED in the game) but stays
--   the lessor's: it can't be sold, doesn't count as an asset, and at the end
--   is returned (extra hours and wear charged), bought out or extended.
-- Game calls go through FF.env and FF.env.equipment:
--   getUniqueId(vehicle), findVehicle(uid), getHours(vehicle),
--   getWearCost(vehicle), deleteVehicle(vehicle),
--   projectResidual(storeXml, price, months, hours), listPromoBrands(),
--   findNewVehicle(farmId, storeXml, excludeUids)

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region
local LM = FF.LoanMath
local C = FF.Credit

FF.Equipment = {}
local EQ = FF.Equipment

EQ.PENDING_MS = 300000
EQ.pending = EQ.pending or {}

local function env()
    return FF.env or {}
end

local function eqEnv()
    return env().equipment or {}
end

local function addMoney(amount, farmId, typeKey)
    if amount ~= 0 and env().addMoney ~= nil then
        env().addMoney(amount, farmId, typeKey)
    end
end

local function notify(farmId, text, isWarning)
    if env().notify ~= nil then
        env().notify(farmId, text, isWarning)
    end
end

local function markDirty()
    if env().markDirty ~= nil then
        env().markDirty()
    end
end

local function random()
    if env().random ~= nil then
        return env().random()
    end
    return math.random()
end

local function sameFile(a, b)
    return a ~= nil and b ~= nil and string.lower(tostring(a)) == string.lower(tostring(b))
end

-- Promos -------------------------------------------------------------------------------

function EQ.getPromo(brandName)
    if brandName == nil or FF.state == nil or R.get("equipment.promo.enabled", true) == false then
        return nil
    end
    local promo = (FF.state.promos or {})[brandName]
    if promo ~= nil and promo.endMonth >= FF.state.monthIndex then
        return promo
    end
    return nil
end

function EQ.refreshPromos()
    local s = FF.state
    s.promos = s.promos or {}
    for brand, promo in pairs(s.promos) do
        if promo.endMonth < s.monthIndex then
            s.promos[brand] = nil
        end
    end
    if R.get("equipment.promo.enabled", true) == false or eqEnv().listPromoBrands == nil then
        return
    end
    local candidates = {}
    for _, brand in ipairs(eqEnv().listPromoBrands() or {}) do
        if s.promos[brand] == nil then
            candidates[#candidates + 1] = brand
        end
    end
    local wanted = R.get("equipment.promo.brandsPerMonth", 2) - U.count(s.promos)
    local monthsOptions = R.get("equipment.promo.months", {60})
    while wanted > 0 and #candidates > 0 do
        local index = math.min(#candidates, math.floor(random() * #candidates) + 1)
        local brand = table.remove(candidates, index)
        local months = monthsOptions[math.min(#monthsOptions, math.floor(random() * #monthsOptions) + 1)] or 60
        s.promos[brand] = {
            months = months,
            rebate = R.get("equipment.promo.rebate", 0.06),
            startMonth = s.monthIndex,
            endMonth = s.monthIndex + R.get("equipment.promo.durationMonths", 2) - 1
        }
        wanted = wanted - 1
    end
end

-- Quotes ---------------------------------------------------------------------------------

function EQ.quoteLoan(farmId, args)
    local evaluation = FF.Bank.evaluate(farmId)
    local price = args.price or 0
    local downShare = args.downShare or R.get("equipment.loan.minDownPayment", 0.10)
    local quote = {
        kind = args.usePromo and "promo" or "loan",
        price = price,
        down = math.floor(price * downShare + 0.5),
        score = evaluation.score,
        grade = evaluation.grade
    }
    quote.financed = price - quote.down
    local promo = args.usePromo and EQ.getPromo(args.brand) or nil
    if args.usePromo then
        quote.months = promo ~= nil and promo.months or 60
        quote.rate = 0
    else
        quote.months = math.floor((args.termYears or 5) * 12 + 0.5)
        quote.rate = C.rateFor(FF.state.baseRate or 0.065, "equipment", evaluation.score)
        if args.isSale then
            quote.rate = quote.rate + R.get("equipment.loan.usedSpread", 0.015)
        end
    end
    quote.payment = LM.payment(quote.financed, quote.rate, quote.months)

    local snapshot = evaluation.snapshot
    local capacity = C.capacityLimit(snapshot, evaluation.ratios, quote.rate, quote.months)
    local solvencyRoom = 0.80 * ((snapshot.totalAssets or 0) + price) - (snapshot.totalDebt or 0)
    if args.usePromo and (promo == nil or args.isSale) then
        quote.reason = "ff_reason_noPromo"
    elseif downShare + 1e-9 < R.get("equipment.loan.minDownPayment", 0.10) then
        quote.reason = "ff_reason_downPayment"
    elseif evaluation.score < R.get("credit.minScore", 580) then
        quote.reason = "ff_reason_score"
    elseif quote.financed < R.get("loans.minAmount", 5000) then
        quote.reason = "ff_reason_tooSmall"
    elseif capacity ~= nil and quote.financed > capacity then
        quote.reason = "ff_reason_capacity"
    elseif quote.financed > solvencyRoom then
        quote.reason = "ff_reason_noRoom"
    else
        quote.approved = true
    end
    return quote
end

function EQ.quoteLease(farmId, args)
    local evaluation = FF.Bank.evaluate(farmId)
    local price = args.price or 0
    local months = math.floor((args.termYears or 3) * 12 + 0.5)
    local hoursPerYear = args.hoursPerYear or 600
    local projected = args.residual
    if projected == nil and eqEnv().projectResidual ~= nil then
        projected = eqEnv().projectResidual(args.storeXml, price, months, hoursPerYear * months / 12)
    end
    projected = projected or price * 0.5
    local residual = math.floor(projected * (1 - R.get("equipment.lease.residualMargin", 0.05)) + 0.5)
    local rate = C.rateFor(FF.state.baseRate or 0.065, "equipment", evaluation.score) + R.get("equipment.lease.spread", 0.005)
    local payment = LM.payment(price - LM.presentValue(residual, rate, months), rate, months)
    local quote = {
        kind = "lease",
        price = price,
        months = months,
        hoursPerYear = hoursPerYear,
        residual = residual,
        rate = rate,
        payment = payment,
        deposit = math.floor(payment * R.get("equipment.lease.depositPayments", 1) + 0.5),
        score = evaluation.score,
        grade = evaluation.grade
    }
    quote.upfront = payment + quote.deposit

    local snapshot = evaluation.snapshot
    local ratios = evaluation.ratios
    local capacityOk = true
    if ratios.hasIncomeHistory then
        local strongTDC = R.getRatio("termDebtCoverage") or 1.25
        local room = math.max(ratios.netOperatingIncome, 0) / strongTDC - (snapshot.debtService12 or 0)
        capacityOk = payment * 12 <= room
    end
    if R.get("equipment.lease.enabled", true) == false then
        quote.reason = "ff_reason_productDisabled"
    elseif evaluation.score < R.get("credit.minScore", 580) then
        quote.reason = "ff_reason_score"
    elseif not capacityOk then
        quote.reason = "ff_reason_capacity"
    elseif price < R.get("loans.minAmount", 5000) then
        quote.reason = "ff_reason_tooSmall"
    else
        quote.approved = true
    end
    return quote
end

-- Pre-approval and binding ------------------------------------------------------------------

local function now()
    if env().now ~= nil then
        return env().now()
    end
    return 0
end

local function getLeases(farm)
    farm.leases = farm.leases or {}
    return farm.leases
end

-- Server action. args: kind ("loan"|"promo"|"lease"), price, storeXml,
-- storeName, brand, isSale, downShare, termYears, hoursPerYear.
function EQ.preApprove(farmId, args)
    local farm = FF.Bank.getFarm(farmId)
    for _, pending in ipairs(EQ.pending) do
        if pending.farmId == farmId then
            return false, "ff_reason_pendingDeal"
        end
    end
    local pending = {
        farmId = farmId,
        kind = args.kind,
        price = args.price,
        storeXml = args.storeXml,
        storeName = args.storeName,
        expires = now() + EQ.PENDING_MS,
        -- machines the farm already has: the bought one is the one not in here
        knownUids = eqEnv().listUids ~= nil and eqEnv().listUids(farmId) or {}
    }
    if args.kind == "lease" then
        local quote = EQ.quoteLease(farmId, args)
        if not quote.approved then
            return false, quote.reason
        end
        local lease = {
            id = FF.Bank.nextId("E"),
            farmId = farmId,
            storeXml = args.storeXml,
            name = args.storeName,
            price = quote.price,
            payment = quote.payment,
            residual = quote.residual,
            deposit = quote.deposit,
            rate = quote.rate,
            months = quote.months,
            monthsLeft = quote.months,
            hoursPerYear = quote.hoursPerYear,
            startMonth = FF.state.monthIndex,
            status = "pending"
        }
        getLeases(farm)[lease.id] = lease
        pending.refKind = "lease"
        pending.refId = lease.id
        addMoney(quote.price, farmId, "leaseFunding")
        notify(farmId, U.text("ff_msg_leaseApproved", args.storeName or "?", U.money(quote.payment)), false)
    else
        local quote = EQ.quoteLoan(farmId, {
            price = args.price, downShare = args.downShare, termYears = args.termYears,
            usePromo = args.kind == "promo", brand = args.brand, isSale = args.isSale
        })
        if not quote.approved then
            return false, quote.reason
        end
        local loan = FF.Bank.createLoan(farmId, {
            productId = "equipment",
            amount = quote.financed,
            months = quote.months,
            rate = quote.rate,
            source = args.kind == "promo" and "promo" or "shop",
            label = args.storeName
        })
        loan.pendingPurchase = true
        pending.refKind = "loan"
        pending.refId = loan.id
        notify(farmId, U.text("ff_msg_financeApproved", U.money(quote.financed), args.storeName or "?"), false)
    end
    table.insert(EQ.pending, pending)
    markDirty()
    return true
end

local function findPending(farmId, storeXml, cost)
    for index, pending in ipairs(EQ.pending) do
        local tolerance = math.max(1, (pending.price or 0) * 0.01)
        if pending.farmId == farmId and not pending.charged
                and (storeXml == nil or sameFile(pending.storeXml, storeXml))
                and math.abs((pending.price or 0) - cost) <= tolerance then
            return pending, index
        end
    end
    return nil
end

-- A shop purchase charge was matched (server). buyInfo: storeXml, brand,
-- isSale. Returns what happened: "financed", "leased", "rebate" or nil.
function EQ.onShopPurchase(farmId, cost, buyInfo)
    buyInfo = buyInfo or {}
    local pending = findPending(farmId, buyInfo.storeXml, cost)
    local farm = FF.Bank.getFarm(farmId)
    if pending ~= nil then
        pending.charged = true
        pending.expires = now() + EQ.PENDING_MS
        if pending.refKind == "lease" then
            local lease = getLeases(farm)[pending.refId]
            if lease ~= nil then
                lease.status = "awaitingVehicle"
                -- first payment in advance plus the security deposit
                addMoney(-lease.payment, farmId, "leasePayment")
                addMoney(-lease.deposit, farmId, "leaseDeposit")
                lease.monthsLeft = math.max(lease.months - 1, 0)
            end
            markDirty()
            return "leased"
        end
        local loan = farm.loans[pending.refId]
        if loan ~= nil then
            loan.pendingPurchase = nil
            loan.awaitingVehicle = true
        end
        markDirty()
        return "financed"
    end
    local promo = not buyInfo.isSale and EQ.getPromo(buyInfo.brand) or nil
    if promo ~= nil and cost >= R.get("equipment.promo.minPrice", 30000) then
        local rebate = math.floor(cost * promo.rebate + 0.5)
        addMoney(rebate, farmId, "dealerRebate")
        notify(farmId, U.text("ff_msg_dealerRebate", U.money(rebate), buyInfo.brand), false)
        return "rebate"
    end
    return nil
end

-- Ties charged deals to the machine that arrived (called every second).
function EQ.bindVehicles()
    if eqEnv().findNewVehicle == nil then
        return
    end
    for _, pending in ipairs(EQ.pending) do
        if pending.charged and not pending.bound then
            local exclude = EQ.getBoundUids()
            for uid in pairs(pending.knownUids or {}) do
                exclude[uid] = true
            end
            local vehicle, uid = eqEnv().findNewVehicle(pending.farmId, pending.storeXml, exclude)
            if uid ~= nil then
                local farm = FF.Bank.getFarm(pending.farmId)
                if pending.refKind == "lease" then
                    local lease = getLeases(farm)[pending.refId]
                    if lease ~= nil then
                        lease.vehicleUid = uid
                        lease.status = "active"
                    end
                else
                    local loan = farm.loans[pending.refId]
                    if loan ~= nil then
                        loan.collateralUid = uid
                        loan.awaitingVehicle = nil
                    end
                end
                pending.bound = true
                markDirty()
            end
        end
    end
    for index = #EQ.pending, 1, -1 do
        if EQ.pending[index].bound then
            table.remove(EQ.pending, index)
        end
    end
end

-- Reverses deals whose purchase never happened.
function EQ.expirePending()
    local t = now()
    for index = #EQ.pending, 1, -1 do
        local pending = EQ.pending[index]
        if t > pending.expires then
            table.remove(EQ.pending, index)
            local farm = FF.Bank.getFarm(pending.farmId)
            if not pending.charged then
                if pending.refKind == "lease" then
                    local lease = getLeases(farm)[pending.refId]
                    if lease ~= nil then
                        addMoney(-lease.price, pending.farmId, "leaseFunding")
                        getLeases(farm)[pending.refId] = nil
                    end
                else
                    local loan = farm.loans[pending.refId]
                    if loan ~= nil then
                        addMoney(-loan.balance, pending.farmId, "loanProceeds")
                        farm.loans[pending.refId] = nil
                    end
                end
                notify(pending.farmId, U.text("ff_msg_dealCancelled", pending.storeName or "?"), true)
            else
                -- charged but the machine was never found: keep the deal unbound
                local lease = getLeases(farm)[pending.refId]
                if lease ~= nil and lease.status == "awaitingVehicle" then
                    lease.status = "active"
                end
            end
            markDirty()
        end
    end
end

function EQ.getBoundUids()
    local uids = {}
    if FF.state == nil then
        return uids
    end
    for _, farm in pairs(FF.state.farms) do
        for _, lease in pairs(farm.leases or {}) do
            if lease.vehicleUid ~= nil then
                uids[lease.vehicleUid] = true
            end
        end
        for _, loan in pairs(farm.loans or {}) do
            if loan.collateralUid ~= nil then
                uids[loan.collateralUid] = true
            end
        end
    end
    return uids
end

-- Leases --------------------------------------------------------------------------------------

function EQ.getLeaseByUid(uid)
    if uid == nil or FF.state == nil then
        return nil
    end
    for _, farm in pairs(FF.state.farms) do
        for _, lease in pairs(farm.leases or {}) do
            if lease.vehicleUid == uid and lease.status == "active" then
                return lease, farm
            end
        end
    end
    return nil
end

function EQ.isLeased(uid)
    return EQ.getLeaseByUid(uid) ~= nil
end

-- What ending the lease would cost right now. vehicle may be nil when the
-- machine can't be found (then only the contract amounts count).
function EQ.getLeaseSettlement(lease, vehicle)
    local monthsLeft = math.max(lease.monthsLeft or 0, 0)
    local remainingPV = LM.principalForPayment(lease.payment, lease.rate, monthsLeft)
    local residualPV = LM.presentValue(lease.residual, lease.rate, monthsLeft)
    local result = {
        monthsLeft = monthsLeft,
        buyout = remainingPV + residualPV,
        earlyPayments = remainingPV,
        deposit = lease.deposit or 0,
        excessHours = 0,
        excessCharge = 0,
        wear = 0
    }
    if vehicle ~= nil then
        local hours = eqEnv().getHours ~= nil and eqEnv().getHours(vehicle) or 0
        local yearsUsed = math.max((lease.months - monthsLeft) / 12, 1 / 12)
        local allowed = (lease.hoursPerYear or 600) * yearsUsed
        result.hours = hours
        result.excessHours = math.max(hours - allowed, 0)
        result.excessCharge = result.excessHours * lease.price * R.get("equipment.lease.excessHourShare", 0.0002)
        result.wear = eqEnv().getWearCost ~= nil and (eqEnv().getWearCost(vehicle) or 0) or 0
    end
    result.returnCost = result.earlyPayments + result.excessCharge + result.wear - result.deposit
    return result
end

local function findLease(farmId, leaseId)
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return nil
    end
    local lease = getLeases(farm)[leaseId]
    if lease == nil or lease.status ~= "active" then
        return nil
    end
    return lease, farm
end

local function findVehicle(lease)
    if lease.vehicleUid == nil or eqEnv().findVehicle == nil then
        return nil
    end
    return eqEnv().findVehicle(lease.vehicleUid)
end

function EQ.returnLease(farmId, leaseId)
    local lease, farm = findLease(farmId, leaseId)
    if lease == nil then
        return false, "ff_reason_noLease"
    end
    local vehicle = findVehicle(lease)
    if vehicle == nil then
        return false, "ff_reason_leaseVehicleMissing"
    end
    local settlement = EQ.getLeaseSettlement(lease, vehicle)
    if settlement.earlyPayments > 0 then
        addMoney(-settlement.earlyPayments, farmId, "leasePayment")
    end
    if settlement.excessCharge + settlement.wear > 0 then
        addMoney(-(settlement.excessCharge + settlement.wear), farmId, "leaseReturn")
    end
    if settlement.deposit > 0 then
        addMoney(settlement.deposit, farmId, "leaseDeposit")
    end
    getLeases(farm)[leaseId] = nil
    if eqEnv().deleteVehicle ~= nil then
        eqEnv().deleteVehicle(vehicle)
    end
    notify(farmId, U.text("ff_msg_leaseReturned", lease.name or "?", U.money(settlement.excessCharge + settlement.wear)), false)
    markDirty()
    return true
end

function EQ.buyoutLease(farmId, leaseId)
    local lease, farm = findLease(farmId, leaseId)
    if lease == nil then
        return false, "ff_reason_noLease"
    end
    local settlement = EQ.getLeaseSettlement(lease, nil)
    local net = settlement.buyout - settlement.deposit
    if env().getMoney ~= nil and env().getMoney(farmId) < net then
        return false, "ff_reason_noCash"
    end
    addMoney(-settlement.buyout, farmId, "leaseBuyout")
    addMoney(settlement.deposit, farmId, "leaseDeposit")
    getLeases(farm)[leaseId] = nil
    notify(farmId, U.text("ff_msg_leaseBoughtOut", lease.name or "?", U.money(settlement.buyout)), false)
    markDirty()
    return true
end

-- Extends a finished lease by a year on the depreciated residual.
function EQ.extendLease(farmId, leaseId)
    local lease = findLease(farmId, leaseId)
    if lease == nil then
        return false, "ff_reason_noLease"
    end
    if (lease.monthsLeft or 0) > 0 then
        return false, "ff_reason_leaseNotEnded"
    end
    local newResidual = math.floor(lease.residual * (1 - R.get("equipment.lease.extendDepreciation", 0.12)) + 0.5)
    lease.payment = LM.payment(lease.residual - LM.presentValue(newResidual, lease.rate, 12), lease.rate, 12)
    lease.residual = newResidual
    lease.months = lease.months + 12
    lease.monthsLeft = 12
    lease.endNotified = nil
    markDirty()
    return true
end

-- Monthly lease payments. Past the end of the term the lease runs on at the
-- same payment (holdover) until the machine is returned, bought or extended.
function EQ.billLeases(farm)
    local billed = 0
    for _, id in ipairs(U.sortedKeys(farm.leases or {})) do
        local lease = farm.leases[id]
        if lease.status == "active" then
            addMoney(-lease.payment, farm.farmId, "leasePayment")
            billed = billed + lease.payment
            if lease.monthsLeft > 0 then
                lease.monthsLeft = lease.monthsLeft - 1
            end
            if lease.monthsLeft == 0 and not lease.endNotified then
                lease.endNotified = true
                notify(farm.farmId, U.text("ff_msg_leaseEnded", lease.name or "?", U.money(lease.residual)), false)
            end
        end
    end
    return billed
end

-- Yearly lease cost for credit (term debt and lease coverage).
function EQ.getLeasePayments12(farm)
    local total = 0
    for _, lease in pairs(farm.leases or {}) do
        if lease.status == "active" then
            total = total + lease.payment * 12
        end
    end
    return total
end

-- Collateral ---------------------------------------------------------------------------------

-- A machine was sold: pay off the loans it secured from the proceeds.
function EQ.onVehicleSold(farmId, uid)
    if uid == nil then
        return 0
    end
    local farm = FF.Bank.getFarm(farmId, false)
    if farm == nil then
        return 0
    end
    local paid = 0
    for _, id in ipairs(U.sortedKeys(farm.loans)) do
        local loan = farm.loans[id]
        if loan ~= nil and loan.collateralUid == uid and loan.balance > 0 then
            local balance = loan.balance
            FF.Bank.payExtraForced(farmId, id, balance)
            paid = paid + balance
            notify(farmId, U.text("ff_msg_collateralPaidOff", loan.label or "?", U.money(balance)), false)
        end
    end
    return paid
end

function EQ.processMonth(farm, period)
    return EQ.billLeases(farm)
end

-- Pending deals don't survive a save: a deal saved before its purchase is
-- reversed on load; one already paid but not yet tied to a machine runs on
-- without a machine link.
function EQ.cleanupAfterLoad()
    EQ.pending = {}
    if FF.state == nil then
        return
    end
    for _, farm in pairs(FF.state.farms) do
        for _, id in ipairs(U.sortedKeys(farm.loans or {})) do
            local loan = farm.loans[id]
            if loan.pendingPurchase then
                addMoney(-loan.balance, farm.farmId, "loanProceeds")
                farm.loans[id] = nil
            end
            if loan.awaitingVehicle then
                loan.awaitingVehicle = nil
            end
        end
        for _, id in ipairs(U.sortedKeys(farm.leases or {})) do
            local lease = farm.leases[id]
            if lease.status == "pending" then
                addMoney(-lease.price, farm.farmId, "leaseFunding")
                farm.leases[id] = nil
            elseif lease.status == "awaitingVehicle" then
                lease.status = "active"
            end
        end
    end
end

return EQ
