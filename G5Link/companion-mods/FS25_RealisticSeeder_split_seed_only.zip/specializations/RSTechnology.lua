-- Independent retrofit configurations; the native shop owns payment and persistence.
RSTechnology={modules={
 {name="rsLogger",title="FieldPath logger",capability="settingsLogging",planter=1500,drill=1500},
 {name="rsSeedMonitor",title="Seed monitoring",capability="seedMonitor",planter=3000,drill=2000},
 {name="rsDepthSensor",title="Depth sensing",capability="depthSensor",planter=3000,drill=2500},
 {name="rsMeterDrive",title="Powered metering",capability="cabRateControl",planter=5000,drill=4000}}}
local T=RSTechnology
function T.register(manager)
 for _,m in ipairs(T.modules) do
  if manager:getConfigurationDescByName(m.name)==nil then manager:addConfigurationType(m.name,m.title,"rsPlacement",VehicleConfigurationItem) end
 end
end
function T.factory(xml,filename,configurations)
 local filename=(filename or ''):lower():gsub('\\','/')
 local kinze=filename:match('/kinze/planter4900/planter4900.xml$')~=nil
 local p={equipment={},equipmentCheck='Installed equipment',rowCount=0}
 for cap in pairs(T.capabilities) do
  local value=getXMLBool(xml.handle,'vehicle.rsPlacement#'..cap)
  if value==nil then value=kinze and (cap=='settingsLogging' or cap=='seedMonitor' or cap=='cabRateControl') end
  p[cap]=value==true
 end
 local rows=tonumber(getXMLString(xml.handle,'vehicle.rsPlacement#rowCount'))
 if rows and rows==math.floor(rows) and rows>=1 and rows<=24 then p.rowCount=rows end
 if filename:match('/fs25_johndeere_1760/1760_12row.xml$') then p.rowCount=12;p.recognizedCleanerOptions=true end
 if configurations~=nil and filename:match('/fs25_johndeere_1760/1760_12row.xml$') then
  configurations=configurations or {}
  local function selected(name)
   local item=g_storeManager:getItemByXMLFilename(filename)
   local items=item and item.configurations and item.configurations[name]
   return items and items[configurations[name] or 1]
  end
  local cleaners=selected('design6')
  if cleaners and cleaners.name=='Precision Plant Air adjust row cleaners' then
   p.rowCleaners='pneumatic';p.rowCleanerCabAdjustment=true
   p.equipment[#p.equipment+1]='Air-adjust row cleaners (existing hydraulic-axis control)'
  end
  for _,entry in ipairs({{'design5','Gauge wheels'},{'design2','Left closing wheel'},{'design3','Right closing wheel'}}) do
   local item=selected(entry[1]);if item then p.equipment[#p.equipment+1]=entry[2]..': '..item.name end
  end
 end
 if p.automaticDownforce then p.cabDownforceControl=true;p.downforceSensor=true end
 if p.automaticClosing then p.improvedClosing=true;p.closingSensor=true;p.cabClosingControl=true end
 if p.rowDrive then p.cabRateControl=true end
 return p
end
function T.getConfigurations(manager,original,xml,key,baseDir,environment,isMod,storeItem)
 if manager~=g_vehicleConfigurationManager then return original(manager,xml,key,baseDir,environment,isMod,storeItem) end
 T.register(manager)
 local configs,defaults=original(manager,xml,key,baseDir,environment,isMod,storeItem)
 if key~='vehicle' or not xml:hasProperty('vehicle.sowingMachine') or getXMLBool(xml.handle,'vehicle.sowingMachine.waterSeeding#value')==true then return configs,defaults end
 local kind=tostring(getXMLString(xml.handle,'vehicle.storeData.category') or ''):lower()=='planters' and 'planter' or 'drill'
 local explicit=getXMLString(xml.handle,'vehicle.rsPlacement#kind');if explicit=='planter' or explicit=='drill' then kind=explicit end
 local factory=T.factory(xml,storeItem and storeItem.xmlFilename)
 configs=configs or {};defaults=defaults or {}
 for _,m in ipairs(T.modules) do
  if not configs[m.name] and (not m.kind or m.kind==kind) and (not m.cleaners or factory.recognizedCleanerOptions or factory.rowCleanerCabAdjustment) then
   local options=T.options(m,kind,factory)
   local items={}
   for index=1,#options+1 do
    local option=options[index-1]
    local item=VehicleConfigurationItem.new(m.name);item:setIndex(index)
    item.configKey=string.format('vehicle.rsPlacement.%sConfigurations.%sConfiguration(%d)',m.name,m.name,index-1)
    item.name=option and option.title or (factory[m.capability] and 'Factory fitted' or 'Standard / not fitted')
    item.saveId=option and option.id or 'standard';item.price=option and option[kind] or 0;item.isDefault=index==1
    item.desc=m.description or 'Staged simulation hardware. Sensing and automatic control are separate capabilities. Prices are gameplay values.'
    items[index]=item
   end
   configs[m.name]=items;defaults[m.name]=1
  end
 end
 return configs,defaults
end
function T.apply(profile,configurations,filename,xml)
 if xml then for key,value in pairs(T.factory(xml,filename,configurations)) do profile[key]=value end end
 profile.technologyModules={};profile.technologyLabels={};profile.technologyWarnings={}
 for _,m in ipairs(T.modules) do
  local index=configurations and configurations[m.name] or 1
  local item=filename and ConfigurationUtil.getConfigItemByConfigId(filename,m.name,index)
  local chosen
  for _,o in ipairs(m.options or {{id='retrofit',caps={m.capability}}}) do if item and item.saveId==o.id then chosen=o end end
  for _,o in ipairs(m.extra or {}) do if item and item.saveId==o.id then chosen=o end end
  if chosen and (not m.kind or profile.kind==m.kind) then for _,cap in ipairs(chosen.caps) do profile[cap]=true end else chosen=nil end
  profile.technologyModules[m.name]=chosen and 'retrofit' or (profile[m.capability] and 'factory' or 'notFitted')
  profile.technologyLabels[m.name]=chosen and item.name or (profile[m.capability] and 'Factory fitted' or 'Not fitted')
 end
 if profile.rowDrive and ((profile.rowCount or 0)<1 or profile.kind~='planter') then
  profile.rowDrive=false;profile.technologyWarnings[#profile.technologyWarnings+1]='Row drive: a supported row layout is required.'
 end
 if profile.rowCleanerDisplayControl and not profile.rowCleanerCabAdjustment then
  profile.rowCleanerDisplayControl=false;profile.technologyWarnings[#profile.technologyWarnings+1]='Row cleaner interface: fit the recognized air-adjust cleaners first.'
 end
 profile.automaticDepth=profile.cabDepthControl==true and profile.soilSensor==true
 profile.controlledDelivery=profile.controlledDeliveryHardware==true and profile.precisionMeter==true and profile.cabRateControl==true
 if profile.controlledDeliveryHardware and not profile.controlledDelivery then profile.technologyWarnings[#profile.technologyWarnings+1]='Controlled delivery inactive: precision and powered metering are both required.' end
 return profile
end
function T.describe(profile)
 local lines={profile.equipmentCheck or 'Equipment profile'}
 for _,m in ipairs(T.modules) do if not m.kind or m.kind==profile.kind then lines[#lines+1]=m.title..': '..(profile.technologyLabels and profile.technologyLabels[m.name] or (profile[m.capability] and 'Fitted' or 'Not fitted')) end end
 for _,name in ipairs(profile.equipment or {}) do lines[#lines+1]=name end
 for _,warning in ipairs(profile.technologyWarnings or {}) do lines[#lines+1]=warning end
 lines[#lines+1]='Other hardware may need an equipment profile. Individual upgrades are available through workshop customization.'
 return table.concat(lines,'\n')
end
if ConfigurationUtil and Utils then ConfigurationUtil.getConfigurationsFromXML=Utils.overwrittenFunction(ConfigurationUtil.getConfigurationsFromXML,T.getConfigurations) end
