-- Read the user's installed wheat assets at runtime. No game artwork is shipped.
local WV = WheatVarieties
local Tree = {}
WV.XmlTree = Tree

function Tree.read(handle, key)
    local node = { name = getXMLElementName(handle, key), attributes = {}, children = {} }
    assert(node.name ~= nil, "XML element missing: " .. key)
    for index = 0, getXMLNumOfAttributes(handle, key) - 1 do
        local name = getXMLAttributeName(handle, key, index)
        node.attributes[name] = getXMLString(handle, key .. "#" .. name)
    end
    local count = getXMLNumOfChildren(handle, key)
    if count == 0 then node.text = getXMLString(handle, key) end
    for index = 0, count - 1 do
        node.children[#node.children + 1] = Tree.read(handle, key .. ".*(" .. index .. ")")
    end
    return node
end

function Tree.load(path, root)
    local handle = loadXMLFile("wvRead", path)
    assert(handle ~= nil and handle ~= 0, "Cannot read " .. path)
    local ok, result = pcall(Tree.read, handle, root)
    delete(handle)
    assert(ok, result)
    return result
end

function Tree.child(node, name)
    for _, child in ipairs(node.children or {}) do
        if child.name == name then return child end
    end
end

function Tree.replaceChild(node, replacement)
    for index, child in ipairs(node.children) do
        if child.name == replacement.name then node.children[index] = replacement; return end
    end
    node.children[#node.children + 1] = replacement
end

function Tree.write(handle, key, node)
    setXMLString(handle, key, node.text or "") -- retain empty periods and states
    for _, name in ipairs(WV.sortedKeys(node.attributes)) do
        setXMLString(handle, key .. "#" .. name, node.attributes[name])
    end
    local counts = {}
    for _, child in ipairs(node.children) do
        local index = counts[child.name] or 0
        Tree.write(handle, key .. "." .. child.name .. "(" .. index .. ")", child)
        counts[child.name] = index + 1
    end
end

function Tree.save(path, node)
    local handle = createXMLFile("wvGenerated", path, node.name)
    assert(handle ~= nil and handle ~= 0, "Cannot create " .. path)
    local ok, message = pcall(function()
        Tree.write(handle, node.name, node)
        assert(saveXMLFile(handle), "Cannot save " .. path)
    end)
    delete(handle)
    assert(ok, message)
end

local pathAttributes = {
    shapeSource = true, distanceMap = true, distanceTexturePath = true,
    filename = true, hud = true, diffuse = true, normal = true,
    displacement = true, distance = true, diffuseMap = true, normalMap = true
}

function Tree.rebase(node, baseDirectory)
    for name, value in pairs(node.attributes) do
        -- Fill textures use a height map path; foliage heights are numeric.
        local isPath = pathAttributes[name] or (node.name == "textures" and name == "height")
        if isPath and value ~= "" and value:sub(1, 1) ~= "$"
            and value:sub(1, 1) ~= "/" and not value:match("^%a:")
            and not value:match("^data/") and not value:match("^dataS/") then
            node.attributes[name] = baseDirectory .. value
        end
    end
    -- A cached file must not retain a relative schema location from the install.
    node.attributes["xsi:noNamespaceSchemaLocation"] = nil
    for _, child in ipairs(node.children) do Tree.rebase(child, baseDirectory) end
end
