-- Retrofit catalog. Generic hardware, modeled on what is sold for real planters
-- and drills; prices are gameplay approximations of US list prices.
-- Price fields: base ($ per machine), row ($ per planter row), opener ($ per drill
-- opener), section ($ per drill section). A plain number is a flat price.
-- lanes=true: needs a known row count (planter) or working width (drill).
-- legacy=true: retired option, still honored for saves that bought it, never sold.
local T=RSTechnology
local function o(t) return t end
T.modules={
 {name='rsLogger',title='Monitor + logger',capability='settingsLogging',options={
  o{id='retrofit',title='Planter monitor + logger',caps={'settingsLogging'},planter={base=6500},
    description='In-cab planter monitor. Seed sensors, automatic control, soil sensing and GPS row shutoff report through it. Records settings and passes for FieldPath.'},
  o{id='retrofit',title='Seeding monitor + logger',caps={'settingsLogging'},drill={base=4000},
    description='In-cab seeding monitor. Blockage and seed counting sensors and GPS section control report through it. Records settings and passes for FieldPath.'}}},
 {name='rsSeedMonitor',title='Seed sensing',capability='seedMonitor',options={
  o{id='retrofit',title='Optical seed sensors (every row)',caps={'seedMonitor'},planter={row=150},
    description='Counts seeds in every seed tube: population, skips, doubles and singulation. Needs the planter monitor.'},
  o{id='blockage',title='Blockage sensors (every run)',caps={'blockageMonitor'},drill={opener=60},
    description='Flow sensors on the secondary hoses. Reports delivery misses, not seed counts. Needs the seeding monitor.'},
  o{id='retrofit',title='Seed counting sensors (every run)',caps={'seedMonitor'},drill={opener=250},
    description='Counts seed in every run: rate, misses and distribution. Needs the seeding monitor.'}}},
 {name='rsMeterDrive',title='Meter drive / row control',capability='cabRateControl',options={
  o{id='retrofit',title='Hydraulic variable-rate drive',caps={'cabRateControl'},planter={base=6000},
    description='Replaces the ground drive. Rate changes from the cab while planting; whole planter, no row shutoff.'},
  o{id='clutches',title='Ground drive + row clutches',caps={'rowShutoff'},planter={row=300},lanes=true,
    description='Electric clutch on every row: rows switch off from the cab or by GPS row shutoff. Rate stays set at the transmission.'},
  o{id='vrClutches',title='Hydraulic VR drive + row clutches',caps={'cabRateControl','rowShutoff'},planter={base=6000,row=300},lanes=true,
    description='Variable rate from the cab plus a clutch on every row for shutoff.'},
  o{id='rowDrive',title='Electric drive on every row',caps={'cabRateControl','rowShutoff','rowDrive'},planter={base=4000,row=1000},lanes=true,
    description='Electric motor on every meter, with an extra power supply: row shutoff and a rate per row (curve compensation, row trials).'},
  o{id='retrofit',title='Variable-rate meter drive',caps={'cabRateControl'},drill={base=5000},
    description='Hydraulic or electric meter drive. Rate changes from the cab; whole machine.'},
  o{id='sections',title='VR meter drive + section shutoff',caps={'cabRateControl','rowShutoff'},drill={base=5000,section=1500},lanes=true,
    description='Sectional meters: each section of the drill shuts off from the cab or by GPS section control.'}}},
 {name='rsAutoShutoff',title='Automatic GPS row / section shutoff',capability='autoShutoffController',options={
  o{id='retrofit',title='Automatic GPS row shutoff',caps={'autoShutoffController'},planter={base=1500},
    description='Monitor software unlock. Rows turn off over ground already planted. Needs the monitor and row clutches or electric drives. A G5Link Section Control activation does the same job.'},
  o{id='retrofit',title='Automatic GPS section control',caps={'autoShutoffController'},drill={base=1500},
    description='Monitor software unlock. Sections turn off over ground already seeded. Needs the monitor and section shutoff. A G5Link Section Control activation does the same job.'}}},
 {name='rsPrecisionMeter',title='Precision metering',capability='precisionMeter',options={
  o{id='retrofit',title='Precision vacuum meters',caps={'precisionMeter'},planter={row=450},
    description='Upgraded vacuum meters with better singulation at speed.'},
  o{id='retrofit',title='Crop-specific meter rollers',caps={'precisionMeter'},drill={base=400},
    description='Fine and coarse meter rollers matched to the seed. Steadier delivery and lower distribution CV.'}}},
 {name='rsDownforce',title='Opener downforce',capability='cabDownforceControl',options={
  o{id='cab',title='Air bag downforce, cab adjust',caps={'cabDownforceControl'},planter={base=4000,row=100},
    description='Air bags on every row with a compressor; pressure set from the cab.'},
  o{id='autoAir',title='Automatic air bag downforce',caps={'cabDownforceControl','downforceSensor','automaticDownforce'},planter={base=9000,row=150},
    description='Load pins on the gauge wheels hold margin automatically, one pressure for the whole planter. Needs the planter monitor.'},
  o{id='autoHydraulic',title='Hydraulic downforce, automatic per row',caps={'cabDownforceControl','downforceSensor','automaticDownforce'},planter={row=1100},
    description='Hydraulic cylinder and load pin on every row; each row adjusts on its own. Needs the planter monitor.'},
  o{id='cab',title='Hydraulic opener pressure, cab adjust',caps={'cabDownforceControl'},drill={base=5000,opener=50},
    description='Hydraulic opener pressure for the whole drill, set from the cab.'},
  o{id='sensed',title='Cab control + load sensing (retired)',caps={'cabDownforceControl','downforceSensor'},planter=6000,drill=6500,legacy=true},
  o{id='automatic',title='Automatic downforce system (retired)',caps={'cabDownforceControl','downforceSensor','automaticDownforce'},planter=14000,drill=12000,legacy=true}}},
 {name='rsClosing',title='Closing / packing system',capability='improvedClosing',options={
  o{id='manual',title='Aftermarket closing wheels',caps={'improvedClosing'},planter={row=150},
    description='Spiked or cast closing wheels for better seed-to-soil contact. Pressure set by hand.'},
  o{id='automatic',title='Hydraulic closing system, automatic',caps={'improvedClosing','closingSensor','cabClosingControl','automaticClosing'},planter={row=1000},
    description='Hydraulic closing-wheel pressure on every row, cab or automatic. Needs the planter monitor.'},
  o{id='manual',title='Aftermarket press wheels / seed firmers',caps={'improvedClosing'},drill={opener=40},
    description='Better press wheels or seed firmers on every opener. Pressure set by hand.'},
  o{id='sensed',title='Improved system + load sensing (retired)',caps={'improvedClosing','closingSensor'},planter=5000,drill=4500,legacy=true},
  o{id='automatic',title='Automatic closing / packing system (retired)',caps={'improvedClosing','closingSensor','cabClosingControl','automaticClosing'},drill=9000,legacy=true}}},
 {name='rsDepthControl',title='Depth adjustment',capability='cabDepthControl',options={
  o{id='retrofit',title='Powered row depth, with depth readout',caps={'cabDepthControl','depthSensor'},planter={row=700},
    description='Electric depth actuator on every row; reports the depth it holds. Add soil sensing for automatic depth.'},
  o{id='retrofit',title='Cab hydraulic depth (whole drill)',caps={'cabDepthControl'},drill={base=6000},
    description='Hydraulic depth control for the whole drill, set from the cab.'}}},
 {name='rsSoilSensor',title='Seed-zone soil sensing',capability='soilSensor',options={
  o{id='retrofit',title='Sensing seed firmers',caps={'soilSensor'},planter={row=600},
    description='Seed firmers that read furrow moisture and conditions. Needs the planter monitor; with powered depth it enables automatic depth.'},
  o{id='retrofit',title='Seed-zone soil sensing (retired)',caps={'soilSensor'},drill=3500,legacy=true}}},
 {name='rsSeedDelivery',title='High-speed seed delivery',capability='controlledDeliveryHardware',options={
  o{id='retrofit',title='Belt seed delivery',caps={'controlledDeliveryHardware'},planter={row=1100},
    description='Carries each seed to the furrow for accurate spacing at high speed. Needs precision meters AND electric row drives. Corn, soybeans, cotton and sugarbeets.'}}},
 {name='rsRowCleanerControl',title='Row cleaner control',capability='rowCleanerDisplayControl',cleaners=true,options={
  o{id='retrofit',title='Pneumatic row cleaner control',caps={'rowCleanerDisplayControl'},planter={base=2000,row=350},
    description='Cab control of the air-adjust row cleaners. Fit recognized air-adjust cleaners first; needs the planter monitor.'}}},
 {name='rsDepthSensor',title='Depth sensing',capability='depthSensor',options={
  o{id='retrofit',title='Depth sensing (retired)',caps={'depthSensor'},planter=3000,drill=2500,legacy=true}}},
}
T.capabilities={}
for _,m in ipairs(T.modules) do
 T.capabilities[m.capability]=true
 for _,opt in ipairs(m.options) do for _,cap in ipairs(opt.caps) do T.capabilities[cap]=true end end
end
T.capabilities.rowShutoff=true;T.capabilities.rowDrive=true
