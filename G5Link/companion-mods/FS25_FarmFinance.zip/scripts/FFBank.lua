-- FS25_FarmFinance - the bank: state, loans, monthly billing, market rate.
--
-- Pure rules. Everything that touches the game goes through FF.env, which
-- FFMain fills in with FS calls (and the offline tests fill with stubs):
--   env.getMoney(farmId), env.addMoney(amount, farmId, typeKey),
--   env.notify(farmId, text, isWarning), env.random(), env.getFarmIds(),
--   env.snapshot(farmId), env.markDirty()
-- Server only: clients receive the state over the network.

FarmFinance = FarmFinance or {}
local FF = FarmFinance
local U = FF.Util
local R = FF.Region
local LM = FF.LoanMath
local C = FF.Credit

FF.Bank = {}
local B = FF.Bank

B.CLOSED_KEEP = 20
B.RATE_HISTORY_KEEP = 36

function B.newState()
    return {
        version = FF.STATE_VERSION,
        nextId = 1,
        regionId = nil,
        monthIndex = 0,
        cropYear = 1,
        baseRate = nil,
        rateTrend = 0,
        rateTrendMonths = 0,
        rateHistory = {},
        farms = {},
        imported = {},
        importReport = {}
    }
end

function B.init(state)
    FF.state = state or B.newState()
    local s = FF.state
    s.farms = s.farms or {}
    s.imported = s.imported or {}
    s.importReport = s.importReport or {}
    s.rateHistory = s.rateHistory or {}
    if s.baseRate == nil then
        s.baseRate = R.get("rates.base.start", 0.065)
    end
    return s
end

function B.nextId(prefix)
    local s = FF.state
    local id = (prefix or "X") .. tostring(s.nextId)
    s.nextId = s.nextId + 1
    return id
end

function B.getFarm(farmId, create)
    local s = FF.state
    local key = tostring(farmId)
    local farm = s.farms[key]
    if farm == nil and create ~= false then
        farm = {
            farmId = farmId,
            history = C.newHistory(),
            loans = {},
            land = {},
            closed = {},
            income = {},
            ledger = {interestPaid = 0, principalPaid = 0, rentPaid = 0, rentIncome = 0},
            lastScore = nil,
            review = nil
        }
        s.farms[key] = farm
    end
    return farm
end

local function env()
    return FF.env or {}
end

local function addMoney(amount, farmId, typeKey)
    if amount ~= 0 and env().addMoney ~= nil then
        env().addMoney(amount, farmId, typeKey)
    end
end

local function notify(farmId, text, isWarning)
    if env().notify ~= nil then
        env().notify(farmId, text, isWarning)
    end
end

local function random()
    if env().random ~= nil then
        return env().random()
    end
    return math.random()
end

local function markDirty()
    if env().markDirty ~= nil then
        env().markDirty()
    end
end

-- Market rate --------------------------------------------------------------

function B.stepBaseRate()
    local s = FF.state
    local minRate = R.get("rates.base.min", 0.025)
    local maxRate = R.get("rates.base.max", 0.12)
    local step = R.get("rates.base.stepPerMonth", 0.00125)

    if (s.rateTrendMonths or 0) <= 0 then
        local middle = (minRate + maxRate) / 2
        local halfRange = math.max((maxRate - minRate) / 2, 0.0001)
        local pull = U.clamp((s.baseRate - middle) / halfRange, -1, 1)
        local downChance = 0.30 + 0.20 * pull
        local upChance = 0.30 - 0.20 * pull
        local roll = random()
        if roll < downChance then
            s.rateTrend = -1
        elseif roll < downChance + upChance then
            s.rateTrend = 1
        else
            s.rateTrend = 0
        end
        s.rateTrendMonths = 3 + math.floor(random() * 6)
    end

    local move = s.rateTrend * step * (0.5 + random())
    s.baseRate = U.round(U.clamp(s.baseRate + move, minRate, maxRate), 5)
    s.rateTrendMonths = s.rateTrendMonths - 1

    table.insert(s.rateHistory, {month = s.monthIndex, rate = s.baseRate})
    while #s.rateHistory > B.RATE_HISTORY_KEEP do
        table.remove(s.rateHistory, 1)
    end
end

-- Debt summary used by credit and the UI ---------------------------------

function B.getDebtSummary(farmId)
    local farm = B.getFarm(farmId, false)
    local summary = {
        debts = {realEstate = 0, equipment = 0, operating = 0, imported = 0},
        total = 0,
        debtService12 = 0,
        principal12 = 0,
        interest12 = 0,
        monthlyPayments = 0
    }
    if farm == nil then
        return summary
    end
    for _, loan in pairs(farm.loans) do
        if loan.balance > 0 then
            local product = loan.productId or "imported"
            summary.debts[product] = (summary.debts[product] or 0) + loan.balance
            summary.total = summary.total + loan.balance
            local total12, principal12 = LM.nextTwelveMonths(loan.balance, loan.rate, loan.payment, loan.monthsLeft)
            summary.debtService12 = summary.debtService12 + total12
            summary.principal12 = summary.principal12 + principal12
            summary.interest12 = summary.interest12 + (total12 - principal12)
            summary.monthlyPayments = summary.monthlyPayments + loan.payment
        end
    end
    -- Operating line: due within the year (yearly clean-up), interest variable.
    local line = farm.line
    if line ~= nil and line.open and (line.balance or 0) > 0 then
        local rate = FF.Line ~= nil and FF.Line.getRate(farm) or 0.08
        summary.debts.operating = summary.debts.operating + line.balance
        summary.total = summary.total + line.balance
        summary.principal12 = summary.principal12 + line.balance
        summary.interest12 = summary.interest12 + line.balance * rate
        summary.debtService12 = summary.debtService12 + line.balance * (1 + rate)
        summary.lineBalance = line.balance
    end
    -- Machine leases: a year of payments (term debt and lease coverage).
    if FF.Equipment ~= nil and farm.leases ~= nil then
        local lease12 = FF.Equipment.getLeasePayments12(farm)
        if lease12 > 0 then
            summary.debtService12 = summary.debtService12 + lease12
            summary.lease12 = lease12
        end
    end
    -- Input account: all of it is due within a year.
    if FF.Inputs ~= nil and farm.inputs ~= nil then
        local balance = FF.Inputs.getBalance(farm)
        if balance > 0 then
            summary.debts.inputs = balance
            summary.total = summary.total + balance
            summary.principal12 = summary.principal12 + balance
            summary.debtService12 = summary.debtService12 + balance
            summary.inputBalance = balance
        end
    end
    return summary
end

-- Credit ---------------------------------------------------------------------

function B.evaluate(farmId)
    local farm = B.getFarm(farmId)
    local snapshot = env().snapshot ~= nil and env().snapshot(farmId) or {totalAssets = 0, totalDebt = 0}
    local ratios = C.ratios(snapshot)
    local score, parts = C.score(ratios, snapshot, farm.history, FF.state.monthIndex)
    farm.lastScore = score
    return {
        score = score,
        grade = C.grade(score),
        parts = parts,
        ratios = ratios,
        snapshot = snapshot
    }
end

function B.quote(farmId, productId, termYears, amount)
    local evaluation = B.evaluate(farmId)
    local quote = C.quote({
        snapshot = evaluation.snapshot,
        ratios = evaluation.ratios,
        score = evaluation.score,
        productId = productId,
        termYears = termYears,
        amount = amount,
        baseRate = FF.state.baseRate
    })
    quote.evaluation = evaluation
    return quote
end

-- Loans ----------------------------------------------------------------------

function B.createLoan(farmId, args)
    local farm = B.getFarm(farmId)
    local months = math.max(1, math.floor(args.months or (args.termYears or 1) * 12))
    local balance = math.max(args.balance or args.amount or 0, 0)
    local loan = {
        id = B.nextId("L"),
        farmId = farmId,
        productId = args.productId or "equipment",
        label = args.label,
        source = args.source or "ff",
        principal = args.amount or balance,
        balance = balance,
        rate = args.rate or FF.state.baseRate,
        monthsTotal = args.monthsTotal or months,
        monthsLeft = months,
        startMonth = FF.state.monthIndex,
        lateMonths = 0,
        status = "active"
    }
    loan.payment = args.payment or LM.payment(balance, loan.rate, months)
    farm.loans[loan.id] = loan
    if not args.noDisbursement and balance > 0 then
        addMoney(balance, farmId, "loanProceeds")
    end
    markDirty()
    return loan
end

function B.applyForLoan(farmId, productId, termYears, amount)
    local quote = B.quote(farmId, productId, termYears, amount)
    if not quote.approved then
        return nil, quote.reason or "ff_reason_declined", quote
    end
    local loan = B.createLoan(farmId, {
        productId = productId,
        amount = amount,
        termYears = termYears,
        rate = quote.rate
    })
    notify(farmId, U.text("ff_msg_loanApproved", U.money(amount), U.percent(loan.rate)), false)
    return loan, nil, quote
end

local function closeLoan(farm, loan, status)
    loan.status = status or "paid"
    loan.balance = 0
    loan.closedMonth = FF.state.monthIndex
    farm.loans[loan.id] = nil
    table.insert(farm.closed, 1, loan)
    while #farm.closed > B.CLOSED_KEEP do
        table.remove(farm.closed)
    end
    if loan.wasDefault then
        farm.history.defaults = math.max((farm.history.defaults or 0) - 1, 0)
    end
end

local function monthsToRepay(balance, rate, payment)
    if payment <= 0 then
        return 1
    end
    local r = rate / 12
    if r <= 0 then
        return math.max(1, math.ceil(balance / payment))
    end
    local x = 1 - balance * r / payment
    if x <= 0 then
        return nil
    end
    return math.max(1, math.ceil(-math.log(x) / math.log(1 + r)))
end

-- Extra principal payment. Keeps the monthly payment and shortens the term.
function B.payExtra(farmId, loanId, amount)
    local farm = B.getFarm(farmId, false)
    local loan = farm ~= nil and farm.loans[loanId] or nil
    if loan == nil then
        return false, "ff_reason_noLoan"
    end
    amount = math.min(amount or 0, loan.balance)
    if amount <= 0 then
        return false, "ff_reason_tooSmall"
    end
    if env().getMoney ~= nil and env().getMoney(farmId) < amount then
        return false, "ff_reason_noCash"
    end
    addMoney(-amount, farmId, "loanPrincipal")
    farm.ledger.principalPaid = farm.ledger.principalPaid + amount
    loan.balance = loan.balance - amount
    if loan.balance <= 0.5 then
        closeLoan(farm, loan, "paid")
        notify(farmId, U.text("ff_msg_loanPaidOff", loan.label or U.text("ff_product_" .. loan.productId)), false)
    else
        local months = monthsToRepay(loan.balance, loan.rate, loan.payment)
        if months ~= nil then
            loan.monthsLeft = math.min(loan.monthsLeft, months)
        end
    end
    markDirty()
    return true
end

-- Payoff without the cash check: sale proceeds pay off the loan a sold
-- machine secured (the sale money has just been credited).
function B.payExtraForced(farmId, loanId, amount)
    local farm = B.getFarm(farmId, false)
    local loan = farm ~= nil and farm.loans[loanId] or nil
    if loan == nil then
        return false
    end
    amount = math.min(amount or loan.balance, loan.balance)
    addMoney(-amount, farmId, "loanPrincipal")
    farm.ledger.principalPaid = farm.ledger.principalPaid + amount
    loan.balance = loan.balance - amount
    if loan.balance <= 0.5 then
        closeLoan(farm, loan, "paid")
    end
    markDirty()
    return true
end

function B.payOff(farmId, loanId)
    local farm = B.getFarm(farmId, false)
    local loan = farm ~= nil and farm.loans[loanId] or nil
    if loan == nil then
        return false, "ff_reason_noLoan"
    end
    return B.payExtra(farmId, loanId, loan.balance)
end

-- Bills every loan of a farm for one month. Returns total billed.
function B.billLoans(farm)
    local billed = 0
    local ids = U.sortedKeys(farm.loans)
    for _, id in ipairs(ids) do
        local loan = farm.loans[id]
        if loan ~= nil and loan.balance > 0 then
            local interest, principal, newBalance = LM.step(loan.balance, loan.rate, loan.payment, loan.monthsLeft)
            addMoney(-interest, farm.farmId, "loanInterest")
            addMoney(-principal, farm.farmId, "loanPrincipal")
            farm.ledger.interestPaid = farm.ledger.interestPaid + interest
            farm.ledger.principalPaid = farm.ledger.principalPaid + principal
            billed = billed + interest + principal
            loan.balance = newBalance
            loan.monthsLeft = math.max(loan.monthsLeft - 1, 0)
            loan.billedThisMonth = true
            if loan.balance <= 0 or loan.monthsLeft <= 0 then
                closeLoan(farm, loan, "paid")
                notify(farm.farmId, U.text("ff_msg_loanPaidOff", loan.label or U.text("ff_product_" .. loan.productId)), false)
            end
        end
    end
    return billed
end

-- After billing: was the farm able to pay? Updates history and defaults.
function B.recordPaymentMonth(farm, billedSomething, forceLate)
    local history = farm.history
    history.monthsOnRecord = (history.monthsOnRecord or 0) + 1
    if not billedSomething and not forceLate then
        return
    end
    local money = env().getMoney ~= nil and env().getMoney(farm.farmId) or 0
    local overdrawn = money < 0
    -- forceLate: a past-due supplier account or a line carryover. It marks
    -- the payment history but doesn't push bank loans toward default.
    local isLate = overdrawn or forceLate == true
    local defaultAfter = R.get("loans.defaultAfterLateMonths", 3)
    if isLate then
        history.late = (history.late or 0) + 1
        history.streak = 0
        history.recentLate = history.recentLate or {}
        table.insert(history.recentLate, FF.state.monthIndex)
        while #history.recentLate > 24 do
            table.remove(history.recentLate, 1)
        end
        if overdrawn then
            for _, loan in pairs(farm.loans) do
                loan.lateMonths = (loan.lateMonths or 0) + 1
                if loan.status ~= "default" and loan.lateMonths >= defaultAfter then
                    loan.status = "default"
                    loan.wasDefault = true
                    history.defaults = (history.defaults or 0) + 1
                    history.missed = (history.missed or 0) + 1
                    loan.rate = loan.rate + R.get("rates.latePenalty", 0.03)
                    loan.payment = LM.payment(loan.balance, loan.rate, math.max(loan.monthsLeft, 1))
                    notify(farm.farmId, U.text("ff_msg_loanDefault", loan.label or U.text("ff_product_" .. loan.productId)), true)
                end
            end
            notify(farm.farmId, U.text("ff_msg_paymentLate"), true)
        end
    else
        history.onTime = (history.onTime or 0) + 1
        history.streak = (history.streak or 0) + 1
        for _, loan in pairs(farm.loans) do
            loan.lateMonths = 0
        end
    end
end

-- Credit review once a year, after harvest.
function B.runReview(farm)
    local evaluation = B.evaluate(farm.farmId)
    farm.review = {
        month = FF.state.monthIndex,
        cropYear = FF.state.cropYear,
        score = evaluation.score,
        grade = evaluation.grade,
        debtToAsset = evaluation.ratios.debtToAsset,
        currentRatio = evaluation.ratios.currentRatio,
        termDebtCoverage = evaluation.ratios.termDebtCoverage
    }
    notify(farm.farmId, U.text("ff_msg_review", evaluation.score, evaluation.grade), false)
end

-- One game month. `period` is the crop period that just started (1-12).
function B.processMonth(period)
    local s = FF.state
    s.monthIndex = s.monthIndex + 1
    s.period = period
    if period == 1 then
        s.cropYear = (s.cropYear or 1) + 1
    end

    B.stepBaseRate()
    if FF.Equipment ~= nil and FF.Equipment.refreshPromos ~= nil then
        FF.Equipment.refreshPromos()
    end

    if FF.Land ~= nil and FF.Land.beginMonth ~= nil then
        FF.Land.beginMonth(period)
    end

    local farmIds = env().getFarmIds ~= nil and env().getFarmIds() or {}
    for _, farmId in ipairs(farmIds) do
        local farm = B.getFarm(farmId)
        local billed = B.billLoans(farm)
        if FF.Land ~= nil and FF.Land.billFarm ~= nil then
            billed = billed + FF.Land.billFarm(farm, period)
        end
        if FF.CropShare ~= nil and FF.CropShare.processMonth ~= nil then
            billed = billed + FF.CropShare.processMonth(farm, period)
        end
        if FF.Equipment ~= nil and FF.Equipment.processMonth ~= nil then
            billed = billed + FF.Equipment.processMonth(farm, period)
        end
        local forceLate = false
        if FF.Inputs ~= nil and FF.Inputs.processMonth ~= nil then
            local paid, pastDue = FF.Inputs.processMonth(farm, period)
            billed = billed + paid
            forceLate = forceLate or pastDue
        end
        if FF.Line ~= nil and FF.Line.processMonth ~= nil then
            local interest, carried = FF.Line.processMonth(farm, period)
            billed = billed + interest
            forceLate = forceLate or carried
        end
        B.recordPaymentMonth(farm, billed > 0, forceLate)
        if FF.FarmData ~= nil and FF.FarmData.closeMonth ~= nil then
            FF.FarmData.closeMonth(farm)
        end
        if period == R.get("credit.reviewPeriod", 10) then
            B.runReview(farm)
        else
            B.evaluate(farmId)
        end
    end

    if FF.Land ~= nil and FF.Land.endMonth ~= nil then
        FF.Land.endMonth(period)
    end

    markDirty()
end

-- Vanilla loan takeover: turns farm.loan into a Farm Finance loan.
function B.convertVanillaLoan(farmId, amount)
    if amount == nil or amount <= 0 then
        return nil
    end
    local rate = C.rateFor(FF.state.baseRate, "equipment", 700)
    local loan = B.createLoan(farmId, {
        productId = "equipment",
        amount = amount,
        months = 60,
        rate = rate,
        source = "vanilla",
        label = U.text("ff_label_vanillaLoan"),
        noDisbursement = true
    })
    table.insert(FF.state.importReport, U.text("ff_import_vanilla", U.money(amount), U.percent(rate)))
    return loan
end

return B
